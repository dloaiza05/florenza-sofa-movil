from pathlib import Path
import json,shutil,sys
base=Path(__file__).resolve().parents[1];publication=Path(sys.argv[1]).resolve()
mapping=json.loads((base/'herramientas/assets-map.json').read_text())
for name,relative in mapping.items():
 source=publication/name
 if not source.exists():continue
 target=base/'tienda/public/assets'/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
target=base/'tienda/public/prueba3d';target.mkdir(parents=True,exist_ok=True)
for name in ['index.html','viewer.js','viewer.css','model-viewer.min.js','LICENSE-model-viewer.txt','qr.svg','sofa-190-gris.glb','sofa-190-arena.glb','sofa-190-petroleo.glb']:
 shutil.copy2(publication/name,target/name)
# Use the optimized images provided in the publication.
for folder in ['src','server']:
 for file in (base/'tienda'/folder).rglob('*'):
  if file.suffix not in ['.js','.jsx','.json']:continue
  text=file.read_text(encoding='utf-8')
  for rel in mapping.values():
   if rel.endswith('.webp'):text=text.replace('/assets/'+rel[:-5]+'.png','/assets/'+rel)
  file.write_text(text,encoding='utf-8')
print('Medios preparados; configurar entorno e instalar dependencias antes de iniciar.')
