from pathlib import Path
import urllib.request,json,shutil,re
root=Path.cwd(); src=root/'outputs/dekoramma-web'; dest=root/'outputs/florenza-sofa-movil'; work=root/'tmp/github-store-src'; work.mkdir(exist_ok=True)
shutil.copytree(src/'src',work/'src',dirs_exist_ok=True)
catalog=json.load(urllib.request.urlopen('http://localhost:8790/api/catalog'))
assets=src/'public/assets'; mapping={}
for f in assets.rglob('*'):
 if not f.is_file():continue
 rel=f.relative_to(assets).as_posix(); chosen=f
 if f.suffix=='.png' and f.with_suffix('.webp').exists():chosen=f.with_suffix('.webp')
 name='asset-'+chosen.relative_to(assets).as_posix().replace('/','-')
 mapping['/assets/'+rel]='./'+name
 if chosen.suffix not in ['.css'] and not (dest/name).exists():shutil.copy2(chosen,dest/name)
def transform(text):
 for k,v in sorted(mapping.items(),key=lambda x:-len(x[0])):text=text.replace(k,v)
 text=text.replace('href="/"','href="./dekoramma.html"').replace('href="/admin/vista-previa"','href="./dekoramma.html?vista=admin"').replace('href="/admin"','href="./dekoramma.html?vista=admin"')
 text=text.replace('href="/informacion','href="./dekoramma.html?vista=informacion').replace('href="/preferencias','href="./dekoramma.html?vista=preferencias')
 text=text.replace('href="/prueba3d/index.html"','href="./index.html"')
 text=text.replace('"/informacion#','"./dekoramma.html?vista=informacion#')
 text=text.replace('/assets/payments/','./asset-payments-').replace('/assets/social/','./asset-social-')
 text=text.replace('/prueba3d/index.html', './index.html')
 return text
# Public storefront data only; no users, credentials, documents or customer records.
catalog=json.loads(transform(json.dumps(catalog,ensure_ascii=False)))
for key in list(catalog['settings']):
 if any(x in key.lower() for x in ['secret','token','password','credential']):del catalog['settings'][key]
(work/'src/catalog.json').write_text(json.dumps(catalog,ensure_ascii=False),encoding='utf-8')
for f in (work/'src').rglob('*'):
 if f.suffix in ['.js','.jsx','.css']:
  text=transform(f.read_text(encoding='utf-8'))
  if f.name=='Admin.jsx':
   text=text.replace('href="./dekoramma.html?vista=admin"','href="./dekoramma.html"').replace('Entrar para publicar →','Volver a la tienda →').replace('Entrar al administrador →','Volver a la tienda →').replace('Para subir archivos o publicar, inicia sesión.','Los cambios de esta demostración se pierden al recargar. Subir archivos y publicar requiere el servidor; no está habilitado en GitHub Pages.')
  f.write_text(text,encoding='utf-8')
for f in assets.rglob('*.css'):(dest/('asset-'+f.relative_to(assets).as_posix().replace('/','-'))).write_text(transform(f.read_text()),encoding='utf-8')
api=(src/'src/api.js').read_text(encoding='utf-8'); constants=api[api.index('export const money'):api.index('export const mediaUrl')]
(work/'src/api.js').write_text('''import catalog from './catalog.json';
import {createAdminPreviewApi} from './admin-preview-api';
const admin=createAdminPreviewApi(catalog);
export const setCsrf=()=>{};
export async function api(url,{method='GET',body}={}){
 if(url.startsWith('/admin/'))return admin(url,{method,body});
 if(method!=='GET')throw new Error('Esta es una demostración: no se envían datos, no se crean pedidos y no se realizan cobros.');
 if(url==='/catalog')return structuredClone(catalog);
 if(url==='/documents')return {documents:[]};
 if(url.startsWith('/products?')){
  const p=new URL(url,'https://preview.invalid').searchParams;
  let items=catalog.products.filter(x=>x.active!==false);
  const category=p.get('category'),q=(p.get('q')||'').toLocaleLowerCase('es');
  if(category&&category!=='Todo')items=items.filter(x=>x.category===category);
  if(q)items=items.filter(x=>(x.name+' '+x.category+' '+x.description).toLocaleLowerCase('es').includes(q));
  if(p.get('maxPrice'))items=items.filter(x=>x.price<=Number(p.get('maxPrice')));
  if(p.get('sort')==='low')items.sort((a,b)=>a.price-b.price);
  if(p.get('sort')==='high')items.sort((a,b)=>b.price-a.price);
  const page=Math.max(1,Number(p.get('page'))||1),size=12,total=items.length;
  return structuredClone({items:items.slice((page-1)*size,page*size),total,pages:Math.ceil(total/size),page});
 }
 if(url.startsWith('/products/')){const item=catalog.products.find(x=>x.id===url.split('/').pop());if(item)return structuredClone(item);}
 throw new Error('Esta opción requiere el servidor de la tienda. No está conectada en la demostración.');
}
export const mediaUrl=url=>url;
'''+constants,encoding='utf-8')
(work/'dynamic.jsx').write_text("import React,{lazy,Suspense} from 'react'; export default function dynamic(load,options={}){const C=lazy(load);return function Dynamic(p){return <Suspense fallback={options.loading?React.createElement(options.loading):null}><C {...p}/></Suspense>}}",encoding='utf-8')
(work/'entry.jsx').write_text('''import React from 'react';import{createRoot}from'react-dom/client';
import App from './src/main';import Admin from './src/Admin';import LegalCenter from './src/LegalCenter';import MarketingPreferences from './src/MarketingPreferences';import './src/style.css';
const view=new URLSearchParams(location.search).get('vista');
function Preview(){return <><aside className="github-preview"><strong>Vista de prueba · Dekoramma</strong><span>Catálogo de ejemplo. Sin cobros ni envío de formularios.</span><nav><a href="./dekoramma.html">Tienda</a><a href="./dekoramma.html?vista=admin">Probar administración</a></nav></aside>{view==='admin'?<Admin preview/>:view==='informacion'?<LegalCenter/>:view==='preferencias'?<MarketingPreferences/>:<App/>}</>}
createRoot(document.getElementById('root')).render(<Preview/>);
''',encoding='utf-8')
with (work/'src/style.css').open('a',encoding='utf-8')as f:f.write('''
.github-preview{display:flex;align-items:center;justify-content:center;gap:16px;flex-wrap:wrap;background:#24251f;color:#fff;padding:10px 16px;font:12px/1.5 Arial,sans-serif}.github-preview nav{display:flex;gap:12px}.github-preview a{color:#ead2ae;text-decoration:underline}.preview-model-note{font:13px/1.6 Arial;color:#5b5349;background:#f8f4ee;padding:12px;border-radius:8px}.mobile-sofa-integration>p:last-child{text-align:center}.mobile-sofa-integration a{color:#a74627}@media(max-width:600px){.github-preview{gap:5px;text-align:center}.github-preview span{width:100%}}
''')
(dest/'dekoramma.html').write_text('''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><meta name="robots" content="noindex,nofollow"><meta name="referrer" content="strict-origin-when-cross-origin"><title>Dekoramma · Industrial artesanal · Vista de prueba</title><link rel="stylesheet" href="store.css"><script type="module" src="store.js"></script></head><body><div id="root"></div></body></html>''',encoding='utf-8')
print('Public catalog',len(catalog['products']),'products;',len(mapping),'asset mappings')
