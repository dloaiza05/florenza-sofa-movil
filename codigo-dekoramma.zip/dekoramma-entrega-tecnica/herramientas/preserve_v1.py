from pathlib import Path
import urllib.request,hashlib,json
commit='0c605c5a6b1bbac7983828bcd7a1c0caca70af52'
out=Path('outputs/florenza-sofa-movil-v1');out.mkdir(exist_ok=True)
names=['index.html','viewer.js','viewer.css','README.md','manifest.json','qr.svg','model-viewer.min.js','LICENSE-model-viewer.txt','sofa-190-gris.glb','sofa-190-arena.glb','sofa-190-petroleo.glb']
hashes={}
for name in names:
 data=urllib.request.urlopen(f'https://raw.githubusercontent.com/dloaiza05/florenza-sofa-movil/{commit}/{name}').read()
 (out/name).write_bytes(data);hashes[name]=hashlib.sha256(data).hexdigest()
(out/'VERSION-ORIGINAL.json').write_text(json.dumps({'commit':commit,'sha256':hashes},indent=2),encoding='utf-8')
publish=Path('outputs/florenza-sofa-movil')
h=(out/'index.html').read_text(encoding='utf-8').replace('href="viewer.css"','href="v1-viewer.css"').replace('src="viewer.js"','src="v1-viewer.js"').replace('href="index.html"','href="v1.html"').replace('src="qr.svg"','src="v1-qr.svg"').replace('https://dloaiza05.github.io/florenza-sofa-movil/','https://dloaiza05.github.io/florenza-sofa-movil/v1.html')
(publish/'v1.html').write_text(h,encoding='utf-8')
j=(out/'viewer.js').read_text(encoding='utf-8').replace("const shareURL='https://dloaiza05.github.io/florenza-sofa-movil/';","const shareURL='https://dloaiza05.github.io/florenza-sofa-movil/v1.html';")
(publish/'v1-viewer.js').write_text(j,encoding='utf-8');(publish/'v1-viewer.css').write_bytes((out/'viewer.css').read_bytes())
import qrcode,qrcode.image.svg
qrcode.make('https://dloaiza05.github.io/florenza-sofa-movil/v1.html',image_factory=qrcode.image.svg.SvgPathImage).save(publish/'v1-qr.svg')
print('Version 1 preserved from commit',commit,'with',len(hashes),'verified source files')
