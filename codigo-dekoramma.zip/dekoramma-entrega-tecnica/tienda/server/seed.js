import { initialContent } from "./content.js";
import { legalDefaults } from "./legal-content.js";
export const categories = [
  "Salas completas",
  "Esquineros",
  "Sofás cama",
  "Modulares",
  "Poltronas",
  "Reclinables",
  "Sofás",
  "Comedores",
  "Camas",
  "Colchones",
  "Bases cama",
];
const rows = [
  ["canela", "Juego Canela", "Salas completas", 2189000, "sala-calida.png"],
  ["milan", "Esquinero Milán", "Esquineros", 2890000, "milan.png"],
  ["aurora", "Sofá cama Aurora", "Sofás cama", 1290000, "aurora.png"],
  ["bruna", "Modular Bruna", "Modulares", 2450000, "sala-creativa.png"],
  ["rose", "Poltronas Rosé · par", "Poltronas", 1180000, "rose.png"],
  ["nara", "Reclinable Nara", "Reclinables", 1850000, "nara.png"],
];
export const initialSettings = {
  storeName: "Dekoramma",
  phone: "573163072132",
  email: "dekoramma@gmail.com",
  mapsPlaceId: "",
  address: "Calle 59C Sur #89A-22, Bosa, Bogotá D. C., Colombia",
  hours: "Lun–Sáb 10:30–19:00 · Dom y festivos 11:00–18:00",
  announcement: "Hecho a tu medida · Envíos a toda Colombia",
  heroTitle: "No la escogemos. La fabricamos.",
  heroImage: "/assets/sala-industrial.png",
  facebook: "https://www.facebook.com/dekoramma",
  instagram: "https://www.instagram.com/dekoramma/",
  paymentMethods: [
    "Bold",
    "PSE",
    "Addi",
    "Sistecrédito",
    "Vanti Listo",
    "Nequi",
    "Daviplata",
  ],
  paymentNote:
    "Consulta disponibilidad y condiciones con un asesor. El envío se confirma según tu ciudad. Las cuotas mostradas son una división ilustrativa del precio, sin incluir intereses ni otros cargos.",
  privacy:
    "Usamos los datos que compartes para responder tu solicitud y coordinar tu compra. La política definitiva del negocio debe aprobarse antes de abrir ventas.",
  terms:
    "Los precios y fotografías de esta versión son referencias del boceto. Medidas, materiales, disponibilidad, flete y forma de pago se confirman antes de aceptar la compra.",
  warranty:
    "La cobertura y condiciones de garantía se confirman por escrito con la tienda antes de comprar.",
  demo: true,
  marketingEnabled: true,
  ...legalDefaults,
};
export async function seed(db) {
  await db.query(
    "CREATE TABLE IF NOT EXISTS content(id INTEGER PRIMARY KEY,data JSONB NOT NULL)",
  );
  await db.query(
    "INSERT INTO content(id,data) VALUES(1,$1::jsonb) ON CONFLICT(id) DO NOTHING",
    [JSON.stringify(initialContent)],
  );
  await db.query(
    "UPDATE content SET data = data || $1::jsonb WHERE id=1 AND NOT (data ? 'campaigns')",
    [JSON.stringify({ campaigns: initialContent.campaigns })],
  );
  await db.query(
    "UPDATE content SET data = data || $1::jsonb WHERE id=1 AND NOT (data ? 'financeBanners')",
    [JSON.stringify({ financeBanners: initialContent.financeBanners })],
  );
  for (const [id, name, category, price, image] of rows) {
    const data = {
      id,
      name,
      category,
      price,
      image: "/assets/" + image,
      description:
        "Fabricada a tu medida. Elige configuración, tapizado y color con el acompañamiento de nuestro taller.",
      width: 270,
      depth: 170,
      height: 90,
      colors: ["Arena", "Gris", "Petróleo", "Rosa"],
      active: true,
      modelUrl: "/assets/modulo-demo.glb",
      usdzUrl: "",
      modelDemo: true,
      videoUrl: "",
    };
    await db.query(
      "INSERT INTO products(id,data) VALUES($1,$2::jsonb) ON CONFLICT(id) DO NOTHING",
      [id, JSON.stringify(data)],
    );
  }
  await db.query(
    "INSERT INTO settings(id,data) VALUES(1,$1::jsonb) ON CONFLICT(id) DO NOTHING",
    [JSON.stringify(initialSettings)],
  );
  // Add our new legal fields without overwriting custom business copy.
  const former = {
    privacy:
      "Usamos los datos que compartes para responder tu solicitud y coordinar tu compra. La política definitiva del negocio debe aprobarse antes de abrir ventas.",
    terms:
      "Los precios y fotografías de esta versión son referencias del boceto. Medidas, materiales, disponibilidad, flete y forma de pago se confirman antes de aceptar la compra.",
    warranty:
      "La cobertura y condiciones de garantía se confirman por escrito con la tienda antes de comprar.",
  };
  for (const [key, value] of Object.entries(legalDefaults))
    await db.query(
      "UPDATE settings SET data=jsonb_set(data,ARRAY[$1::text],$2::jsonb) WHERE id=1 AND (NOT(data ? $1::text) OR data->>$1=$3)",
      [key, JSON.stringify(value), former[key] ?? null],
    );
  // Add newly verified contact fields without replacing any saved business data.
  await db.query(
    "UPDATE settings SET data=data || '{\"marketingEnabled\":true}'::jsonb WHERE id=1 AND NOT(data ? 'marketingEnabled')",
  );
  await db.query(
    "UPDATE settings SET data=data || $1::jsonb WHERE id=1 AND NOT (data ? 'email')",
    [JSON.stringify({ email: initialSettings.email, mapsPlaceId: "" })],
  );
}
