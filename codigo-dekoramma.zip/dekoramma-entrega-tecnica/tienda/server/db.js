import "dotenv/config";
import { PGlite } from "@electric-sql/pglite";
import pg from "pg";
import fs from "node:fs/promises";
import path from "node:path";
export async function openDatabase({
  url = process.env.DATABASE_URL,
  dir = process.env.DATA_DIR || "./data/postgres",
} = {}) {
  let driver;
  if (url) driver = new pg.Pool({ connectionString: url, max: 8 });
  else {
    if (dir !== "memory://")
      await fs.mkdir(path.resolve(dir), { recursive: true });
    driver = new PGlite(dir === "memory://" ? undefined : path.resolve(dir));
    await driver.waitReady;
  }
  const db = {
    query: (sql, params = []) => driver.query(sql, params),
    close: () => (url ? driver.end() : driver.close()),
  };
  await db.query(
    `CREATE TABLE IF NOT EXISTS documents(id TEXT PRIMARY KEY,category TEXT NOT NULL,title TEXT NOT NULL,document_year INTEGER NOT NULL,version INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'draft',filename TEXT NOT NULL,byte_size INTEGER NOT NULL,sha256 TEXT NOT NULL,created_by TEXT NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT now(),updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),UNIQUE(category,document_year,version))`,
  );
  await db.query(
    `CREATE TABLE IF NOT EXISTS document_events(id TEXT PRIMARY KEY,document_id TEXT REFERENCES documents(id),action TEXT NOT NULL,actor TEXT NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT now(),details JSONB NOT NULL)`,
  );
  await db.query(
    `CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY, data JSONB NOT NULL, updated_at TIMESTAMPTZ NOT NULL DEFAULT now())`,
  );
  await db.query(
    `CREATE TABLE IF NOT EXISTS settings(id INTEGER PRIMARY KEY, data JSONB NOT NULL)`,
  );
  await db.query(
    `CREATE TABLE IF NOT EXISTS admins(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL)`,
  );
  await db.query(
    `CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,admin_id TEXT REFERENCES admins(id) ON DELETE CASCADE,csrf TEXT NOT NULL,expires_at TIMESTAMPTZ NOT NULL)`,
  );
  await db.query(`ALTER TABLE admins ADD COLUMN IF NOT EXISTS google_sub TEXT`);
  await db.query(
    `CREATE UNIQUE INDEX IF NOT EXISTS admins_google_sub ON admins(google_sub) WHERE google_sub IS NOT NULL`,
  );
  await db.query(
    `ALTER TABLE sessions ADD COLUMN IF NOT EXISTS auth_provider TEXT NOT NULL DEFAULT 'password'`,
  );
  await db.query(
    `CREATE TABLE IF NOT EXISTS google_login_attempts(state_hash TEXT PRIMARY KEY,browser_hash TEXT NOT NULL,nonce TEXT NOT NULL,verifier TEXT NOT NULL,expires_at TIMESTAMPTZ NOT NULL DEFAULT now()+interval '5 minutes')`,
  );
  await db.query(
    `CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,token_hash TEXT NOT NULL,idempotency_key TEXT UNIQUE NOT NULL,payload_hash TEXT NOT NULL,data JSONB NOT NULL,status TEXT NOT NULL DEFAULT 'recibido',created_at TIMESTAMPTZ NOT NULL DEFAULT now())`,
  );
  await db.query(
    `CREATE TABLE IF NOT EXISTS leads(id TEXT PRIMARY KEY,data JSONB NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT now())`,
  );
  await db.query(
    `CREATE TABLE IF NOT EXISTS marketing_contacts(id TEXT PRIMARY KEY,token_hash TEXT UNIQUE NOT NULL,data JSONB NOT NULL,status TEXT NOT NULL DEFAULT 'pending_verification',created_at TIMESTAMPTZ NOT NULL DEFAULT now(),updated_at TIMESTAMPTZ NOT NULL DEFAULT now())`,
  );
  await db.query(
    `CREATE TABLE IF NOT EXISTS marketing_events(id BIGSERIAL PRIMARY KEY,contact_id TEXT NOT NULL REFERENCES marketing_contacts(id),action TEXT NOT NULL,details JSONB NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT now())`,
  );
  return db;
}
