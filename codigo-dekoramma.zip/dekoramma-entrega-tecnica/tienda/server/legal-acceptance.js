import {hash} from './security.js';
export function legalSnapshot(settings,documents=[]){
 const snapshot={version:settings.legalVersion||'Sin versión',draft:settings.legalDraft!==false,terms:settings.terms,privacy:settings.privacy,warranty:settings.warranty,withdrawal:settings.withdrawal||'',documents:documents.map(x=>({id:x.id,category:x.category,version:x.version,year:x.document_year,sha256:x.sha256})).sort((a,b)=>a.category.localeCompare(b.category))};
 return {...snapshot,fingerprint:hash(JSON.stringify(snapshot))};
}
