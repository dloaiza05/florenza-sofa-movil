import { z } from "zod";
import { categories } from "../seed.js";
export const txt = (max = 300) => z.string().trim().min(1).max(max);
export const asset = z
  .string()
  .max(500)
  .refine(
    (s) => s === "" || /^\/(assets|uploads)\/[a-zA-Z0-9._-]+$/.test(s),
    "Usa un archivo de la biblioteca",
  );
export const productSchema = z
  .object({
    id: z.string().regex(/^[a-z0-9-]{1,80}$/),
    name: txt(100),
    category: z.enum(categories),
    price: z.number().int().min(1000).max(100000000),
    description: txt(2000),
    image: asset.refine(Boolean),
    width: z.number().min(20).max(1000),
    depth: z.number().min(20).max(1000),
    height: z.number().min(10).max(500),
    colors: z.array(txt(40)).min(1).max(20),
    active: z.boolean(),
    modelUrl: asset,
    usdzUrl: asset,
    modelDemo: z.boolean(),
    videoUrl: asset,
    gallery: z
      .array(
        z.object({
          url: asset.refine(
            (s) => /\.(png|jpe?g|webp)$/i.test(s),
            "Selecciona una fotografía",
          ),
          color: z.string().trim().max(40).default(""),
          alt: z.string().trim().max(160).default(""),
        }),
      )
      .max(10)
      .default([]),
    videos: z
      .array(
        z.object({
          url: asset.refine(
            (s) => /\.mp4$/i.test(s),
            "Selecciona un video MP4",
          ),
          title: txt(100),
        }),
      )
      .max(3)
      .default([]),
    madeToMeasure: z.boolean().default(false),
    materials: z.string().trim().max(1000).default(""),
    care: z.string().trim().max(1500).default(""),
    leadTime: z.string().trim().max(200).default(""),
    modelParts: z
      .object(
        Object.fromEntries(
          ["arms", "back", "seat", "legs"].map((key) => [
            key,
            z.array(txt(100)).max(12).default([]),
          ]),
        ),
      )
      .default({ arms: [], back: [], seat: [], legs: [] }),
    finishes: z
      .array(
        z.object({
          id: z.string().regex(/^[a-z0-9-]{1,80}$/),
          label: txt(50),
          hex: z.string().regex(/^#[0-9a-fA-F]{6}$/),
        }),
      )
      .max(20)
      .default([]),
    legOptions: z
      .array(
        z.object({
          id: z.string().regex(/^[a-z0-9-]{1,80}$/),
          label: txt(80),
          modelUrl: asset.refine((s) => s.endsWith(".glb")),
          usdzUrl: asset.refine((s) => !s || s.endsWith(".usdz")),
        }),
      )
      .max(6)
      .default([]),
  })
  .superRefine((p, ctx) => {
    p.gallery.forEach((photo, i) => {
      if (photo.color && !p.colors.includes(photo.color))
        ctx.addIssue({
          code: "custom",
          path: ["gallery", i, "color"],
          message:
            "El color de la fotografía debe estar entre los colores del producto",
        });
    });
    if (p.gallery.length && p.image !== p.gallery[0].url)
      ctx.addIssue({
        code: "custom",
        path: ["image"],
        message: "La portada debe ser la primera fotografía de la galería",
      });
    const names = Object.values(p.modelParts).flat();
    if (new Set(names).size !== names.length)
      ctx.addIssue({
        code: "custom",
        path: ["modelParts"],
        message: "Cada pieza debe utilizar materiales exclusivos",
      });
    for (const key of ["finishes", "legOptions"])
      if (new Set(p[key].map((x) => x.id)).size !== p[key].length)
        ctx.addIssue({
          code: "custom",
          path: [key],
          message: "Los códigos deben ser únicos",
        });
  });
export const catalogQuerySchema = z.object({
  q: z.string().trim().max(100).default(""),
  category: z.union([z.enum(categories), z.literal("Todo")]).default("Todo"),
  sort: z.enum(["featured", "low", "high"]).default("featured"),
  page: z.coerce.number().int().min(1).max(10000).default(1),
  pageSize: z.coerce.number().int().min(1).max(24).default(12),
  maxPrice: z.coerce.number().int().min(1000).max(100000000).optional(),
});
export const settingsSchema = z.object({
  storeName: txt(80),
  phone: z.string().regex(/^\d{10,15}$/),
  email: z.union([z.email().max(150), z.literal("")]).default(""),
  mapsPlaceId: z
    .string()
    .max(200)
    .regex(/^[a-zA-Z0-9_-]*$/)
    .default(""),
  address: txt(200),
  hours: txt(250),
  announcement: txt(160),
  heroTitle: txt(160),
  heroImage: asset.refine(Boolean),
  facebook: z.url().startsWith("https://www.facebook.com/"),
  instagram: z.url().startsWith("https://www.instagram.com/"),
  paymentMethods: z.array(txt(30)).max(10),
  paymentNote: txt(2000),
  privacy: txt(10000),
  terms: txt(10000),
  warranty: txt(10000),
  demo: z.boolean(),
  marketingEnabled:z.boolean().default(true),
  legalName:z.string().trim().max(150).default(''),
  taxId:z.string().trim().max(30).default(''),
  registration:z.string().trim().max(120).default(''),
  legalDraft:z.boolean().default(true),
  legalVersion:txt(100).default('Borrador v1 · 11/09/2026'),
  withdrawal:z.string().max(10000).default(''),
  documentation:z.string().max(10000).default(''),
});
export const configSchema = z.object({
  shape: z.enum(["Lineal", "En L", "En U"]),
  fabric: z.enum(["Petróleo", "Terracota", "Mostaza", "Gris", "Arena"]),
  extras: z.array(z.enum(["Baúl", "Mesa de centro", "Antifluidos"])).max(3),
});
export const productConfigSchema = z.object({
  kind: z.literal("product"),
  productId: txt(80),
  color: txt(40),
  parts: z
    .object(
      Object.fromEntries(
        ["arms", "back", "seat", "legs"].map((key) => [
          key,
          txt(80).optional(),
        ]),
      ),
    )
    .default({}),
  legOption: z.string().max(80).default(""),
});
export const orderSchema = z.object({
  termsAccepted:z.literal(true),
  legalFingerprint:z.string().regex(/^[a-f0-9]{64}$/),
  customer: z.object({
    name: txt(100),
    phone: z.string().regex(/^[+\d\s-]{7,22}$/),
    email: z.email().max(150),
    city: txt(100),
    address: txt(250),
    notes: z.string().max(1000).default(""),
    consent: z.literal(true),
  }),
  items: z
    .array(
      z.object({
        id: txt(80),
        quantity: z.number().int().min(1).max(10),
        color: txt(40),
      }),
    )
    .min(1)
    .max(20),
  method: txt(30),
  idempotencyKey: z.uuid(),
  trackingToken: z.string().regex(/^[a-f0-9]{64}$/),
});
