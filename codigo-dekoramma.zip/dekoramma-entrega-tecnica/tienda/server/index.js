/**
 * Hecho por Leidy Rodriguez
 * Iniciado el 11/09/2026
 * [contacto privado omitido en copia pública]
 * Realizado por Florenza Digital
 */
import "dotenv/config";
import next from "next";
import { openDatabase } from "./db.js";
import { seed } from "./seed.js";
import { createApp } from "./app.js";
const production =
  process.argv.includes("--production") ||
  process.env.NODE_ENV === "production";
if (
  production &&
  (!process.env.DATABASE_URL || !process.env.APP_ORIGIN?.startsWith("https://"))
)
  throw Error(
    "Producción requiere DATABASE_URL PostgreSQL y APP_ORIGIN HTTPS.",
  );
const port = Number(process.env.PORT || 8790),
  host = process.env.HOST || "127.0.0.1";
const nextApp = next({ dev: !production, hostname: host, port });
await nextApp.prepare();
const db = await openDatabase();
await seed(db);
const app = createApp(db, {
  production,
  origin: process.env.APP_ORIGIN || "http://localhost:" + port,
  uploadDir: process.env.UPLOAD_DIR || "./uploads",
});
app.use((req, res) => nextApp.getRequestHandler()(req, res));
const server = app.listen(port, host, () =>
  console.log(
    "Dekoramma lista en http://localhost:" + port + " · Administración /admin",
  ),
);
server.on("upgrade", (req, socket, head) =>
  nextApp.getUpgradeHandler()(req, socket, head),
);
for (const sig of ["SIGINT", "SIGTERM"])
  process.on(sig, () =>
    server.close(async () => {
      await db.close();
      await nextApp.close();
      process.exit(0);
    }),
  );
