import express from "express";
import helmet from "helmet";
import { rateLimit } from "express-rate-limit";
import path from "node:path";
import { randomBytes } from "node:crypto";
import { createStoreRepository } from "./repositories/store.repository.js";
import { apiRoutes } from "./routes/api.routes.js";
import { handleError } from "./middleware/errors.js";
import { documentsRepository } from "./repositories/documents.repository.js";
import { marketingRepository } from "./repositories/marketing.repository.js";
import { mediaProtection } from "./middleware/media-protection.js";
export function createApp(
  db,
  {
    production = false,
    uploadDir = "./uploads",
    origin = "http://localhost:8790",
    documentDir = process.env.DOCUMENT_DIR || "./data/documents",
  } = {},
) {
  for (const publicRoot of ["./public", uploadDir]) {
    const relative = path.relative(
      path.resolve(publicRoot),
      path.resolve(documentDir),
    );
    if (
      !relative ||
      (!relative.startsWith(".." + path.sep) &&
        relative !== ".." &&
        !path.isAbsolute(relative))
    )
      throw new Error(
        "La biblioteca de documentos debe estar fuera de las carpetas públicas.",
      );
  }
  const app = express();
  app.disable("x-powered-by");
  app.use((req, res, next) => {
    let url;
    try {
      url = decodeURIComponent(req.path).toLowerCase();
    } catch {
      return res.status(400).end();
    }
    if (
      /(?:^|\/)\.(?!well-known(?:\/|$))/.test(url) ||
      /^\/(?:data|server|src|app|docs|output|qa|tests|scripts|node_modules)(?:\/|$)/.test(
        url,
      ) ||
      /^\/(?:package(?:-lock)?\.json|dockerfile|compose\.yaml|autoria\.md|readme\.md|next\.config\.mjs)$/.test(
        url,
      ) ||
      /\.(?:env|pem|key|p12|pfx|dpapi|log)$/.test(url) ||
      /\.(?:blend\d*|psd|psb|ai|fig|sketch|raw|dng|cr2|nef|exr|sql|sqlite|bak|7z)$/.test(
        url,
      ) ||
      (production && url.endsWith(".map"))
    ) {
      res.status(404).end();
      return;
    }
    if (
      url === "/admin" ||
      url.startsWith("/admin/") ||
      url.startsWith("/api/")
    ) {
      res.set("Cache-Control", "no-store");
      res.set("X-Robots-Tag", "noindex, nofollow");
    }
    next();
  });
  if (process.env.TRUST_PROXY === "1") app.set("trust proxy", 1);
  app.use((req, res, next) => {
    res.locals.nonce = randomBytes(16).toString("base64");
    next();
  });
  const security = helmet({
    contentSecurityPolicy: production
      ? {
          directives: {
            defaultSrc: ["'self'"],
            scriptSrc: [
              "'self'",
              (req, res) => "'nonce-" + res.locals.nonce + "'",
            ],
            styleSrc: ["'self'", "'unsafe-inline'"],
            imgSrc: ["'self'", "data:", "blob:"],
            connectSrc: ["'self'"],
            fontSrc: ["'self'"],
            workerSrc: ["'self'", "blob:"],
            objectSrc: ["'none'"],
            frameAncestors: ["'none'"],
            upgradeInsecureRequests: null,
          },
        }
      : false,
    crossOriginEmbedderPolicy: false,
  });
  app.use(security);
  app.use(["/assets", "/uploads"], mediaProtection());
  // Next reads the per-request CSP to nonce its own bootstrap scripts.
  app.use((req, res, next) => {
    if (production)
      req.headers["content-security-policy"] = res.getHeader(
        "Content-Security-Policy",
      );
    next();
  });
  app.use(express.json({ limit: "256kb" }));
  app.use(
    "/api",
    rateLimit({
      windowMs: 60000,
      limit: 180,
      standardHeaders: "draft-8",
      legacyHeaders: false,
      message: { error: "Demasiadas solicitudes. Intenta más tarde." },
    }),
  );
  app.use("/api", (req, res, next) => {
    res.set("Cache-Control", "no-store");
    if (!["GET", "HEAD", "OPTIONS"].includes(req.method)) {
      const sent = req.headers.origin;
      if (sent && sent !== origin)
        return res.status(403).json({ error: "Origen no autorizado" });
      if (production && !sent)
        return res
          .status(403)
          .json({ error: "Se requiere una solicitud del sitio" });
    }
    next();
  });
  app.use(
    "/uploads",
    express.static(path.resolve(uploadDir), {
      dotfiles: "deny",
      setHeaders(res, file) {
        res.setHeader("X-Content-Type-Options", "nosniff");
        if (file.endsWith(".glb")) res.type("model/gltf-binary");
        if (file.endsWith(".usdz")) res.type("model/vnd.usdz+zip");
      },
    }),
  );
  app.use(
    "/api",
    apiRoutes(createStoreRepository(db), {
      production,
      origin,
      uploadDir,
      documentDir,
      documentsRepo: documentsRepository(db),
      marketingRepo: marketingRepository(db),
    }),
  );
  app.use(handleError);
  return app;
}
