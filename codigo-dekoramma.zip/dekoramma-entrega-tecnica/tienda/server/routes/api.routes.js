import { Router } from "express";
import { rateLimit } from "express-rate-limit";
import multer from "multer";
import { catalogController } from "../controllers/catalog.controller.js";
import { authController } from "../controllers/auth.controller.js";
import { contentController } from "../controllers/content.controller.js";
import { ordersController } from "../controllers/orders.controller.js";
import { leadsController } from "../controllers/leads.controller.js";
import { mediaController } from "../controllers/media.controller.js";
import { createAuthService } from "../services/auth.service.js";
import { createOrdersService } from "../services/orders.service.js";
import { authenticate } from "../middleware/auth.js";
import { documentsController } from "../controllers/documents.controller.js";
import { marketingController } from "../controllers/marketing.controller.js";
import {
  createGoogleAuthService,
  googleConfiguration,
} from "../services/google-auth.service.js";
import { googleAuthController } from "../controllers/google-auth.controller.js";
export function apiRoutes(
  repo,
  { production, origin, uploadDir, documentDir, documentsRepo, marketingRepo },
) {
  const googleConfig = googleConfiguration(origin);
  const router = Router(),
    authService = createAuthService(
      repo,
      googleConfig.enabled ? googleConfig.emails : [],
    ),
    auth = authenticate(authService);
  const google = googleAuthController(
    createGoogleAuthService(repo, googleConfig),
    production,
  );
  const catalog = catalogController(repo),
    marketing = marketingController(repo, marketingRepo),
    documents = documentsController(documentsRepo, documentDir),
    account = authController(authService, production),
    content = contentController(repo),
    orders = ordersController(createOrdersService(repo));
  const limits = (n) =>
      rateLimit({
        windowMs: 15 * 60000,
        limit: n,
        standardHeaders: "draft-8",
        legacyHeaders: false,
        message: { error: "Demasiadas solicitudes. Intenta más tarde." },
      }),
    submit = limits(30);
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 100 * 1024 * 1024, files: 1 },
  });
  router.get("/health", catalog.health);
  router.get("/catalog", catalog.list);
  router.get("/products", catalog.page);
  router.get("/products/:id", catalog.detail);
  router.get("/documents", documents.publicList);
  router.get("/documents/:id/file", documents.downloadPublic);
  router.post("/login", limits(10), account.login);
  router.get("/auth/options", (req, res) =>
    res.json({ google: googleConfig.enabled }),
  );
  router.get("/auth/google/start", limits(10), google.start);
  router.get("/auth/google/callback", limits(20), google.callback);
  router.post("/orders", submit, orders.create);
  router.post("/track", submit, orders.track);
  router.post("/leads", submit, leadsController(repo));
  router.post("/marketing", limits(8), marketing.create);
  router.post("/marketing/withdraw", limits(15), marketing.withdraw);
  router.use("/admin", auth);
  router.get("/admin/me", account.me);
  router.get("/admin/marketing", marketing.list);
  router.post("/admin/marketing/:id/withdraw", marketing.withdrawAdmin);
  router.get("/admin/documents", documents.list);
  router.get("/admin/documents/:id/file", documents.downloadPrivate);
  router.post(
    "/admin/documents",
    multer({
      storage: multer.memoryStorage(),
      limits: { fileSize: 20 * 1024 * 1024, files: 1 },
    }).single("file"),
    documents.upload,
  );
  router.patch("/admin/documents/:id", documents.change);
  router.post("/admin/logout", account.logout);
  router.get("/admin/data", content.dashboard);
  router.get("/admin/content", content.read);
  router.put("/admin/content", content.save);
  router.put("/admin/settings", content.settings);
  router.put("/admin/products/:id", catalog.save);
  router.delete("/admin/products/:id", catalog.remove);
  router.patch("/admin/orders/:id", orders.status);
  router.post(
    "/admin/upload",
    upload.single("file"),
    mediaController(uploadDir),
  );
  router.use((req, res) =>
    res.status(404).json({ error: "Ruta no encontrada" }),
  );
  return router;
}
