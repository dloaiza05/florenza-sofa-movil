export function marketingRepository(db) {
  return {
    async create(id, tokenHash, data) {
      await db.query(
        `WITH added AS (INSERT INTO marketing_contacts(id,token_hash,data) VALUES($1,$2,$3::jsonb) RETURNING id) INSERT INTO marketing_events(contact_id,action,details) SELECT id,'consent_requested',$4::jsonb FROM added`,
        [
          id,
          tokenHash,
          JSON.stringify(data),
          JSON.stringify({
            channels: data.channels,
            consent: data.consent,
            source: "storefront",
          }),
        ],
      );
    },
    async tokenFor(id) {
      return (
        await db.query(
          "SELECT token_hash FROM marketing_contacts WHERE id=$1",
          [id],
        )
      ).rows[0]?.token_hash;
    },
    async withdraw(tokenHash, details = { source: "private_management_link" }) {
      // Cancel all requests associated with the same contact, including duplicates.
      const result = await db.query(
        `WITH owner AS (SELECT data FROM marketing_contacts WHERE token_hash=$1), changed AS (UPDATE marketing_contacts SET status='withdrawn',updated_at=now() WHERE status<>'withdrawn' AND EXISTS (SELECT 1 FROM owner WHERE (owner.data->>'email'<>'' AND owner.data->>'email'=marketing_contacts.data->>'email') OR (owner.data->>'phone'<>'' AND owner.data->>'phone'=marketing_contacts.data->>'phone')) RETURNING id) INSERT INTO marketing_events(contact_id,action,details) SELECT id,'withdrawn',$2::jsonb FROM changed RETURNING contact_id`,
        [tokenHash, JSON.stringify(details)],
      );
      return result.rows.length;
    },
    async list(page) {
      const total = Number(
        (await db.query("SELECT count(*) AS total FROM marketing_contacts"))
          .rows[0].total,
      );
      const contacts = (
        await db.query(
          "SELECT id,data,status,created_at,updated_at FROM marketing_contacts ORDER BY created_at DESC,id LIMIT 24 OFFSET $1",
          [(page - 1) * 24],
        )
      ).rows;
      const events = (
        await db.query(
          "SELECT contact_id,action,created_at,details FROM marketing_events ORDER BY created_at DESC LIMIT 100",
        )
      ).rows;
      return {
        contacts,
        events,
        total,
        page,
        pages: Math.max(1, Math.ceil(total / 24)),
      };
    },
  };
}
