import { randomUUID } from "node:crypto";
export const publicDocumentCategories = [
  "terms",
  "privacy",
  "warranty",
  "withdrawal",
];
export function documentsRepository(db) {
  return {
    list: async () =>
      (
        await db.query(
          "SELECT id,category,title,document_year,version,status,byte_size,sha256,created_by,created_at,updated_at FROM documents ORDER BY created_at DESC",
        )
      ).rows,
    publicList: async () =>
      (
        await db.query(
          "SELECT DISTINCT ON(category) id,category,title,document_year,version,updated_at FROM documents WHERE status='published' AND category=ANY($1) ORDER BY category,updated_at DESC",
          [publicDocumentCategories],
        )
      ).rows,
    get: async (id) =>
      (await db.query("SELECT * FROM documents WHERE id=$1", [id])).rows[0],
    byHash: async (hash) =>
      (await db.query("SELECT id FROM documents WHERE sha256=$1", [hash]))
        .rows[0],
    events: async () =>
      (
        await db.query(
          "SELECT e.id,e.document_id,d.title,e.action,e.actor,e.created_at,e.details FROM document_events e JOIN documents d ON d.id=e.document_id ORDER BY e.created_at DESC LIMIT 1000",
        )
      ).rows,
    create: async (d) =>
      (
        await db.query(
          `WITH saved AS (INSERT INTO documents(id,category,title,document_year,version,filename,byte_size,sha256,created_by) SELECT $1,$2,$3,$4,COALESCE(MAX(version),0)+1,$5,$6,$7,$8 FROM documents WHERE category=$2 AND document_year=$4 RETURNING *), audit AS (INSERT INTO document_events(id,document_id,action,actor,details) SELECT $9,id,'uploaded',$8,jsonb_build_object('version',version,'year',document_year,'sha256',sha256) FROM saved) SELECT id,version FROM saved`,
          [
            d.id,
            d.category,
            d.title,
            d.year,
            d.filename,
            d.size,
            d.hash,
            d.actor,
            randomUUID(),
          ],
        )
      ).rows[0],
    transition: async (id, expected, next, actor) =>
      (
        await db.query(
          `WITH changed AS (UPDATE documents SET status=$1,updated_at=now() WHERE id=$2 AND status=$3 RETURNING *), audit AS (INSERT INTO document_events(id,document_id,action,actor,details) SELECT $4,id,$1,$5,jsonb_build_object('from',$3::text,'to',$1::text,'version',version) FROM changed) SELECT id,status FROM changed`,
          [next, id, expected, randomUUID(), actor],
        )
      ).rows[0],
  };
}
