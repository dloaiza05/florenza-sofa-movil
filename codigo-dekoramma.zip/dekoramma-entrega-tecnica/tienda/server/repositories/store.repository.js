// SQL lives here; controllers and services never depend on a database driver.
export function createStoreRepository(db) {
  const row = async (sql, args = []) => (await db.query(sql, args)).rows[0];
  const rows = async (sql, args = []) => (await db.query(sql, args)).rows;
  return {
    health: () => db.query("SELECT 1"),
    publishedDocuments: () =>
      rows(
        "SELECT DISTINCT ON(category) id,category,document_year,version,sha256 FROM documents WHERE status='published' AND category IN ('terms','privacy','warranty','withdrawal') ORDER BY category,updated_at DESC",
      ),
    settings: async () =>
      (await row("SELECT data FROM settings WHERE id=1")).data,
    content: async () =>
      (await row("SELECT data FROM content WHERE id=1")).data,
    saveContent: (data) =>
      db.query("UPDATE content SET data=$1::jsonb WHERE id=1", [
        JSON.stringify(data),
      ]),
    saveSettings: (data) =>
      db.query("UPDATE settings SET data=$1::jsonb WHERE id=1", [
        JSON.stringify(data),
      ]),
    products: async (activeOnly = false) =>
      (
        await rows(
          "SELECT data FROM products" +
            (activeOnly ? " WHERE data->>'active'='true'" : "") +
            " ORDER BY id",
        )
      ).map((x) => x.data),
    product: async (id) =>
      (await row("SELECT data FROM products WHERE id=$1", [id]))?.data,
    productPage: async ({ q, category, sort, page, pageSize, maxPrice }) => {
      const args = [],
        clauses = ["data->>'active'='true'"];
      const parameter = (value) => {
        args.push(value);
        return "$" + args.length;
      };
      if (category !== "Todo")
        clauses.push("data->>'category'=" + parameter(category));
      if (q)
        clauses.push(
          "strpos(lower(concat_ws(' ',data->>'name',data->>'category',data->>'description')),lower(" +
            parameter(q) +
            "))>0",
        );
      if (maxPrice)
        clauses.push("(data->>'price')::numeric<=" + parameter(maxPrice));
      const where = " WHERE " + clauses.join(" AND ");
      const total = Number(
        (await row("SELECT count(*) AS total FROM products" + where, args))
          .total,
      );
      const pages = Math.max(1, Math.ceil(total / pageSize)),
        current = Math.min(page, pages);
      const order =
        sort === "low"
          ? "(data->>'price')::numeric ASC,id"
          : sort === "high"
            ? "(data->>'price')::numeric DESC,id"
            : "CASE id WHEN 'canela' THEN 0 WHEN 'milan' THEN 1 WHEN 'aurora' THEN 2 WHEN 'bruna' THEN 3 WHEN 'rose' THEN 4 WHEN 'nara' THEN 5 ELSE 6 END,id";
      const result = await rows(
        "SELECT data FROM products" +
          where +
          " ORDER BY " +
          order +
          " LIMIT " +
          parameter(pageSize) +
          " OFFSET " +
          parameter((current - 1) * pageSize),
        args,
      );
      return {
        items: result.map((x) => x.data),
        total,
        page: current,
        pageSize,
        pages,
      };
    },
    saveProduct: (data) =>
      db.query(
        "INSERT INTO products(id,data) VALUES($1,$2::jsonb) ON CONFLICT(id) DO UPDATE SET data=EXCLUDED.data,updated_at=now()",
        [data.id, JSON.stringify(data)],
      ),
    hideProduct: (id) =>
      db.query(
        "UPDATE products SET data=jsonb_set(data,'{active}','false'::jsonb),updated_at=now() WHERE id=$1",
        [id],
      ),
    admin: (email) => row("SELECT * FROM admins WHERE email=$1", [email]),
    createGoogleAttempt: async (state, browser, nonce, verifier) => {
      await db.query(
        "DELETE FROM google_login_attempts WHERE expires_at<=now()",
      );
      await db.query(
        "INSERT INTO google_login_attempts(state_hash,browser_hash,nonce,verifier) VALUES($1,$2,$3,$4)",
        [state, browser, nonce, verifier],
      );
    },
    consumeGoogleAttempt: (state, browser) =>
      row(
        "DELETE FROM google_login_attempts WHERE state_hash=$1 AND browser_hash=$2 AND expires_at>now() RETURNING nonce,verifier",
        [state, browser],
      ),
    bindGoogleAdmin: (email, sub) =>
      row(
        "UPDATE admins SET google_sub=$2 WHERE email=$1 AND (google_sub IS NULL OR google_sub=$2) RETURNING id,email",
        [email, sub],
      ),
    session: (tokenHash) =>
      row(
        "SELECT s.*,a.email FROM sessions s JOIN admins a ON a.id=s.admin_id WHERE token_hash=$1 AND expires_at>now()",
        [tokenHash],
      ),
    purgeSessions: () =>
      db.query("DELETE FROM sessions WHERE expires_at<now()"),
    createSession: (tokenHash, id, csrf, provider = "password") =>
      db.query(
        "INSERT INTO sessions(token_hash,admin_id,csrf,expires_at,auth_provider) VALUES($1,$2,$3,now()+interval '8 hours',$4)",
        [tokenHash, id, csrf, provider],
      ),
    deleteSession: (tokenHash) =>
      db.query("DELETE FROM sessions WHERE token_hash=$1", [tokenHash]),
    orders: () =>
      rows(
        "SELECT id,data,status,created_at FROM orders ORDER BY created_at DESC LIMIT 500",
      ),
    orderByKey: (key) =>
      row("SELECT * FROM orders WHERE idempotency_key=$1", [key]),
    createOrder: (id, tokenHash, key, payloadHash, data) =>
      db.query(
        "INSERT INTO orders(id,token_hash,idempotency_key,payload_hash,data) VALUES($1,$2,$3,$4,$5::jsonb)",
        [id, tokenHash, key, payloadHash, JSON.stringify(data)],
      ),
    track: (id, tokenHash) =>
      row(
        "SELECT id,status,created_at,data FROM orders WHERE id=$1 AND token_hash=$2",
        [id, tokenHash],
      ),
    setOrderStatus: (id, status) =>
      row("UPDATE orders SET status=$1 WHERE id=$2 RETURNING id", [status, id]),
    leads: () =>
      rows(
        "SELECT id,data,created_at FROM leads ORDER BY created_at DESC LIMIT 500",
      ),
    createLead: (id, data) =>
      db.query("INSERT INTO leads(id,data) VALUES($1,$2::jsonb)", [
        id,
        JSON.stringify(data),
      ]),
  };
}
