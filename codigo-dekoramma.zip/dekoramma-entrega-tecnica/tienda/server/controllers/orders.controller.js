import { z } from "zod";
import { orderSchema } from "../validators/schemas.js";
export function ordersController(service) {
  return {
    create: async (req, res) => {
      const result = await service.create(orderSchema.parse(req.body));
      res.status(result.repeated ? 200 : 201).json(result);
    },
    track: async (req, res) => {
      const { id, token } = z
        .object({ id: z.uuid(), token: z.string().regex(/^[a-f0-9]{64}$/) })
        .parse(req.body);
      res.json(await service.track(id, token));
    },
    status: async (req, res) => {
      const { status } = z
        .object({
          status: z.enum([
            "recibido",
            "contactado",
            "confirmado",
            "en_fabricacion",
            "enviado",
            "entregado",
            "cancelado",
          ]),
        })
        .parse(req.body);
      res.json(await service.changeStatus(req.params.id, status));
    },
  };
}
