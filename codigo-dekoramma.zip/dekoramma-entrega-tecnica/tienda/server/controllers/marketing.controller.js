import { z } from "zod";
import { randomUUID } from "node:crypto";
import { hash, random } from "../security.js";
import { HttpError } from "../lib/http-error.js";
import { legalSnapshot } from "../legal-acceptance.js";
import { marketingConsent } from "../../src/consent-copy.js";
const schema = z
  .object({
    name: z.string().trim().max(100).default(""),
    email: z.union([z.email().max(254), z.literal("")]).default(""),
    phone: z
      .union([z.string().regex(/^(?:\+?57)?3\d{9}$/), z.literal("")])
      .default(""),
    channels: z
      .array(z.enum(["email", "whatsapp"]))
      .min(1)
      .max(2)
      .transform((x) => [...new Set(x)]),
    consent: z.literal(true),
    legalFingerprint: z.string().regex(/^[a-f0-9]{64}$/),
  })
  .superRefine((x, ctx) => {
    for (const field of x.channels.map((c) =>
      c === "email" ? "email" : "phone",
    ))
      if (!x[field])
        ctx.addIssue({
          code: "custom",
          path: [field],
          message: "Completa el canal que autorizas",
        });
  });
export function marketingController(repo, marketing) {
  return {
    create: async (req, res) => {
      const input = schema.parse(req.body),
        settings = await repo.settings();
      if (settings.marketingEnabled === false)
        throw new HttpError(
          409,
          "La inscripción a novedades está deshabilitada.",
        );
      const legal = legalSnapshot(settings, await repo.publishedDocuments());
      if (
        !settings.demo &&
        (!settings.legalName?.trim() || !settings.taxId?.trim())
      )
        throw new HttpError(
          409,
          "La inscripción se habilitará al completar la información del responsable.",
        );
      if (legal.fingerprint !== input.legalFingerprint)
        throw new HttpError(
          409,
          "La política cambió. Actualiza la página y revísala antes de continuar.",
        );
      if (!settings.demo && settings.legalDraft !== false)
        throw new HttpError(
          409,
          "La inscripción a novedades todavía está en preparación.",
        );
      const token = random(),
        id = randomUUID();
      await marketing.create(id, hash(token), {
        name: input.name,
        email: input.channels.includes("email")
          ? input.email.trim().toLowerCase()
          : "",
        phone: input.channels.includes("whatsapp")
          ? "57" + input.phone.replace(/^\+?57/, "")
          : "",
        channels: input.channels,
        consent: {
          text: marketingConsent,
          acceptedAt: new Date().toISOString(),
          privacy: legal.privacy,
          version: legal.version,
          fingerprint: legal.fingerprint,
          documents: legal.documents,
        },
        demo: settings.demo,
        identityVerified: false,
      });
      res.status(201).json({
        id,
        status: "pending_verification",
        managementPath: "/preferencias#" + token,
        message:
          "Guardamos tu solicitud. Los envíos todavía no están habilitados; tu canal deberá verificarse antes de activarlos.",
      });
    },
    withdraw: async (req, res) => {
      const { token } = z
        .object({ token: z.string().regex(/^[a-f0-9]{64}$/) })
        .parse(req.body);
      await marketing.withdraw(hash(token));
      // Same response for unknown and previously withdrawn links; no contact enumeration.
      res.json({
        ok: true,
        message:
          "La autorización asociada a este enlace queda retirada. Si tienes otras solicitudes, puedes gestionarlas con la tienda.",
      });
    },
    withdrawAdmin: async (req, res) => {
      const id = z.uuid().parse(req.params.id),
        { reason } = z
          .object({ reason: z.string().trim().min(10).max(500) })
          .parse(req.body);
      const tokenHash = await marketing.tokenFor(id);
      if (!tokenHash) throw new HttpError(404, "Registro no encontrado");
      await marketing.withdraw(tokenHash, {
        source: "admin_request",
        actor: req.session.email,
        reason,
      });
      res.json({ ok: true });
    },
    list: async (req, res) =>
      res.json(
        await marketing.list(
          z.coerce
            .number()
            .int()
            .min(1)
            .max(10000)
            .default(1)
            .parse(req.query.page),
        ),
      ),
  };
}
