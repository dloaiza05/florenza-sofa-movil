import { cookie } from "../security.js";
import { sessionCookie } from "./auth.controller.js";
export function googleAuthController(service, production) {
  const challengeCookie = {
    httpOnly: true,
    secure: production,
    sameSite: "lax",
    path: "/api/auth/google",
    maxAge: 5 * 60000,
  };
  return {
    start: async (req, res) => {
      const { url, browserKey } = await service.start();
      res
        .cookie("dk_google_challenge", browserKey, challengeCookie)
        .redirect(303, url);
    },
    callback: async (req, res) => {
      res.set("Referrer-Policy", "no-referrer");
      res.clearCookie("dk_google_challenge", {
        ...challengeCookie,
        maxAge: undefined,
      });
      try {
        const { token } = await service.finish({
          state: req.query.state,
          code: req.query.code,
          browserKey: cookie(req, "dk_google_challenge"),
        });
        res
          .cookie("dk_session", token, sessionCookie(production))
          .redirect(303, "/admin");
      } catch {
        // Never include OAuth codes, tokens, email allowlists or provider errors in URLs/logs.
        res.redirect(303, "/admin?acceso=no-autorizado");
      }
    },
  };
}
