import { z } from "zod";
import { txt } from "../validators/schemas.js";
export const sessionCookie = (production) => ({
  httpOnly: true,
  secure: production,
  sameSite: "strict",
  maxAge: 8 * 3600000,
  path: "/",
});
export function authController(service, production) {
  return {
    login: async (req, res) => {
      const i = z
        .object({ email: z.email().max(150), password: txt(200) })
        .parse(req.body);
      const { token, ...user } = await service.login(i.email, i.password);
      res.cookie("dk_session", token, sessionCookie(production)).json(user);
    },
    me: (req, res) =>
      res.json({ email: req.session.email, csrf: req.session.csrf }),
    logout: async (req, res) => {
      await service.logout(req.session.token_hash);
      res.clearCookie("dk_session", { path: "/" }).json({ ok: true });
    },
  };
}
