import { z } from "zod";
import path from "node:path";
import { storeDocument } from "../services/documents.service.js";
import { publicDocumentCategories } from "../repositories/documents.repository.js";
import { HttpError } from "../lib/http-error.js";
const schema = z.object({
  title: z.string().trim().min(3).max(160),
  category: z.enum([
    "terms",
    "privacy",
    "warranty",
    "withdrawal",
    "rut",
    "chamber",
    "other",
  ]),
  year: z.coerce.number().int().min(1900).max(2100),
});
export function documentsController(repo, dir) {
  const download = async (req, res, privateAccess) => {
    const doc = await repo.get(req.params.id);
    if (
      !doc ||
      (!privateAccess &&
        (doc.status !== "published" ||
          !publicDocumentCategories.includes(doc.category)))
    )
      throw new HttpError(404, "Documento no disponible");
    res.set("Cache-Control", "no-store");
    res.set("Content-Security-Policy", "sandbox; default-src 'none'");
    res.set("X-Content-Type-Options", "nosniff");
    res.type("application/pdf");
    res.download(
      path.resolve(dir, doc.filename),
      doc.category + "-" + doc.document_year + "-v" + doc.version + ".pdf",
    );
  };
  return {
    list: async (req, res) =>
      res.json({ documents: await repo.list(), events: await repo.events() }),
    publicList: async (req, res) =>
      res.json({ documents: await repo.publicList() }),
    upload: async (req, res) =>
      res
        .status(201)
        .json(
          await storeDocument(
            repo,
            dir,
            req.file,
            schema.parse(req.body),
            req.session.email,
          ),
        ),
    change: async (req, res) => {
      const { status } = z
          .object({ status: z.enum(["approved", "published", "archived"]) })
          .parse(req.body),
        doc = await repo.get(req.params.id);
      if (!doc) throw new HttpError(404, "Documento no encontrado");
      const allowed = {
        draft: ["approved", "archived"],
        approved: ["published", "archived"],
        published: ["archived"],
        archived: [],
      };
      if (!allowed[doc.status].includes(status))
        throw new HttpError(409, "Ese cambio de estado no está permitido.");
      if (
        status === "published" &&
        !publicDocumentCategories.includes(doc.category)
      )
        throw new HttpError(
          400,
          "RUT, Cámara de Comercio y documentos internos se conservan privados.",
        );
      const result = await repo.transition(
        doc.id,
        doc.status,
        status,
        req.session.email,
      );
      if (!result)
        throw new HttpError(409, "El estado cambió. Actualiza la biblioteca.");
      res.json(result);
    },
    downloadPrivate: (req, res) => download(req, res, true),
    downloadPublic: (req, res) => download(req, res, false),
  };
}
