import { productSchema, catalogQuerySchema } from "../validators/schemas.js";
import { HttpError } from "../lib/http-error.js";
import {legalSnapshot} from '../legal-acceptance.js';
export function catalogController(repo) {
  const summary = ({ gallery, videos, care, materials, ...p }) => ({
    ...p,
    colorImages: (gallery || [])
      .filter((x) => x.color)
      .map(({ url, color, alt }) => ({ url, color, alt })),
  });
  return {
    page: async (req, res) => {
      const result = await repo.productPage(
        catalogQuerySchema.parse(req.query),
      );
      res.json({ ...result, items: result.items.map(summary) });
    },
    detail: async (req, res) => {
      const product = await repo.product(req.params.id);
      if (!product?.active) throw new HttpError(404, "Producto no disponible");
      res.json(product);
    },
    health: async (req, res) => {
      await repo.health();
      res.json({ ok: true });
    },
    list: async (req, res) => {
      const [products, settings, content] = await Promise.all([
        repo.products(true),
        repo.settings(),
        repo.content(),
      ]);
      const legal=legalSnapshot(settings,await repo.publishedDocuments());
      res.json({ products: products.map(summary), settings, content,legalFingerprint:legal.fingerprint });
    },
    save: async (req, res) => {
      const data = productSchema.parse(req.body);
      if (data.id !== req.params.id)
        throw new HttpError(400, "Identificador inválido");
      await repo.saveProduct(data);
      res.json(data);
    },
    remove: async (req, res) => {
      await repo.hideProduct(req.params.id);
      res.json({ ok: true });
    },
  };
}
