import { saveMedia } from "../services/media.service.js";
export const mediaController = (uploadDir) => async (req, res) =>
  res.status(201).json(await saveMedia(req.file, uploadDir));
