import { contentSchema } from "../content.js";
import { settingsSchema } from "../validators/schemas.js";
export function contentController(repo) {
  return {
    read: async (req, res) =>
      res.json(contentSchema.parse(await repo.content())),
    save: async (req, res) => {
      const data = contentSchema.parse(req.body);
      await repo.saveContent(data);
      res.json(data);
    },
    settings: async (req, res) => {
      const data = settingsSchema.parse(req.body);
      await repo.saveSettings(data);
      res.json(data);
    },
    dashboard: async (req, res) => {
      const [products, orders, leads, settings] = await Promise.all([
        repo.products(),
        repo.orders(),
        repo.leads(),
        repo.settings(),
      ]);
      res.json({ products, orders, leads, settings });
    },
  };
}
