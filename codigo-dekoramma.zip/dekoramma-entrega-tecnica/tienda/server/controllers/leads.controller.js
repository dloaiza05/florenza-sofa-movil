import { z } from "zod";
import { randomUUID } from "node:crypto";
import {
  txt,
  configSchema,
  productConfigSchema,
} from "../validators/schemas.js";
import { modelOptions, partLabels } from "../../src/product-options.js";
import { HttpError } from "../lib/http-error.js";
import { legalSnapshot } from "../legal-acceptance.js";
import { adviceConsent } from "../../src/consent-copy.js";
export function leadsController(repo) {
  return async (req, res) => {
    const data = z
      .object({
        name: txt(100),
        phone: z.string().regex(/^[+\d\s-]{7,22}$/),
        city: txt(100),
        message: txt(2000),
        consent: z.literal(true),
        email: z.union([z.email().max(254), z.literal("")]).default(""),
        contactChannel: z
          .enum(["whatsapp", "phone", "email"])
          .default("whatsapp"),
        preferredDate: z.union([z.iso.date(), z.literal("")]).default(""),
        preferredTime: z.enum(["", "morning", "afternoon"]).default(""),
        legalFingerprint: z
          .string()
          .regex(/^[a-f0-9]{64}$/)
          .optional(),
        configuration: z.union([configSchema, productConfigSchema]).optional(),
        type: z.enum(["asesoria", "personalizacion", "envio"]),
      })
      .parse(req.body);
    if (data.contactChannel === "email" && !data.email)
      throw new HttpError(
        400,
        "Indica el correo al que quieres que respondamos.",
      );
    const legal = legalSnapshot(
      await repo.settings(),
      await repo.publishedDocuments(),
    );
    if (data.legalFingerprint && data.legalFingerprint !== legal.fingerprint)
      throw new HttpError(
        409,
        "La política cambió. Actualiza la tienda y revisa la autorización.",
      );
    data.contactConsent = {
      text: adviceConsent,
      channel: data.contactChannel,
      acceptedAt: new Date().toISOString(),
      privacy: legal.privacy,
      version: legal.version,
      fingerprint: legal.fingerprint,
      viewedFingerprintProvided: !!data.legalFingerprint,
    };
    data.marketingConsent = false;
    if (data.configuration?.kind === "product") {
      const config = data.configuration,
        p = await repo.product(config.productId);
      if (!p?.active || !p.colors.includes(config.color))
        throw new HttpError(400, "Producto o color no disponible");
      const options = modelOptions(p);
      for (const [part, finish] of Object.entries(config.parts))
        if (
          !options.parts[part]?.length ||
          !options.finishes.some((x) => x.id === finish)
        )
          throw new HttpError(400, "Acabado no disponible para esta pieza");
      if (
        config.legOption &&
        !options.legs.some((x) => x.id === config.legOption)
      )
        throw new HttpError(400, "Opción de patas no disponible");
      data.configuration = {
        ...config,
        productName: p.name,
        summary: Object.entries(config.parts)
          .map(
            ([part, id]) =>
              partLabels[part] +
              ": " +
              options.finishes.find((x) => x.id === id).label,
          )
          .join(" · "),
        legLabel:
          options.legs.find((x) => x.id === config.legOption)?.label ||
          "Patas del modelo base",
      };
    }
    const id = randomUUID();
    await repo.createLead(id, data);
    res.status(201).json({ id });
  };
}
