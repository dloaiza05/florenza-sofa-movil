import { hash, random, verify } from "../security.js";
import { HttpError } from "../lib/http-error.js";
export function createAuthService(repo, googleAllowedEmails = []) {
  return {
    async login(email, password) {
      const admin = await repo.admin(email.toLowerCase());
      if (!admin || !verify(password, admin.password_hash))
        throw new HttpError(401, "Correo o contraseña incorrectos");
      const token = random(),
        csrf = random();
      await repo.purgeSessions();
      await repo.createSession(hash(token), admin.id, csrf);
      return { token, csrf, email: admin.email };
    },
    async session(token) {
      const s = token ? await repo.session(hash(token)) : null;
      if (!s) throw new HttpError(401, "Inicia sesión o renueva tu acceso");
      if (
        s.auth_provider === "google" &&
        !googleAllowedEmails.includes(s.email)
      ) {
        await repo.deleteSession(s.token_hash);
        throw new HttpError(401, "Inicia sesión o renueva tu acceso");
      }
      return s;
    },
    logout: (tokenHash) => repo.deleteSession(tokenHash),
  };
}
