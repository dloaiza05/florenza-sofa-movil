import fs from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";
import ffprobe from "ffprobe-static";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { HttpError } from "../lib/http-error.js";
const probe = promisify(execFile);
export async function saveMedia(file, uploadDir) {
  if (!file) throw new HttpError(400, "Selecciona un archivo");
  const b = file.buffer,
    ext = path.extname(file.originalname).toLowerCase();
  let valid = false;
  if (ext === ".glb") {
    valid =
      b.length >= 20 &&
      b.toString("ascii", 0, 4) === "glTF" &&
      b.readUInt32LE(4) === 2 &&
      b.readUInt32LE(8) === b.length;
    if (valid) {
      try {
        const len = b.readUInt32LE(12);
        if (b.readUInt32LE(16) !== 0x4e4f534a || len > b.length - 20)
          throw Error();
        const json = JSON.parse(b.toString("utf8", 20, 20 + len).trim());
        valid =
          json.asset?.version === "2.0" &&
          ![...(json.buffers || []), ...(json.images || [])].some(
            (x) => x.uri && !x.uri.startsWith("data:"),
          );
      } catch {
        valid = false;
      }
    }
  }
  if (ext === ".usdz")
    valid =
      b.length > 4 &&
      b[0] === 0x50 &&
      b[1] === 0x4b &&
      b[2] === 3 &&
      b[3] === 4;
  if (ext === ".png")
    valid = b
      .subarray(0, 8)
      .equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
  if ([".jpg", ".jpeg"].includes(ext))
    valid = b[0] === 255 && b[1] === 216 && b[2] === 255;
  if (ext === ".webp")
    valid =
      b.toString("ascii", 0, 4) === "RIFF" &&
      b.toString("ascii", 8, 12) === "WEBP";
  if (ext === ".mp4") valid = b.toString("ascii", 4, 8) === "ftyp";
  if (!valid)
    throw new HttpError(
      400,
      "Archivo inválido. Admite PNG, JPG, WebP, MP4, GLB v2 autocontenido o USDZ.",
    );
  await fs.mkdir(uploadDir, { recursive: true });
  const name = randomUUID() + ext,
    filePath = path.join(uploadDir, name);
  await fs.writeFile(filePath, b);
  if (ext === ".mp4") {
    try {
      const { stdout } = await probe(
        ffprobe.path,
        [
          "-v",
          "error",
          "-show_entries",
          "format=duration:stream=codec_type",
          "-of",
          "json",
          filePath,
        ],
        { timeout: 15000, maxBuffer: 1024 * 1024 },
      );
      const result = JSON.parse(stdout),
        duration = Number(result.format?.duration);
      if (
        !result.streams?.some((s) => s.codec_type === "video") ||
        !Number.isFinite(duration) ||
        duration <= 0 ||
        duration > 180
      )
        throw Error();
    } catch {
      await fs.unlink(filePath).catch(() => {});
      throw new HttpError(
        400,
        "El video debe ser un MP4 válido de hasta 3 minutos (180 segundos).",
      );
    }
  }
  return { url: "/uploads/" + name };
}
