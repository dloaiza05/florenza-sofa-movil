import fs from "node:fs/promises";
import path from "node:path";
import { randomUUID, createHash } from "node:crypto";
import { PDFDocument, PDFDict, PDFName } from "pdf-lib";
import { HttpError } from "../lib/http-error.js";
export async function storeDocument(repo, dir, file, input, actor) {
  if (
    !file ||
    file.buffer.length > 20 * 1024 * 1024 ||
    !file.originalname.toLowerCase().endsWith(".pdf")
  )
    throw new HttpError(400, "Selecciona un PDF de hasta 20 MB.");
  try {
    const pdf = await PDFDocument.load(file.buffer, {
      ignoreEncryption: false,
      updateMetadata: false,
    });
    if (pdf.getPageCount() < 1 || pdf.getPageCount() > 500) throw Error();
    for (const [, object] of pdf.context.enumerateIndirectObjects())
      if (object instanceof PDFDict) {
        for (const name of [
          "JS",
          "JavaScript",
          "Launch",
          "EmbeddedFiles",
          "OpenAction",
          "AA",
          "RichMediaContent",
        ])
          if (object.has(PDFName.of(name))) throw Error();
        const action = object.get(PDFName.of("S"));
        if (
          action &&
          [
            "/JavaScript",
            "/Launch",
            "/SubmitForm",
            "/ImportData",
            "/GoToR",
          ].includes(action.toString())
        )
          throw Error();
      }
  } catch {
    throw new HttpError(
      400,
      "El PDF no es válido, está protegido o contiene acciones/adjuntos no admitidos. Usa una copia simple sin contraseña.",
    );
  }
  const id = randomUUID(),
    filename = id + ".pdf",
    hash = createHash("sha256").update(file.buffer).digest("hex");
  await fs.mkdir(dir, { recursive: true });
  const target = path.join(dir, filename);
  await fs.writeFile(target, file.buffer, { flag: "wx" });
  try {
    for (let attempt = 0; attempt < 3; attempt++)
      try {
        return await repo.create({
          id,
          ...input,
          filename,
          size: file.buffer.length,
          hash,
          actor,
        });
      } catch (error) {
        if (error.code !== "23505" || attempt === 2) throw error;
      }
  } catch (error) {
    await fs.unlink(target).catch(() => {});
    throw error;
  }
}
