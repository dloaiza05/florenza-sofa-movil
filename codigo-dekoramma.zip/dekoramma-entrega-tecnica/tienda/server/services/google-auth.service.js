import { OAuth2Client } from "google-auth-library";
import { createHash } from "node:crypto";
import { hash, random } from "../security.js";
import { HttpError } from "../lib/http-error.js";

export function googleConfiguration(origin, env = process.env) {
  const emails = (env.GOOGLE_ADMIN_EMAILS || "")
    .split(",")
    .map((x) => x.trim().toLowerCase())
    .filter(Boolean);
  return {
    clientId: env.GOOGLE_CLIENT_ID || "",
    clientSecret: env.GOOGLE_CLIENT_SECRET || "",
    redirectUri: new URL("/api/auth/google/callback", origin).href,
    emails,
    enabled: Boolean(
      env.GOOGLE_CLIENT_ID && env.GOOGLE_CLIENT_SECRET && emails.length,
    ),
  };
}

export function createGoogleAuthService(
  repo,
  config,
  client = new OAuth2Client(
    config.clientId,
    config.clientSecret,
    config.redirectUri,
  ),
) {
  const denied = () =>
    new HttpError(
      403,
      "No se pudo autorizar esta cuenta. Contacta al responsable de la tienda.",
    );
  return {
    async start() {
      if (!config.enabled)
        throw new HttpError(
          503,
          "Acceso con Google pendiente de configuración",
        );
      const state = random(),
        browserKey = random(),
        nonce = random(),
        verifier = random();
      await repo.createGoogleAttempt(
        hash(state),
        hash(browserKey),
        nonce,
        verifier,
      );
      const url = client.generateAuthUrl({
        access_type: "online",
        scope: ["openid", "email"],
        prompt: "select_account",
        state,
        nonce,
        code_challenge_method: "S256",
        code_challenge: createHash("sha256")
          .update(verifier)
          .digest("base64url"),
      });
      return { url, browserKey };
    },
    async finish({ state, code, browserKey }) {
      if (
        !config.enabled ||
        !/^[a-f0-9]{64}$/.test(state || "") ||
        !/^[a-f0-9]{64}$/.test(browserKey || "") ||
        typeof code !== "string" ||
        !code ||
        code.length > 4096
      )
        throw denied();
      // Atomic consumption prevents callback replay across server instances.
      const attempt = await repo.consumeGoogleAttempt(
        hash(state),
        hash(browserKey),
      );
      if (!attempt) throw denied();
      let claims;
      try {
        const { tokens } = await client.getToken({
          code,
          codeVerifier: attempt.verifier,
          redirect_uri: config.redirectUri,
        });
        const ticket = await client.verifyIdToken({
          idToken: tokens.id_token,
          audience: config.clientId,
        });
        claims = ticket.getPayload();
      } catch {
        throw denied();
      }
      const email = claims?.email?.toLowerCase();
      // Google is authoritative for Gmail and verified Workspace accounts.
      if (
        !claims?.sub ||
        claims.email_verified !== true ||
        claims.nonce !== attempt.nonce ||
        !(email?.endsWith("@gmail.com") || claims.hd) ||
        !config.emails.includes(email)
      )
        throw denied();
      // No registration: only a pre-existing, explicitly allowed admin can bind.
      const admin = await repo.bindGoogleAdmin(email, claims.sub);
      if (!admin) throw denied();
      const token = random(),
        csrf = random();
      await repo.purgeSessions();
      await repo.createSession(hash(token), admin.id, csrf, "google");
      return { token, csrf, email: admin.email };
    },
  };
}
