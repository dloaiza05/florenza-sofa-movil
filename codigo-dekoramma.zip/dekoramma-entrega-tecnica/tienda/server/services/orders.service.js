import { randomUUID } from "node:crypto";
import { hash } from "../security.js";
import { HttpError } from "../lib/http-error.js";
import { legalSnapshot } from "../legal-acceptance.js";
export function createOrdersService(repo) {
  return {
    async create(input) {
      const payloadHash = hash(
        JSON.stringify({ ...input, trackingToken: undefined }),
      );
      const previous = await repo.orderByKey(input.idempotencyKey);
      const repeat = (old) => {
        if (
          old.payload_hash !== payloadHash ||
          old.token_hash !== hash(input.trackingToken)
        )
          throw new HttpError(409, "La solicitud cambió. Vuelve a enviarla.");
        return {
          id: old.id,
          total: old.data.total,
          status: old.status,
          repeated: true,
        };
      };
      if (previous) return repeat(previous);
      const settings = await repo.settings();
      if (
        !settings.demo &&
        (!settings.legalName?.trim() || !settings.taxId?.trim())
      )
        throw new HttpError(
          409,
          "La tienda todavía está completando su información legal de venta.",
        );
      if (!settings.demo && settings.legalDraft !== false)
        throw new HttpError(
          409,
          "La tienda todavía está preparando sus condiciones de venta. Solicita asesoría.",
        );
      const legal = legalSnapshot(settings, await repo.publishedDocuments());
      if (!input.termsAccepted || input.legalFingerprint !== legal.fingerprint)
        throw new HttpError(
          409,
          "Las condiciones cambiaron. Actualiza la tienda y revísalas antes de enviar.",
        );
      if (!settings.paymentMethods.includes(input.method))
        throw new HttpError(400, "Selecciona una forma de pago disponible");
      const items = [];
      for (const item of input.items) {
        const p = await repo.product(item.id);
        if (!p?.active)
          throw new HttpError(409, "Un producto ya no está disponible");
        if (!p.colors.includes(item.color))
          throw new HttpError(400, "Color no disponible");
        items.push({
          id: p.id,
          name: p.name,
          color: item.color,
          quantity: item.quantity,
          price: p.price,
        });
      }
      const total = items.reduce((sum, p) => sum + p.price * p.quantity, 0),
        id = randomUUID();
      const data = {
        customer: input.customer,
        items,
        total,
        method: input.method,
        paymentStatus: "pendiente_de_confirmacion",
        shipping: "por_cotizar",
        demo: settings.demo,
        legalAcceptance: {
          ...legal,
          acceptedAt: new Date().toISOString(),
          termsAccepted: true,
          privacyConsent: input.customer.consent,
        },
      };
      try {
        await repo.createOrder(
          id,
          hash(input.trackingToken),
          input.idempotencyKey,
          payloadHash,
          data,
        );
      } catch (err) {
        if (err.code === "23505") {
          const duplicate = await repo.orderByKey(input.idempotencyKey);
          if (duplicate) return repeat(duplicate);
        }
        throw err;
      }
      return { id, total, status: "recibido" };
    },
    async track(id, token) {
      const row = await repo.track(id, hash(token));
      if (!row)
        throw new HttpError(404, "No encontramos esa solicitud con esa clave");
      return {
        id: row.id,
        status: row.status,
        created_at: row.created_at,
        total: row.data.total,
        items: row.data.items,
        paymentStatus: row.data.paymentStatus,
      };
    },
    async changeStatus(id, status) {
      if (!(await repo.setOrderStatus(id, status)))
        throw new HttpError(404, "Solicitud no encontrada");
      return { ok: true };
    },
  };
}
