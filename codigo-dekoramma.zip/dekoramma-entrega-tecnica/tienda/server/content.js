import { z } from "zod";
import { financeBanners } from "../src/finance-content.js";
import { welcomeDefaults } from "../src/welcome-banner.js";
const t = z.string().trim().min(1).max(4000),
  media = z
    .string()
    .max(500)
    .refine((s) => s === "" || /^\/(assets|uploads)\/[a-zA-Z0-9._-]+$/.test(s));
const bannerImage = media.refine(
  (s) => s === "" || /\.(png|jpe?g|webp)$/i.test(s),
  { message: "El banner debe ser una imagen PNG, JPG o WebP" },
);
const bannerVideo = media.refine(
  (s) => s === "" || /^\/uploads\/[a-zA-Z0-9._-]+\.mp4$/.test(s),
  { message: "Selecciona un MP4 validado desde administración" },
);
const optionalDate = z.union([
  z.literal(""),
  z.string().datetime({ offset: true }),
]);
export const welcomeSchema = z
  .object({
    enabled: z.boolean(),
    revision: z.number().int().min(1).max(999999),
    title: z.string().trim().min(1).max(90),
    text: z.string().trim().min(1).max(400),
    image: bannerImage.refine((s) => !!s),
    mobileImage: bannerImage.default(""),
    video: bannerVideo.default(""),
    imageAlt: z.string().trim().min(1).max(180),
    buttonText: z.string().trim().min(1).max(50),
    target: z.enum(["catalogo", "financiacion", "configurador", "contacto"]),
    startsAt: optionalDate.default(""),
    endsAt: optionalDate.default(""),
  })
  .refine(
    (b) =>
      !b.startsAt || !b.endsAt || Date.parse(b.endsAt) > Date.parse(b.startsAt),
    { message: "El cierre debe ser posterior al inicio" },
  );
export const campaignSchema = z
  .object({
    id: z
      .string()
      .min(1)
      .max(80)
      .regex(/^[a-zA-Z0-9_-]+$/)
      .refine((id) => id !== "home"),
    enabled: z.boolean(),
    simulation: z.literal(true),
    title: z.string().trim().min(1).max(90),
    text: z.string().trim().min(1).max(240),
    discountPercent: z.number().int().min(1).max(95),
    startsAt: z.string().datetime({ offset: true }),
    endsAt: z.string().datetime({ offset: true }),
    image: bannerImage.refine((s) => s.length > 0),
    mobileImage: bannerImage.default(""),
    video: bannerVideo.default(""),
    imageAlt: z.string().trim().min(1).max(180),
    category: z.enum([
      "Salas completas",
      "Esquineros",
      "Sofás cama",
      "Modulares",
      "Poltronas",
      "Reclinables",
      "Sofás",
      "Comedores",
      "Camas",
      "Colchones",
      "Bases cama",
    ]),
    buttonText: z.string().trim().min(1).max(40),
    terms: z.string().trim().min(1).max(2000),
  })
  .refine((c) => Date.parse(c.endsAt) > Date.parse(c.startsAt), {
    message: "El cierre debe ser posterior al inicio",
  });
export const contentSchema = z.object({
  welcomeBanner: welcomeSchema.default(welcomeDefaults),
  financeBanners: z
    .array(
      z
        .object({
          id: z.enum(["credit", "bank", "wallet"]),
          title: z.string().trim().min(1).max(90),
          text: z.string().trim().min(1).max(220),
          button: z.string().trim().min(1).max(50),
          image: bannerImage.default(""),
          mobileImage: bannerImage.default(""),
          video: bannerVideo.default(""),
          imageAlt: z.string().trim().max(180).default(""),
          visible: z.boolean().default(true),
        })
        .refine((b) => !(b.image || b.mobileImage || b.video) || !!b.imageAlt, {
          message: "Describe la imagen del banner",
          path: ["imageAlt"],
        })
        .refine((b) => !b.video || !!b.image, {
          message: "El video necesita una imagen de portada",
          path: ["image"],
        }),
    )
    .length(3)
    .refine((items) => new Set(items.map((x) => x.id)).size === 3)
    .default(financeBanners),
  campaigns: z
    .array(campaignSchema)
    .max(6)
    .refine((a) => new Set(a.map((c) => c.id)).size === a.length, {
      message: "Las campañas deben tener identificadores distintos",
    })
    .default([]),
  hero: z.object({ eyebrow: t, title: t, text: t, primary: t, secondary: t }),
  benefits: z
    .array(
      z.object({
        id: t,
        title: t,
        text: t,
        icon: z.enum(["factory", "ruler", "truck", "card", "cube"]),
        target: z.enum([
          "taller",
          "configurador",
          "envios",
          "financiacion",
          "espacio",
        ]),
      }),
    )
    .max(10),
  reels: z
    .array(
      z.object({ id: t, title: t, image: media, video: media, description: t }),
    )
    .max(12),
  gallery: z.array(z.object({ id: t, title: t, image: media })).max(12),
  faq: z.array(z.object({ id: t, title: t, text: t })).max(15),
  sections: z
    .array(
      z.object({
        id: z.enum([
          "catalogo",
          "reels",
          "configurador",
          "espacio",
          "financiacion",
          "taller",
          "galeria",
          "contacto",
        ]),
        title: t,
        subtitle: z.string().max(4000),
        visible: z.boolean(),
      }),
    )
    .length(8)
    .refine((a) => new Set(a.map((x) => x.id)).size === 8),
  workshop: z.object({
    image: media,
    text: t,
    steps: z
      .array(z.object({ title: t, text: t }))
      .min(1)
      .max(6),
  }),
  delivery: z.object({ text: t, cities: z.array(t).max(30) }),
  navigation: z.object({ drawer: z.boolean() }),
});
export const initialContent = {
  welcomeBanner: welcomeDefaults,
  financeBanners,
  campaigns: [
    {
      id: "semana-taller",
      enabled: true,
      simulation: true,
      title: "Más espacio para vivir juntos.",
      text: "Una sala a tu medida. Una nueva forma de disfrutar tu hogar.",
      discountPercent: 25,
      startsAt: "2026-09-11T00:00:00-05:00",
      endsAt: "2026-09-22T00:00:00-05:00",
      image: "/assets/sala-calida.png",
      imageAlt:
        "Sala modular clara con cojines petróleo y rosa, ambiente ilustrativo",
      category: "Salas completas",
      buttonText: "Explorar salas",
      terms:
        "Ejemplo de campaña para revisar el diseño. El porcentaje no se aplica al catálogo ni al carrito. Referencias, precios y condiciones comerciales pendientes de aprobación.",
    },
    {
      id: "modulares",
      enabled: true,
      simulation: true,
      title: "Cambia la forma de tu espacio.",
      text: "Módulos, telas y colores que se adaptan a tu vida.",
      discountPercent: 20,
      startsAt: "2026-09-11T00:00:00-05:00",
      endsAt: "2026-09-25T00:00:00-05:00",
      image: "/assets/sala-creativa.png",
      imageAlt: "Sofá modular petróleo en un ambiente ilustrativo",
      category: "Modulares",
      buttonText: "Descubrir modulares",
      terms:
        "Simulación visual de una promoción. Sin descuento aplicado al comprar. Requiere aprobación de productos, precios y condiciones antes de su activación comercial.",
    },
  ],
  hero: {
    eyebrow: "Fabricamos en Bogotá",
    title: "No la escogemos.\nLa fabricamos.",
    text: "Tú eliges la forma, la tela y el color.",
    primary: "Explorar salas",
    secondary: "Ver en mi espacio",
  },
  benefits: [
    {
      id: "fabrica",
      title: "Fábrica propia",
      text: "Hecho en Colombia",
      icon: "factory",
      target: "taller",
    },
    {
      id: "medida",
      title: "A tu medida",
      text: "Elige tela y color",
      icon: "ruler",
      target: "configurador",
    },
    {
      id: "envio",
      title: "Envíos a Colombia",
      text: "Consulta tu ciudad",
      icon: "truck",
      target: "envios",
    },
    {
      id: "credito",
      title: "Addi y Sistecrédito",
      text: "Consulta condiciones",
      icon: "card",
      target: "financiacion",
    },
    {
      id: "3d",
      title: "Mírala en 3D",
      text: "Antes de elegir",
      icon: "cube",
      target: "espacio",
    },
  ],
  reels: [
    {
      id: "cama",
      title: "De sofá a cama",
      image: "/assets/aurora.png",
      video: "",
      description:
        "Conoce las opciones de sofá cama y consulta cómo se transforma cada modelo.",
    },
    {
      id: "confort",
      title: "El confort",
      image: "/assets/nara.png",
      video: "",
      description:
        "Explora reclinables y elige con un asesor las medidas para tu espacio.",
    },
    {
      id: "oficio",
      title: "Así lo hacemos",
      image: "/assets/taller.png",
      video: "",
      description:
        "Nuestro taller adapta estructura, medidas y tapizado a tu proyecto.",
    },
    {
      id: "medida",
      title: "Tu sala a medida",
      image: "/assets/sala-creativa.png",
      video: "",
      description: "Combina módulos y telas para diseñar una sala a tu manera.",
    },
  ],
  gallery: [
    {
      id: "1",
      title: "Una sala para compartir",
      image: "/assets/sala-calida.png",
    },
    {
      id: "2",
      title: "Un espacio con carácter",
      image: "/assets/sala-industrial.png",
    },
    { id: "3", title: "Un rincón para ti", image: "/assets/rose.png" },
  ],
  faq: [
    {
      id: "medidas",
      title: "Medidas",
      text: "Confirmamos las medidas de tu espacio, los accesos y la configuración antes de fabricar.",
    },
    {
      id: "telas",
      title: "Telas",
      text: "Consulta las muestras disponibles. El tono puede variar según tu pantalla y la iluminación.",
    },
    {
      id: "garantia",
      title: "Garantía",
      text: "Solicita al asesor las condiciones escritas de garantía para tu producto.",
    },
  ],
  sections: [
    {
      id: "catalogo",
      title: "02. Encuentra tu sala",
      subtitle: "Hechas para vivirlas. Diseñadas para ti.",
      visible: true,
    },
    {
      id: "reels",
      title: "03. Míralos en acción",
      subtitle: "Conoce cada detalle",
      visible: true,
    },
    {
      id: "configurador",
      title: "04. Una sala que sí cabe y sí combina.",
      subtitle: "Confirmamos las medidas contigo.",
      visible: true,
    },
    {
      id: "espacio",
      title: "Mírala en tu espacio",
      subtitle: "Visualiza tu sala en 3D antes de decidir.",
      visible: true,
    },
    {
      id: "financiacion",
      title: "Paga como te sirva",
      subtitle: "Elige la opción que mejor se acomode a ti.",
      visible: true,
    },
    {
      id: "taller",
      title: "De nuestro taller a tu casa",
      subtitle:
        "Creamos cada sala con dedicación para que la disfrutes por años.",
      visible: true,
    },
    {
      id: "galeria",
      title: "Así se ven en casa",
      subtitle: "Ambientes ilustrativos de nuestra colección",
      visible: true,
    },
    {
      id: "contacto",
      title: "Ven a probar tu próxima sala",
      subtitle: "Te esperamos para encontrar tu sala.",
      visible: true,
    },
  ],
  workshop: {
    image: "/assets/taller.png",
    text: "Diseñamos contigo, fabricamos en nuestro taller y coordinamos la entrega hasta tu hogar.",
    steps: [
      { title: "Diseñamos", text: "Tu espacio, tus ideas" },
      { title: "Fabricamos", text: "Materiales y manos expertas" },
      { title: "Entregamos", text: "Hasta la puerta de tu hogar" },
    ],
  },
  delivery: {
    text: "Coordinamos tu entrega según dirección, acceso y disponibilidad. El costo se confirma antes de comprar.",
    cities: ["Bogotá y Soacha", "Cundinamarca y Meta", "Resto de Colombia"],
  },
  navigation: { drawer: false },
};
