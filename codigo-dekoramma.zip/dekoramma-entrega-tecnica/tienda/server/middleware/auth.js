import { cookie } from "../security.js";
import { HttpError } from "../lib/http-error.js";
export const authenticate = (service) => async (req, res, next) => {
  req.session = await service.session(cookie(req, "dk_session"));
  if (
    !["GET", "HEAD"].includes(req.method) &&
    req.headers["x-csrf-token"] !== req.session.csrf
  )
    throw new HttpError(403, "Actualiza la sesión");
  next();
};
