import { Router } from "express";
import { rateLimit } from "express-rate-limit";

// Mitigation for repetitive downloads, not a promise of copy prevention.
export function mediaProtection({ limit = 600, windowMs = 60000 } = {}) {
  const router = Router();
  router.use((req, res, next) => {
    const site = req.get("Sec-Fetch-Site");
    const dest = req.get("Sec-Fetch-Dest");
    // Keep direct opening, search crawlers and native AR/model downloads working.
    if (site === "cross-site" && ["image", "video", "audio"].includes(dest)) {
      res.set("Cache-Control", "no-store");
      return res.status(403).end();
    }
    next();
  });
  router.use(
    rateLimit({
      windowMs,
      limit,
      standardHeaders: "draft-8",
      legacyHeaders: false,
      handler(req, res) {
        res.set("Cache-Control", "no-store");
        res
          .status(429)
          .json({
            error:
              "Se alcanzó el límite temporal de descargas. Intenta nuevamente en un minuto.",
          });
      },
    }),
  );
  return router;
}
