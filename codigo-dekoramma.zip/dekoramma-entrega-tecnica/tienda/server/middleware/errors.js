import { z } from "zod";
import multer from "multer";
import { HttpError } from "../lib/http-error.js";
export function handleError(err, req, res, next) {
  if (err instanceof z.ZodError)
    return res.status(400).json({
      error: "Revisa los campos del formulario",
      fields: err.issues.map((x) => ({
        field: x.path.join("."),
        message: x.message,
      })),
    });
  if (err instanceof multer.MulterError)
    return res.status(400).json({
      error:
        "Archivo no admitido o demasiado grande. Máximo " +
        (req.originalUrl.startsWith("/api/admin/documents") ? "20" : "100") +
        " MB.",
    });
  if (err instanceof HttpError)
    return res.status(err.status).json({ error: err.message });
  if (err.status === 400)
    return res.status(400).json({ error: "Solicitud inválida" });
  // Keep diagnostic categories without request bodies, secrets or SQL values.
  console.error(
    JSON.stringify({
      event: "request_failed",
      method: req.method,
      category: err instanceof TypeError ? "type_error" : "internal_error",
    }),
  );
  res
    .status(500)
    .json({ error: "No pudimos completar la operación. Intenta de nuevo." });
}
