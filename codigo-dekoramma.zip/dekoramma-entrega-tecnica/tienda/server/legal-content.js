// Borradores originales para aprobación comercial y jurídica antes de publicar ventas.
export const legalDefaults = {
  legalName: "",
  taxId: "",
  registration: "",
  legalDraft: true,
  legalVersion: "Borrador v1 · 11/09/2026",
  terms: `1. Quién te atiende
Dekoramma · Estilo y arte es la marca comercial de la tienda ubicada en Calle 59C Sur #89A-22, Bosa, Bogotá D. C. La razón social o nombre del comerciante y el NIT deben completarse antes de abrir ventas. Atención: dekoramma@gmail.com y WhatsApp 3163072132.

2. Antes de confirmar tu compra
Revisa la referencia, cantidad, color, medidas, materiales, tipo de patas y disponibilidad. La confirmación comercial debe indicar el precio total, impuestos aplicables, costo de envío, servicios adicionales y fecha o plazo de entrega. Si el mueble es a medida, la cotización debe incluir un resumen de las especificaciones aprobadas.

3. Solicitud, pago y fabricación
En esta versión del sitio el botón de compra registra una solicitud para atención; no ejecuta un cobro ni aprueba un crédito. El inicio de fabricación, anticipo, saldo y condiciones de pago deberán quedar acordados por escrito en la cotización. No se presumirán aceptadas modificaciones de diseño o precio que no hayas confirmado.

4. Fotografías y personalización
Las fotografías y modelos 3D facilitan la elección. La pantalla y la iluminación pueden alterar la percepción del color; solicita una muestra cuando el acabado sea decisivo. La referencia contratada y sus especificaciones acordadas deben corresponder al producto entregado. Un aviso sobre variaciones visuales no elimina tus derechos por información o productos que no correspondan.

5. Entrega
Indica dirección, ciudad y condiciones de acceso: puertas, ascensor, escaleras y restricciones del edificio. La tienda debe confirmar cobertura, costo, armado y plazo antes de cerrar la compra. No se promete envío gratuito ni cobertura inmediata sin esa confirmación. Comunica cualquier novedad de entrega mediante los canales de atención y conserva la referencia de tu solicitud.

6. Cambios, cancelaciones y reclamos
La garantía, el retracto, la reversión de pago y los cambios comerciales son trámites diferentes. Las condiciones particulares no pueden suprimir derechos obligatorios. Consulta las secciones específicas de este centro y solicita por escrito cualquier cambio en un pedido a medida antes de su fabricación.

7. Alcance del borrador
Este texto es una propuesta para revisión. Antes de publicarlo deben completarse la identificación del vendedor, las reglas de anticipos, entrega, aceptación del pedido, facturación y cambios comerciales. La fecha y versión definitivas deben quedar visibles.`,
  warranty: `1. Compra con información clara
Cada ficha y comprobante de compra deben identificar el producto y sus condiciones de garantía. La duración por estructura, tapizado, mecanismos, colchones y demás componentes queda pendiente de confirmar con Dekoramma. No se trasladan al negocio los plazos anunciados por otra tienda.

2. Cómo solicitar atención
Escribe a dekoramma@gmail.com o al WhatsApp 3163072132 e indica tu nombre, referencia del producto, fecha aproximada de compra, descripción de la falla y un medio de contacto. Puedes aportar fotografías o video para facilitar el diagnóstico. Si no tienes la factura a mano, la tienda revisará otros medios que permitan identificar la compra; no se presenta la factura como el único soporte admisible.

3. Revisión y solución
La tienda deberá registrar la solicitud, explicar cómo se revisará el producto y comunicar la solución aplicable. La reparación, cambio o devolución se determinarán conforme a la garantía legal y a las circunstancias del caso. No se condiciona el ejercicio de derechos a pagos o exclusiones generales que desconozcan la ley.

4. Uso y cuidado
Conserva las instrucciones entregadas con el mueble. Antes de aplicar químicos o desmontar mecanismos, consulta el cuidado adecuado para esa tela o material. El desgaste, el uso indebido y las intervenciones requieren evaluación concreta; no se presume que cualquier marca o daño excluya automáticamente la garantía.

5. Información por completar
La tienda debe aprobar la tabla de cobertura por categoría, el canal de radicación, las instrucciones de cuidado, el procedimiento de recogida y los responsables de responder. Esta propuesta no crea una garantía comercial extendida ni reemplaza la garantía legal.`,
  privacy: `1. Responsable y contacto
El responsable del tratamiento será la persona o empresa que opere Dekoramma; su nombre legal y NIT deben incorporarse antes de publicar esta política. Canal propuesto para consultas y reclamos: dekoramma@gmail.com. Dirección comercial: Calle 59C Sur #89A-22, Bosa, Bogotá D. C.

2. Datos y finalidades
La tienda solicita nombre, teléfono, correo, ciudad, dirección de entrega y datos de la solicitud para responder cotizaciones, gestionar pedidos y atender novedades. Recoge solo información necesaria. La autorización para atender una compra no debe utilizarse como autorización automática para campañas publicitarias; cualquier finalidad adicional debe informarse y contar con la base correspondiente.

3. Ubicación y cámara
La ubicación del dispositivo solo se solicita cuando eliges compartirla para una entrega. La pantalla actual prepara un enlace y un mensaje que tú revisas antes de enviarlo. La función de realidad aumentada requiere permiso del dispositivo y no implementa grabación ni envío de fotografías del hogar a la tienda.

4. Proveedores y seguridad
El alojamiento, transportadores o proveedores de pago podrán requerir datos estrictamente relacionados con su función cuando esas integraciones se activen. Antes de publicar se documentarán los encargados, transferencias aplicables, medidas de protección y período de conservación. Esta versión no captura números completos de tarjeta ni claves bancarias.

5. Tus derechos
Puedes solicitar conocer, actualizar o rectificar tus datos, consultar su uso, pedir prueba de autorización y solicitar revocatoria o supresión cuando proceda. Envía tu solicitud al canal indicado, con información suficiente para verificar tu identidad y explicar lo que necesitas. Se atenderá dentro de los términos legales aplicables; no necesitas enviar documentos sensibles por canales públicos.

6. Almacenamiento del navegador
La tienda usa una cookie de sesión para el administrador y almacenamiento local para la bolsa y la referencia privada de seguimiento. No se ha incorporado una herramienta de publicidad comportamental en esta versión. Si se agregan analítica o publicidad, deberá actualizarse la información y la gestión de consentimientos que corresponda.

7. Pendientes de aprobación
Completar responsable legal, encargados reales, retención, procedimiento de derechos y versión de la política. Esta propuesta requiere revisión antes de recolectar datos de clientes en producción.`,
  withdrawal: `Derecho de retracto
En las ventas a distancia a las que les aplica, el retracto puede ejercerse dentro de los cinco días hábiles siguientes a la entrega del bien. Existen excepciones legales, entre ellas determinados bienes confeccionados conforme a especificaciones del consumidor o claramente personalizados. Esa excepción no elimina la garantía por defectos ni permite clasificar automáticamente todo el catálogo como personalizado.

Para solicitarlo, escribe a dekoramma@gmail.com e identifica la compra y tu intención de ejercer el derecho. La tienda indicará el procedimiento de devolución y los datos necesarios. Para comercio electrónico, la devolución de dinero no debe exceder quince días calendario una vez ejercido el derecho y cumplidas las obligaciones de devolución del producto y entrega de los datos correctos requeridos, según la regulación vigente. Deben respetarse las condiciones legales sobre devolución y costos aplicables.

Reversión de pago
Es un mecanismo distinto, previsto para determinados pagos electrónicos y situaciones legales como operaciones no solicitadas, fraude o problemas con el producto o su entrega. Su trámite involucra al proveedor y al emisor del instrumento de pago dentro de los plazos aplicables. Al activar la pasarela, esta sección deberá indicar el procedimiento operativo concreto y los canales correspondientes.

Este borrador debe verificarse con las condiciones de venta definitivas. No impone renuncias generales ni sustituye la evaluación de cada caso.`,
  documentation: `Para verificar la identidad comercial puedes solicitar la información tributaria y de registro al correo de la tienda. Indica si necesitas RUT, certificado de Cámara de Comercio o datos para facturación, y el propósito de la solicitud. Dekoramma revisará qué documento corresponde y compartirá una versión adecuada por un canal privado.

La razón social o nombre del comerciante, NIT, dirección y contacto deben estar visibles una vez confirmados. Como criterio de privacidad, no se publicarán automáticamente copias completas de documentos con firmas, identificaciones o datos personales adicionales. No se presenta esta pantalla como certificación de registro ni se afirma contar con documentos que todavía no han sido aportados.`,
};
export const legalSections = [
  ["terms", "Términos y condiciones", "terminos"],
  ["warranty", "Garantías y cuidado", "garantias"],
  ["privacy", "Política de privacidad", "privacidad"],
  ["withdrawal", "Derecho de retracto y reversión", "retracto"],
  ["documentation", "Verificación comercial", "documentos"],
];
