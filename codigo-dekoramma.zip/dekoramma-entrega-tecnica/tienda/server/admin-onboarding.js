import "dotenv/config";
import { openDatabase } from "./db.js";
import { passwordHash } from "./security.js";
import { randomUUID } from "node:crypto";
import fs from "node:fs/promises";
import readline from "node:readline/promises";
import { z } from "zod";

function hiddenPassword(prompt) {
  if (!process.stdin.isTTY)
    throw Error("Usa un terminal interactivo o ADMIN_PASSWORD_FILE.");
  process.stdout.write(prompt);
  return new Promise((resolve, reject) => {
    let value = "";
    process.stdin.setRawMode(true);
    process.stdin.resume();
    const finish = () => {
      process.stdin.off("data", onData);
      process.stdin.setRawMode(false);
      process.stdin.pause();
      process.stdout.write("\n");
    };
    function onData(chunk) {
      for (const char of chunk.toString("utf8")) {
        if (char === "\u0003") {
          finish();
          reject(Error("Operación cancelada"));
          return;
        }
        if (char === "\r" || char === "\n") {
          finish();
          resolve(value);
          return;
        }
        if (char === "\u007f" || char === "\b") value = value.slice(0, -1);
        else if (char >= " ") value += char;
      }
    }
    process.stdin.on("data", onData);
  });
}
async function main() {
  if (process.env.NODE_ENV === "production" && !process.env.DATABASE_URL)
    throw Error("Producción requiere PostgreSQL.");
  let email = process.env.ADMIN_EMAIL;
  if (!email) {
    if (!process.stdin.isTTY)
      throw Error("Indica ADMIN_EMAIL o usa un terminal interactivo.");
    const input = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
    });
    email = await input.question("Correo del administrador: ");
    input.close();
  }
  email = z.email().max(150).parse(email.trim().toLowerCase());
  const db = await openDatabase();
  try {
    if (
      (await db.query("SELECT id FROM admins WHERE email=$1", [email])).rows
        .length
    ) {
      console.log("La cuenta ya existe; no se modificó.");
      return;
    }
    let password;
    if (process.env.ADMIN_PASSWORD_FILE)
      password = (
        await fs.readFile(process.env.ADMIN_PASSWORD_FILE, "utf8")
      ).replace(/\r?\n$/, "");
    else {
      password = await hiddenPassword(
        "Contraseña (mínimo 14 caracteres, entrada oculta): ",
      );
      if (password !== (await hiddenPassword("Repite la contraseña: ")))
        throw Error("Las contraseñas no coinciden.");
    }
    if (password.length < 14 || password.length > 200)
      throw Error("La contraseña debe tener entre 14 y 200 caracteres.");
    await db.query(
      "INSERT INTO admins(id,email,password_hash) VALUES($1,$2,$3)",
      [randomUUID(), email, passwordHash(password)],
    );
    password = undefined;
    console.log(
      "Administrador creado. La contraseña no se imprimió ni se guardó en un archivo.",
    );
  } finally {
    await db.close();
  }
}
main().catch(() => {
  console.error(
    "No se completó el alta. Revisa los datos, PostgreSQL y el método de entrada.",
  );
  process.exitCode = 1;
});
