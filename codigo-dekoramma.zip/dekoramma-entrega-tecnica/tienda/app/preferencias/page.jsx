import MarketingPreferences from '../../src/MarketingPreferences';
export const metadata={title:'Preferencias de contacto · Dekoramma',robots:{index:false,follow:false}};
export default function Page(){return <MarketingPreferences/>;}
