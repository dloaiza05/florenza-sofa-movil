import LegalCenter from "../../src/LegalCenter";
export const metadata = {
  title: "Información, garantías y privacidad | Dekoramma",
};
export default function InformationPage() {
  return <LegalCenter />;
}
