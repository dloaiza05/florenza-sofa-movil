import Store from "../src/main";
export default async function Page() {
  let initialData = null;
  try {
    const res = await fetch(
      "http://127.0.0.1:" + (process.env.PORT || 8790) + "/api/catalog",
      { cache: "no-store" },
    );
    if (res.ok) initialData = await res.json();
  } catch {}
  return <Store initialData={initialData} />;
}
