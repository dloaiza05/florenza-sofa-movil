import "../src/style.css";
export const metadata = {
  title: "Dekoramma | Salas hechas en nuestro taller",
  description:
    "Salas modulares a tu medida. Explora el catálogo, configura tu sala y visualízala en 3D.",
};
export const dynamic = "force-dynamic";
export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
