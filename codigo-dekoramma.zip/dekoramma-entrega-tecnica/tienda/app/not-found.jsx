export default function NotFound() {
  return (
    <main className="loading">
      <h1>Página no encontrada</h1>
      <a href="/">Volver a Dekoramma</a>
    </main>
  );
}
