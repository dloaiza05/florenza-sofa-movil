export const metadata = {
  title: "Administración | Dekoramma",
  robots: { index: false, follow: false },
};
export default function AdminLayout({ children }) {
  return children;
}
