import Admin from "../../../src/Admin";
export const metadata = {
  title: "Demostración del administrador | Dekoramma",
  robots: { index: false, follow: false },
};
export default function Preview() {
  return <Admin preview />;
}
