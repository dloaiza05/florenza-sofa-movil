export { default } from "../../src/Admin";
