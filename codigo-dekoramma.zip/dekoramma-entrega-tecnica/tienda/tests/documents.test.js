import {test} from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs/promises';import os from 'node:os';import path from 'node:path';import {randomUUID} from 'node:crypto';
import {PDFDocument,PDFName,PDFString} from 'pdf-lib';
import {openDatabase} from '../server/db.js';import {seed} from '../server/seed.js';import {createApp} from '../server/app.js';import {passwordHash,random} from '../server/security.js';
test('PDFs: versiones inmutables, estados, registro y privacidad tributaria',async()=>{
 const db=await openDatabase({url:'',dir:'memory://'});await seed(db);const password=random();await db.query('INSERT INTO admins(id,email,password_hash) VALUES($1,$2,$3)',[randomUUID(),'documents@example.com',passwordHash(password)]);
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'dekoramma-documents-'));
 const server=createApp(db,{documentDir:dir}).listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));const base='http://127.0.0.1:'+server.address().port;
 try{
  assert.equal((await fetch(base+'/api/admin/documents')).status,401);
  const login=await fetch(base+'/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:'documents@example.com',password})});
  const cookie=login.headers.get('set-cookie').split(';')[0],csrf=(await login.json()).csrf,headers={Cookie:cookie,'X-CSRF-Token':csrf};
  const pdf=await PDFDocument.create();pdf.addPage().drawText('Documento de prueba aislada');const bytes=await pdf.save();
  async function upload(category,year=2026,buffer=bytes){const form=new FormData();form.append('file',new Blob([buffer]),'document.pdf');form.append('title','Documento de prueba');form.append('category',category);form.append('year',year);return fetch(base+'/api/admin/documents',{method:'POST',headers,body:form});}
  const first=await upload('terms');assert.equal(first.status,201,await first.clone().text());const a=await first.json();
  const b=await (await upload('terms')).json();assert.equal(b.version,2);assert.notEqual(a.id,b.id);
  const previousYear=await (await upload('terms',2025)).json();assert.equal(previousYear.version,1);
  const change=(id,status)=>fetch(base+'/api/admin/documents/'+id,{method:'PATCH',headers:{...headers,'Content-Type':'application/json'},body:JSON.stringify({status})});
  assert.equal((await fetch(base+'/api/documents/'+a.id+'/file')).status,404);
  assert.equal((await change(a.id,'published')).status,409);
  assert.equal((await change(a.id,'approved')).status,200);
  assert.equal((await change(a.id,'published')).status,200);
  const publicFile=await fetch(base+'/api/documents/'+a.id+'/file');assert.equal(publicFile.status,200);assert.match(publicFile.headers.get('content-type'),/application\/pdf/);assert.deepEqual(Buffer.from(await publicFile.arrayBuffer()),Buffer.from(bytes));
  const rut=await (await upload('rut')).json();assert.equal((await change(rut.id,'approved')).status,200);assert.equal((await change(rut.id,'published')).status,400);
  assert.equal((await fetch(base+'/api/documents/'+rut.id+'/file')).status,404);
  const publicData=await (await fetch(base+'/api/documents')).json();assert.equal(publicData.documents.length,1);assert.equal(publicData.documents[0].created_by,undefined);
  assert.equal((await change(a.id,'archived')).status,200);assert.equal((await fetch(base+'/api/documents/'+a.id+'/file')).status,404);
  assert.equal((await fetch(base+'/api/admin/documents/'+a.id+'/file',{headers})).status,200);
  assert.equal((await upload('rut',2026,Buffer.from('not a PDF'))).status,400);
  const active=await PDFDocument.create();active.addPage();active.catalog.set(PDFName.of('OpenAction'),active.context.obj({S:PDFName.of('JavaScript'),JS:PDFString.of('app.alert(1)')}));assert.equal((await upload('other',2026,await active.save())).status,400);
  const history=await (await fetch(base+'/api/admin/documents',{headers})).json();assert.equal(history.documents.length,4);assert.equal(history.events.length,8);assert.ok(history.events.every(x=>x.actor==='documents@example.com'&&x.created_at));
 }finally{await new Promise(r=>server.close(r));await db.close();if(path.basename(dir).startsWith('dekoramma-documents-')&&path.dirname(dir)===os.tmpdir())await fs.rm(dir,{recursive:true,force:true});}
});
