import { test } from "node:test";
import assert from "node:assert/strict";
import {
  mapSearch,
  storeDirections,
  storeShare,
  deliveryDraft,
} from "../src/locations.js";
const settings = {
  storeName: "Dekoramma",
  phone: "573163072132",
  address: "Calle 59C Sur #89A-22, Bogotá",
  mapsPlaceId: "",
};
test("Mapa y ruta codifican la dirección completa, incluido el numeral", () => {
  const route = new URL(storeDirections(settings));
  assert.equal(route.searchParams.get("destination"), settings.address);
  assert.equal(route.hash, "");
  assert.equal(route.searchParams.get("api"), "1");
  const shared = new URL(storeShare(settings));
  assert.match(shared.searchParams.get("text"), /Calle 59C Sur/);
  assert.match(shared.searchParams.get("text"), /google.com\/maps/);
});
test("WhatsApp de entrega utiliza el contacto de tienda y la ubicación elegida", () => {
  const draft = deliveryDraft(settings, {
      address: "Carrera 10 #20-30, Bogotá",
    }),
    url = new URL(draft.url);
  assert.equal(url.pathname, "/573163072132");
  assert.ok(url.searchParams.get("text").includes("Carrera 10 #20-30, Bogotá"));
  const coordinateDraft = deliveryDraft(settings, {
    coordinates: { latitude: 4.6, longitude: -74.1 },
  });
  assert.equal(
    new URL(coordinateDraft.map).searchParams.get("query"),
    "4.600000,-74.100000",
  );
  assert.equal(
    new URL(mapSearch(settings.address, "ConfirmedPlaceID")).searchParams.get(
      "query_place_id",
    ),
    "ConfirmedPlaceID",
  );
});
