import test from "node:test";
import assert from "node:assert/strict";
import { productPhoto } from "../src/product-photo.js";
test("Compra: la foto coincide con el color o se identifica como referencia", () => {
  const product = {
    name: "Sala",
    image: "/assets/cover.png",
    gallery: [{ url: "/uploads/rosa.webp", color: "Rosa", alt: "Sala rosa" }],
    colorImages: [{ url: "/uploads/gris.webp", color: "Gris" }],
  };
  assert.deepEqual(productPhoto(product, "Rosa"), {
    url: "/uploads/rosa.webp",
    alt: "Sala rosa",
    matched: true,
  });
  assert.equal(productPhoto(product, "Gris").url, "/uploads/gris.webp");
  assert.equal(productPhoto(product, "Azul").matched, false);
  assert.match(productPhoto(product, "Azul").alt, /referencia/);
  assert.equal(productPhoto(product, "Azul").url, product.image);
  assert.equal(productPhoto(undefined, "Azul").url, "");
});
