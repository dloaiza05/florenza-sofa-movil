import { test } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { openDatabase } from "../server/db.js";
import { seed } from "../server/seed.js";
import { createApp } from "../server/app.js";
import { random, passwordHash, hash } from "../server/security.js";
test("Permisos: opt-in explícito, canales mínimos, registro privado y retiro de duplicados", async () => {
  const db = await openDatabase({ url: "", dir: "memory://" });
  await seed(db);
  const password = random();
  await db.query(
    "INSERT INTO admins(id,email,password_hash) VALUES($1,$2,$3)",
    [randomUUID(), "consent@example.test", passwordHash(password)],
  );
  const server = createApp(db).listen(0, "127.0.0.1");
  await new Promise((r) => server.once("listening", r));
  const base = "http://127.0.0.1:" + server.address().port;
  const post = (url, body) =>
    fetch(base + "/api" + url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
  try {
    const catalog = await (await fetch(base + "/api/catalog")).json();
    const input = {
      name: "Prueba aislada",
      email: "persona@example.test",
      phone: "3001234567",
      channels: ["email"],
      consent: true,
      legalFingerprint: catalog.legalFingerprint,
    };
    assert.equal(
      (await post("/marketing", { ...input, consent: false })).status,
      400,
    );
    assert.equal(
      (await post("/marketing", { ...input, email: "" })).status,
      400,
    );
    assert.equal(
      (await post("/marketing", { ...input, legalFingerprint: "0".repeat(64) }))
        .status,
      409,
    );
    const first = await post("/marketing", input);
    assert.equal(first.status, 201, await first.clone().text());
    const result = await first.json();
    const token = result.managementPath.split("#")[1];
    assert.equal(result.status, "pending_verification");
    const stored = (
      await db.query("SELECT * FROM marketing_contacts WHERE id=$1", [
        result.id,
      ])
    ).rows[0];
    assert.equal(stored.token_hash, hash(token));
    assert.equal(stored.data.phone, "");
    assert.equal(stored.data.identityVerified, false);
    assert.ok(stored.data.consent.privacy);
    assert.equal(stored.data.consent.fingerprint, catalog.legalFingerprint);
    const duplicate = await post("/marketing", {
      ...input,
      email: "PERSONA@example.test",
    });
    assert.equal(duplicate.status, 201);
    assert.equal((await fetch(base + "/api/admin/marketing")).status, 401);
    assert.equal(
      (await post("/marketing/withdraw", { token: random() })).status,
      200,
    );
    assert.equal(
      (
        await db.query(
          "SELECT count(*) AS n FROM marketing_contacts WHERE status='withdrawn'",
        )
      ).rows[0].n,
      0,
    );
    assert.equal((await post("/marketing/withdraw", { token })).status, 200);
    assert.equal(
      (
        await db.query(
          "SELECT count(*) AS n FROM marketing_contacts WHERE status='withdrawn'",
        )
      ).rows[0].n,
      2,
    );
    await post("/marketing/withdraw", { token });
    assert.equal(
      (await db.query("SELECT count(*) AS n FROM marketing_events")).rows[0].n,
      4,
    );
    const login = await post("/login", {
      email: "consent@example.test",
      password,
    });
    const cookie = login.headers.get("set-cookie").split(";")[0];
    const admin = await (
      await fetch(base + "/api/admin/marketing", {
        headers: { Cookie: cookie },
      })
    ).json();
    assert.equal(admin.contacts.length, 2);
    assert.equal(JSON.stringify(admin).includes(token), false);
    assert.equal(JSON.stringify(admin).includes(stored.token_hash), false);
    const pending = await (
      await post("/marketing", { ...input, email: "otra-persona@example.test" })
    ).json();
    const withdrawUrl =
      base + "/api/admin/marketing/" + pending.id + "/withdraw";
    const withdrawal = {
      method: "POST",
      headers: { Cookie: cookie, "Content-Type": "application/json" },
      body: JSON.stringify({
        reason: "Solicitud del titular por correo, referencia de prueba.",
      }),
    };
    assert.equal((await fetch(withdrawUrl, withdrawal)).status, 403);
    const csrf = (await login.json()).csrf;
    assert.equal(
      (
        await fetch(withdrawUrl, {
          ...withdrawal,
          headers: { ...withdrawal.headers, "X-CSRF-Token": csrf },
        })
      ).status,
      200,
    );
    const event = (
      await db.query(
        "SELECT details FROM marketing_events WHERE contact_id=$1 AND action='withdrawn'",
        [pending.id],
      )
    ).rows[0];
    assert.equal(event.details.actor, "consent@example.test");
    assert.equal(event.details.source, "admin_request");
    const advice = await post("/leads", {
      name: "Asesoría aislada",
      phone: "3001234567",
      city: "Bogotá",
      message: "Quiero una cita",
      consent: true,
      type: "asesoria",
      contactChannel: "email",
      email: "cita@example.test",
      preferredDate: "2026-09-25",
      preferredTime: "afternoon",
      legalFingerprint: catalog.legalFingerprint,
    });
    assert.equal(advice.status, 201, await advice.clone().text());
    const lead = (await db.query("SELECT data FROM leads")).rows[0].data;
    assert.equal(lead.marketingConsent, false);
    assert.equal(lead.contactConsent.channel, "email");
    assert.ok(lead.contactConsent.acceptedAt);
    assert.equal(
      (await db.query("SELECT count(*) AS n FROM marketing_contacts")).rows[0]
        .n,
      3,
    );
  } finally {
    await new Promise((r) => server.close(r));
    await db.close();
  }
});
