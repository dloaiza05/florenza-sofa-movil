import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { openDatabase } from "../server/db.js";
import { seed } from "../server/seed.js";
import { createApp } from "../server/app.js";
import { passwordHash, random } from "../server/security.js";
let db, server, base, tmp, session, csrf, catalog;
const password = random();
async function request(
  url,
  { method = "GET", body, admin = false, headers = {} } = {},
) {
  const r = await fetch(base + url, {
    method,
    headers: {
      ...(body && !(body instanceof FormData)
        ? { "Content-Type": "application/json" }
        : {}),
      ...(admin ? { Cookie: session, "X-CSRF-Token": csrf } : {}),
      ...headers,
    },
    body:
      body instanceof FormData ? body : body ? JSON.stringify(body) : undefined,
  });
  return { status: r.status, body: await r.json(), headers: r.headers };
}
before(async () => {
  db = await openDatabase({ url: "", dir: "memory://" });
  await seed(db);
  await db.query(
    "INSERT INTO admins(id,email,password_hash) VALUES($1,$2,$3)",
    [randomUUID(), "test@example.com", passwordHash(password)],
  );
  tmp = await fs.mkdtemp(path.join(os.tmpdir(), "dekoramma-test-"));
  server = createApp(db, { uploadDir: tmp }).listen(0, "127.0.0.1");
  await new Promise((resolve) => server.once("listening", resolve));
  base = "http://127.0.0.1:" + server.address().port;
  catalog = (await request("/api/catalog")).body;
});
after(async () => {
  await new Promise((resolve) => server.close(resolve));
  await db.close();
  await fs.rm(tmp, { recursive: true, force: true });
});
test("Google: configuración privada, acceso cerrado y callback inválido sin sesión", async () => {
  const options = await request("/api/auth/options");
  assert.deepEqual(options.body, { google: false });
  assert.equal((await request("/api/auth/google/start")).status, 503);
  const callback = await fetch(base + "/api/auth/google/callback?state=invalid&code=invalid", { redirect: "manual" });
  assert.equal(callback.status, 303);
  assert.equal(callback.headers.get("location"), "/admin?acceso=no-autorizado");
  assert.ok(!callback.headers.get("set-cookie").includes("dk_session"));
});

test("Administración: exige sesión, valida contraseña y CSRF", async () => {
  assert.equal((await request("/api/admin/data")).status, 401);
  assert.equal(
    (
      await request("/api/login", {
        method: "POST",
        body: { email: "test@example.com", password: "incorrecta" },
      })
    ).status,
    401,
  );
  const login = await request("/api/login", {
    method: "POST",
    body: { email: "test@example.com", password },
  });
  assert.equal(login.status, 200);
  session = login.headers.get("set-cookie").split(";")[0];
  csrf = login.body.csrf;
  assert.ok(login.headers.get("set-cookie").includes("HttpOnly"));
  assert.equal(
    (await request("/api/admin/me", { admin: true })).body.email,
    "test@example.com",
  );
  assert.equal(
    (
      await request("/api/admin/settings", {
        method: "PUT",
        body: catalog.settings,
        headers: { Cookie: session },
      })
    ).status,
    403,
  );
  assert.equal(
    (
      await request("/api/admin/settings", {
        method: "PUT",
        body: catalog.settings,
        admin: true,
        headers: { Origin: "https://foreign.example" },
      })
    ).status,
    403,
  );
});
test("Contenido y productos se guardan y aparecen en la tienda", async () => {
  const content = structuredClone(catalog.content);
  content.hero.title = "Título editado por la tienda";
  content.welcomeBanner.video = "/uploads/bienvenida.mp4";
  content.welcomeBanner.enabled = false;
  content.welcomeBanner.revision = 3;
  content.sections.reverse();
  content.sections.find((x) => x.id === "reels").visible = false;
  content.financeBanners.reverse();
  Object.assign(content.financeBanners[0], {
    image: "/assets/sala-calida.png",
    mobileImage: "/uploads/banner-mobile.webp",
    imageAlt: "Campaña de prueba",
    visible: false,
  });
  content.campaigns.reverse();
  content.campaigns[0].mobileImage = "/uploads/campana-mobile.webp";
  assert.equal(
    (
      await request("/api/admin/content", {
        method: "PUT",
        body: content,
        admin: true,
      })
    ).status,
    200,
  );
  assert.equal(
    (await request("/api/catalog")).body.content.hero.title,
    content.hero.title,
  );
  const invalid = structuredClone(content);
  const published = (await request("/api/catalog")).body.content;
  assert.equal(published.welcomeBanner.video, "/uploads/bienvenida.mp4");
  assert.equal(published.welcomeBanner.enabled, false);
  assert.equal(published.welcomeBanner.revision, 3);
  assert.deepEqual(
    published.financeBanners.map((x) => x.id),
    content.financeBanners.map((x) => x.id),
  );
  assert.equal(published.financeBanners[0].visible, false);
  assert.equal(
    published.financeBanners[0].mobileImage,
    "/uploads/banner-mobile.webp",
  );
  assert.equal(published.financeBanners[0].imageAlt, "Campaña de prueba");
  assert.equal(
    published.campaigns[0].mobileImage,
    "/uploads/campana-mobile.webp",
  );
  invalid.sections[0].id = invalid.sections[1].id;
  assert.equal(
    (
      await request("/api/admin/content", {
        method: "PUT",
        body: invalid,
        admin: true,
      })
    ).status,
    400,
  );
  const product = {
    ...catalog.products[0],
    id: "nuevo-modelo",
    price: 1999000,
  };
  assert.equal(
    (
      await request("/api/admin/products/nuevo-modelo", {
        method: "PUT",
        body: product,
        admin: true,
      })
    ).status,
    200,
  );
  assert.equal(
    (await request("/api/catalog")).body.products.find(
      (x) => x.id === "nuevo-modelo",
    ).price,
    1999000,
  );
  assert.equal(
    (
      await request("/api/admin/products/nuevo-modelo", {
        method: "DELETE",
        admin: true,
      })
    ).status,
    200,
  );
  assert.equal(
    (await request("/api/catalog")).body.products.some(
      (x) => x.id === "nuevo-modelo",
    ),
    false,
  );
});
test("Compra: precio del servidor, idempotencia, seguimiento privado y estados", async () => {
  const p = catalog.products[0];
  const input = {
    termsAccepted: true,
    legalFingerprint: catalog.legalFingerprint,
    items: [{ id: p.id, quantity: 2, color: p.colors[0], price: 1 }],
    method: catalog.settings.paymentMethods[0],
    idempotencyKey: randomUUID(),
    trackingToken: random(),
    customer: {
      name: "Prueba de compra",
      phone: "3001234567",
      email: "test@example.com",
      city: "Bogotá",
      address: "Dirección de prueba",
      notes: "Prueba técnica",
      consent: true,
    },
    total: 1,
  };
  const first = await request("/api/orders", { method: "POST", body: input });
  assert.equal(first.status, 201);
  assert.equal(first.body.total, p.price * 2);
  assert.equal(
    (
      await request("/api/orders", {
        method: "POST",
        body: { ...input, idempotencyKey: randomUUID(), termsAccepted: false },
      })
    ).status,
    400,
  );
  assert.equal(
    (
      await request("/api/orders", {
        method: "POST",
        body: {
          ...input,
          idempotencyKey: randomUUID(),
          legalFingerprint: "0".repeat(64),
        },
      })
    ).status,
    409,
  );
  const storedAcceptance = (
    await db.query("SELECT data FROM orders WHERE id=$1", [first.body.id])
  ).rows[0].data.legalAcceptance;
  assert.equal(storedAcceptance.fingerprint, catalog.legalFingerprint);
  assert.equal(storedAcceptance.terms, catalog.settings.terms);
  assert.ok(storedAcceptance.acceptedAt);
  const repeated = await request("/api/orders", {
    method: "POST",
    body: input,
  });
  assert.equal(repeated.status, 200);
  assert.equal(first.body.id, repeated.body.id);
  assert.equal(
    (
      await request("/api/orders", {
        method: "POST",
        body: { ...input, trackingToken: random() },
      })
    ).status,
    409,
  );
  assert.equal(
    (
      await request("/api/track", {
        method: "POST",
        body: { id: first.body.id, token: random() },
      })
    ).status,
    404,
  );
  const tracking = await request("/api/track", {
    method: "POST",
    body: { id: first.body.id, token: input.trackingToken },
  });
  assert.equal(tracking.status, 200);
  assert.equal(tracking.body.customer, undefined);
  assert.equal(
    (
      await request("/api/admin/orders/" + first.body.id, {
        method: "PATCH",
        body: { status: "en_fabricacion" },
        admin: true,
      })
    ).status,
    200,
  );
  assert.equal(
    (
      await request("/api/track", {
        method: "POST",
        body: { id: first.body.id, token: input.trackingToken },
      })
    ).body.status,
    "en_fabricacion",
  );
  const invalid = {
    ...input,
    idempotencyKey: randomUUID(),
    items: [{ id: p.id, quantity: 1, color: "Color inexistente" }],
  };
  assert.equal(
    (await request("/api/orders", { method: "POST", body: invalid })).status,
    400,
  );
});
test("Asesorías conservan la configuración y exigen consentimiento", async () => {
  const input = {
    name: "Prueba",
    phone: "3001234567",
    city: "Bogotá",
    message: "Quiero una sala",
    consent: true,
    type: "personalizacion",
    configuration: { shape: "En L", fabric: "Petróleo", extras: ["Baúl"] },
  };
  assert.equal(
    (
      await request("/api/leads", {
        method: "POST",
        body: { ...input, consent: false },
      })
    ).status,
    400,
  );
  assert.equal(
    (await request("/api/leads", { method: "POST", body: input })).status,
    201,
  );
  const saved = (await request("/api/admin/data", { admin: true })).body
    .leads[0].data;
  assert.deepEqual(saved.configuration, input.configuration);
});
test("Archivos: acepta GLB autocontenido y rechaza archivos disfrazados", async () => {
  const upload = async (name, buffer) => {
    const form = new FormData();
    form.append("file", new Blob([buffer]), name);
    return request("/api/admin/upload", {
      method: "POST",
      body: form,
      admin: true,
    });
  };
  assert.equal(
    (await upload("falso.png", Buffer.from("not an image"))).status,
    400,
  );
  const valid = await upload(
    "demo.glb",
    await fs.readFile("public/assets/modulo-demo.glb"),
  );
  assert.equal(valid.status, 201);
  assert.ok(valid.body.url.endsWith(".glb"));
  const broken = Buffer.alloc(30);
  broken.write("glTF");
  assert.equal((await upload("broken.glb", broken)).status, 400);
  const fakeVideo = Buffer.alloc(24);
  fakeVideo.write("ftyp", 4);
  const video = await upload("corrupto.mp4", fakeVideo);
  assert.equal(video.status, 400);
  assert.match(video.body.error, /180 segundos/);
  assert.equal(
    (await fs.readdir(tmp)).filter((x) => x.endsWith(".mp4")).length,
    0,
  );
});
test("Cerrar sesión invalida el acceso", async () => {
  assert.equal(
    (await request("/api/admin/logout", { method: "POST", admin: true }))
      .status,
    200,
  );
  assert.equal((await request("/api/admin/me", { admin: true })).status, 401);
});
