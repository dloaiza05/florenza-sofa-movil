import test from "node:test";
import assert from "node:assert/strict";
import {
  contentSchema,
  initialContent,
  campaignSchema,
} from "../server/content.js";
import { activeCampaigns, remainingTime } from "../src/campaigns.js";
test("Campañas: vigencia fija, exclusión al vencer y prohibición en producción", () => {
  const c = initialContent.campaigns[0],
    start = Date.parse(c.startsAt),
    end = Date.parse(c.endsAt);
  assert.equal(activeCampaigns([c], true, start - 1).length, 0);
  assert.equal(activeCampaigns([c], true, start).length, 1);
  assert.equal(activeCampaigns([c], true, end - 1).length, 1);
  assert.equal(activeCampaigns([c], true, end).length, 0);
  assert.equal(activeCampaigns([c], false, start).length, 0);
  assert.equal(
    activeCampaigns([{ ...c, enabled: false }], true, start).length,
    0,
  );
  assert.deepEqual(remainingTime(c.endsAt, end - 90061000), [1, 1, 1, 1]);
  assert.deepEqual(remainingTime(c.endsAt, end + 100000), [0, 0, 0, 0]);
});
test("Campañas: valida fechas, porcentajes, medios y duplicados antes de guardar", () => {
  const c = initialContent.campaigns[0];
  assert.equal(contentSchema.safeParse(initialContent).success, true);
  for (const bad of [
    { endsAt: c.startsAt },
    { discountPercent: 101 },
    { discountPercent: 0 },
    { discountPercent: 1.5 },
    { simulation: false },
    { image: "https://externo.test/foto.png" },
    { image: "/uploads/documento.pdf" },
    { mobileImage: "/uploads/modelo.glb" },
    { startsAt: "sin fecha" },
  ])
    assert.equal(campaignSchema.safeParse({ ...c, ...bad }).success, false);
  assert.equal(
    contentSchema.safeParse({ ...initialContent, campaigns: [c, c] }).success,
    false,
  );
});
test("Banners: rechaza archivos no gráficos e imágenes sin descripción", () => {
  const content = structuredClone(initialContent);
  content.financeBanners[0] = {
    ...content.financeBanners[0],
    image: "/uploads/banner.webp",
    mobileImage: "/uploads/movil.png",
    imageAlt: "Financiación",
  };
  assert.equal(contentSchema.safeParse(content).success, true);
  content.financeBanners[0].imageAlt = "";
  assert.equal(contentSchema.safeParse(content).success, false);
  content.financeBanners[0].imageAlt = "Financiación";
  content.financeBanners[0].mobileImage = "/uploads/video.mp4";
  assert.equal(contentSchema.safeParse(content).success, false);
});
