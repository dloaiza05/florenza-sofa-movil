import { test } from "node:test";
import assert from "node:assert/strict";
import { createAdminPreviewApi } from "../src/admin-preview-api.js";
test("Vista administrativa: usa copias públicas, descarta datos privados y bloquea cargas/acciones reales", async () => {
  const source = {
    products: [{ id: "sample", name: "Original", active: true }],
    settings: { storeName: "Tienda" },
    content: { hero: { title: "Original" } },
    orders: [{ private: true }],
    leads: [{ private: true }],
    admins: [{ private: true }],
  };
  const request = createAdminPreviewApi(source);
  const initial = await request("/admin/data");
  assert.deepEqual(initial.orders, []);
  assert.deepEqual(initial.leads, []);
  assert.equal(initial.admins, undefined);
  await request("/admin/content", {
    method: "PUT",
    body: { hero: { title: "Prueba" } },
  });
  assert.equal((await request("/admin/content")).hero.title, "Prueba");
  assert.equal(source.content.hero.title, "Original");
  initial.products[0].name = "Mutated";
  assert.equal((await request("/admin/data")).products[0].name, "Original");
  for (const url of ["/admin/upload", "/orders", "/login", "/admin/documents"])
    await assert.rejects(request(url, { method: "POST", body: {} }));
  await assert.rejects(request("/admin/me"));
  assert.equal(
    (await createAdminPreviewApi(source)("/admin/content")).hero.title,
    "Original",
  );
});
