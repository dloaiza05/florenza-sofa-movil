import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { openDatabase } from "../server/db.js";
import { createStoreRepository } from "../server/repositories/store.repository.js";
import { createAuthService } from "../server/services/auth.service.js";
import {
  createGoogleAuthService,
  googleConfiguration,
} from "../server/services/google-auth.service.js";
import { hash } from "../server/security.js";
let db, repo;
const config = {
  enabled: true,
  clientId: "test-client",
  clientSecret: "test-only",
  redirectUri: "http://localhost/callback",
  emails: ["owner@gmail.com", "missing@gmail.com"],
};
before(async () => {
  db = await openDatabase({ url: "", dir: "memory://" });
  repo = createStoreRepository(db);
  await db.query(
    "INSERT INTO admins(id,email,password_hash) VALUES('owner','owner@gmail.com','no-password-in-this-test')",
  );
});
after(() => db.close());
async function flow(overrides = {}, failVerification = false) {
  let request;
  const client = {
    generateAuthUrl(options) {
      request = options;
      return "https://accounts.google.com/";
    },
    async getToken(options) {
      assert.equal(options.code, "provider-code");
      assert.ok(options.codeVerifier);
      return { tokens: { id_token: "verified-by-mocked-google-client" } };
    },
    async verifyIdToken(options) {
      assert.equal(options.audience, config.clientId);
      if (failVerification) throw Error("bad signature/issuer/audience/expiry");
      return {
        getPayload: () => ({
          sub: "google-owner-1",
          email: "owner@gmail.com",
          email_verified: true,
          nonce: request.nonce,
          ...overrides,
        }),
      };
    },
  };
  const service = createGoogleAuthService(repo, config, client);
  const { browserKey } = await service.start();
  assert.equal(request.code_challenge_method, "S256");
  assert.deepEqual(request.scope, ["openid", "email"]);
  return {
    service,
    input: { browserKey, state: request.state, code: "provider-code" },
  };
}
test("Google: disabled without explicit configuration and allowlist", async () => {
  const disabled = googleConfiguration("http://localhost:8790", {});
  assert.equal(disabled.enabled, false);
  await assert.rejects(createGoogleAuthService(repo, disabled).start());
});
test("Google: rejects unauthorized/unverified accounts, nonce mismatch and invalid provider token", async () => {
  for (const claims of [
    { email: "intruder@gmail.com" },
    { email: "missing@gmail.com" },
    { email_verified: false },
    { nonce: "wrong" },
    { sub: "" },
  ]) {
    const f = await flow(claims);
    await assert.rejects(f.service.finish(f.input));
  }
  const f = await flow({}, true);
  await assert.rejects(f.service.finish(f.input));
  assert.equal(
    (await db.query("SELECT count(*) AS n FROM sessions")).rows[0].n,
    0,
  );
});
test("Google: state is bound to the initiating browser and expires", async () => {
  const f = await flow();
  await assert.rejects(
    f.service.finish({ ...f.input, browserKey: "a".repeat(64) }),
  );
  await db.query(
    "UPDATE google_login_attempts SET expires_at=now()-interval '1 second' WHERE state_hash=$1",
    [hash(f.input.state)],
  );
  await assert.rejects(f.service.finish(f.input));
});
test("Google: only existing allowed admin signs in; sub is pinned; replay and revoked sessions rejected", async () => {
  const f = await flow();
  const result = await f.service.finish(f.input);
  assert.equal(result.email, "owner@gmail.com");
  assert.equal((await repo.admin(result.email)).google_sub, "google-owner-1");
  await assert.rejects(f.service.finish(f.input));
  const other = await flow({ sub: "different-account-same-email" });
  await assert.rejects(other.service.finish(other.input));
  const authorized = createAuthService(repo, config.emails);
  assert.equal(
    (await authorized.session(result.token)).auth_provider,
    "google",
  );
  await assert.rejects(createAuthService(repo, []).session(result.token));
  assert.equal(await repo.session(hash(result.token)), undefined);
});
