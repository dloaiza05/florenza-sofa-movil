import { test } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { openDatabase } from "../server/db.js";
import { seed } from "../server/seed.js";
import { createApp } from "../server/app.js";
import { random } from "../server/security.js";

async function fixture(run) {
  const db = await openDatabase({ url: "", dir: "memory://" });
  await seed(db);
  const server = createApp(db).listen(0, "127.0.0.1");
  await new Promise((r) => server.once("listening", r));
  const base = "http://127.0.0.1:" + server.address().port;
  const post = (route, body) =>
    fetch(base + "/api" + route, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
  const catalog = () => fetch(base + "/api/catalog").then((r) => r.json());
  const makeInput = (c) => ({
    items: [
      { id: c.products[0].id, color: c.products[0].colors[0], quantity: 1 },
    ],
    method: c.settings.paymentMethods[0],
    idempotencyKey: randomUUID(),
    trackingToken: random(),
    termsAccepted: true,
    legalFingerprint: c.legalFingerprint,
    customer: {
      name: "Prueba técnica aislada",
      phone: "3001234567",
      email: "prueba@example.test",
      city: "Bogotá",
      address: "Dirección ficticia de prueba",
      notes: "",
      consent: true,
    },
  });
  try {
    await run({ db, post, catalog, makeInput });
  } finally {
    await new Promise((r) => server.close(r));
    await db.close();
  }
}

test("Compras: seis envíos simultáneos crean una sola solicitud y no falsifican un pago", () =>
  fixture(async ({ db, post, catalog, makeInput }) => {
    const c = await catalog(),
      input = {
        ...makeInput(c),
        total: 1,
        paymentStatus: "paid",
        status: "entregado",
        shipping: 0,
      };
    input.items[0].price = 1;
    const responses = await Promise.all(
      Array.from({ length: 6 }, () => post("/orders", input)),
    );
    assert.equal(responses.filter((r) => r.status === 201).length, 1);
    assert.equal(responses.filter((r) => r.status === 200).length, 5);
    const results = await Promise.all(responses.map((r) => r.json()));
    assert.equal(new Set(results.map((x) => x.id)).size, 1);
    const rows = (await db.query("SELECT * FROM orders")).rows;
    assert.equal(rows.length, 1);
    assert.equal(rows[0].data.total, c.products[0].price);
    assert.equal(rows[0].data.paymentStatus, "pendiente_de_confirmacion");
    assert.equal(rows[0].data.shipping, "por_cotizar");
    assert.equal(rows[0].status, "recibido");
    assert.equal(
      (
        await post("/orders", {
          ...input,
          items: [{ ...input.items[0], quantity: 2 }],
        })
      ).status,
      409,
    );
    const track = await (
      await post("/track", {
        id: rows[0].id,
        token: input.trackingToken,
        paymentStatus: "paid",
      })
    ).json();
    assert.equal(track.paymentStatus, "pendiente_de_confirmacion");
    assert.equal(
      (await post("/track", { id: rows[0].id, token: random() })).status,
      404,
    );
  }));

test("Apertura comercial: no basta quitar el aviso demo si faltan identidad o condiciones", () =>
  fixture(async ({ db, post, catalog, makeInput }) => {
    const save = async (patch) => {
      await db.query("UPDATE settings SET data=data || $1::jsonb WHERE id=1", [
        JSON.stringify(patch),
      ]);
      return catalog();
    };
    let c = await save({
      demo: false,
      legalName: "",
      taxId: "",
      legalDraft: false,
    });
    assert.equal((await post("/orders", makeInput(c))).status, 409);
    c = await save({
      legalName: "Comercio ficticio de pruebas",
      taxId: "IDENTIFICACION-FICTICIA",
      legalDraft: true,
    });
    assert.equal((await post("/orders", makeInput(c))).status, 409);
    assert.equal(
      (await db.query("SELECT count(*) AS total FROM orders")).rows[0].total,
      0,
    );
    const prior = makeInput(c);
    c = await save({ legalDraft: false });
    assert.equal((await post("/orders", prior)).status, 409);
    const valid = await post("/orders", makeInput(c));
    assert.equal(valid.status, 201);
    const row = (await db.query("SELECT data FROM orders")).rows[0];
    assert.equal(row.data.paymentStatus, "pendiente_de_confirmacion");
    assert.equal(row.data.legalAcceptance.draft, false);
  }));
