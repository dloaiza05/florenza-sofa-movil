import test from "node:test";
import assert from "node:assert/strict";
import express from "express";
import { mediaProtection } from "../server/middleware/media-protection.js";
test("Medios: limita descargas, bloquea incrustación externa y permite visor/AR", async () => {
  const app = express();
  app.use("/assets", mediaProtection({ limit: 3 }));
  app.use((req, res) => res.send("asset"));
  const server = app.listen(0, "127.0.0.1");
  await new Promise((r) => server.once("listening", r));
  const base = "http://127.0.0.1:" + server.address().port;
  try {
    const hotlink = await fetch(base + "/assets/logo.svg", {
      headers: { "Sec-Fetch-Site": "cross-site", "Sec-Fetch-Dest": "image" },
    });
    assert.equal(hotlink.status, 403);
    assert.equal(
      (
        await fetch(base + "/assets/logo.svg", {
          headers: {
            "Sec-Fetch-Site": "same-origin",
            "Sec-Fetch-Dest": "image",
          },
        })
      ).status,
      200,
    );
    assert.equal(
      (
        await fetch(base + "/assets/model.glb", {
          headers: {
            "Sec-Fetch-Site": "cross-site",
            "Sec-Fetch-Dest": "empty",
          },
        })
      ).status,
      200,
    );
    assert.equal((await fetch(base + "/assets/model.usdz")).status, 200);
    const limited = await fetch(base + "/assets/logo.svg");
    assert.equal(limited.status, 429);
    assert.ok(limited.headers.get("retry-after"));
    assert.equal(limited.headers.get("cache-control"), "no-store");
  } finally {
    await new Promise((r) => server.close(r));
  }
});
