import {test} from 'node:test';
import assert from 'node:assert/strict';
import {openDatabase} from '../server/db.js';
import {seed} from '../server/seed.js';
import {createApp} from '../server/app.js';
import {productSchema} from '../server/validators/schemas.js';

test('806 referencias: paginación SQL, filtros, galerías y configuración por piezas',async()=>{
 const db=await openDatabase({url:'',dir:'memory://'});await seed(db);
 const baseProduct=(await db.query("SELECT data FROM products WHERE id='canela'")).rows[0].data;
 const gallery=Array.from({length:10},(_,i)=>({url:baseProduct.image,color:i%2?'Gris':'Arena',alt:'Vista '+(i+1)}));
 const product=productSchema.parse({...baseProduct,gallery,madeToMeasure:true,category:'Comedores'});
 assert.equal(product.gallery.length,10);
 assert.equal(productSchema.safeParse({...product,gallery:[...gallery,gallery[0]]}).success,false);
 assert.equal(productSchema.safeParse({...product,gallery:[{...gallery[0],color:'Color no vendido'}]}).success,false);
 assert.equal(productSchema.safeParse({...product,modelParts:{arms:['shared'],seat:['shared']}}).success,false);
 await db.query("INSERT INTO products(id,data) SELECT 'scale-'||lpad(n::text,4,'0'),$1::jsonb||jsonb_build_object('id','scale-'||lpad(n::text,4,'0'),'name','Comedor prueba '||n,'price',1000000+n) FROM generate_series(1,800) n",[JSON.stringify(product)]);
 const server=createApp(db).listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));const base='http://127.0.0.1:'+server.address().port;
 const get=async url=>{const r=await fetch(base+url);assert.equal(r.status,200);return r.json();};
 try{
  const first=await get('/api/products');assert.equal(first.total,806);assert.equal(first.items.length,12);assert.equal(first.items[0].gallery,undefined);
  const page=await get('/api/products?category=Comedores&sort=low&page=2');assert.equal(page.total,800);assert.equal(page.items[0].id,'scale-0013');assert.equal(page.pages,67);
  const final=await get('/api/products?category=Comedores&page=999');assert.equal(final.page,67);assert.equal(final.items.length,8);
  const filtered=await get('/api/products?category=Comedores&maxPrice=1000010');assert.equal(filtered.total,10);
  assert.equal((await get('/api/products?q='+encodeURIComponent("' OR 1=1 --"))).total,0);
  assert.equal((await fetch(base+'/api/products?pageSize=800')).status,400);
  const detail=await get('/api/products/scale-0001');assert.equal(detail.gallery.length,10);assert.equal(detail.madeToMeasure,true);
  await db.query("UPDATE products SET data=jsonb_set(data,'{active}','false') WHERE id='scale-0001'");assert.equal((await fetch(base+'/api/products/scale-0001')).status,404);
  const lead={name:'Prueba 3D',phone:'3001234567',city:'Bogotá',message:'Cotizar las piezas seleccionadas',consent:true,type:'personalizacion',configuration:{kind:'product',productId:'canela',color:'Arena',parts:{arms:'arena',back:'petroleo',seat:'gris'},legOption:''}};
  const post=body=>fetch(base+'/api/leads',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  assert.equal((await post(lead)).status,201);
  const saved=(await db.query('SELECT data FROM leads')).rows[0].data;assert.equal(saved.configuration.parts.arms,'arena');assert.match(saved.configuration.summary,/Brazos: Arena/);
  assert.equal((await post({...lead,configuration:{...lead.configuration,parts:{arms:'inventado'}}})).status,400);
 }finally{await new Promise(r=>server.close(r));await db.close();}
});
