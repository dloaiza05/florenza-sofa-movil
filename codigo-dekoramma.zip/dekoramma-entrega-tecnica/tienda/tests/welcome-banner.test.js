import test from "node:test";
import assert from "node:assert/strict";
import {
  welcomeDefaults,
  welcomeEligible,
  welcomeKey,
} from "../src/welcome-banner.js";
import {
  welcomeSchema,
  campaignSchema,
  initialContent,
  contentSchema,
} from "../server/content.js";
test("Bienvenida: se muestra en cada carga y respeta vigencia", () => {
  const b = {
    ...welcomeDefaults,
    startsAt: "2026-09-12T00:00:00Z",
    endsAt: "2026-09-13T00:00:00Z",
  };
  const now = Date.parse(b.startsAt);
  assert.equal(welcomeEligible(b, now, false), true);
  assert.equal(welcomeEligible(b, now, true), true);
  assert.equal(welcomeEligible(b, now, false, "#catalogo"), true);
  assert.equal(welcomeEligible(b, now - 1, false), false);
  assert.equal(welcomeEligible(b, Date.parse(b.endsAt), false), false);
  assert.equal(welcomeEligible({ ...b, enabled: false }, now, false), false);
  assert.notEqual(welcomeKey(b), welcomeKey({ ...b, revision: 2 }));
});
test("Banners de video: valida formato, portada, destino y fechas", () => {
  const b = { ...welcomeDefaults, video: "/uploads/banner.mp4" };
  assert.equal(welcomeSchema.safeParse(b).success, true);
  for (const invalid of [
    { video: "https://externo.test/video.mp4" },
    { video: "/uploads/archivo.svg" },
    { image: "" },
    { target: "javascript:alert(1)" },
    { revision: 0 },
    { startsAt: "2026-09-13T00:00:00Z", endsAt: "2026-09-12T00:00:00Z" },
  ])
    assert.equal(welcomeSchema.safeParse({ ...b, ...invalid }).success, false);
  assert.equal(
    campaignSchema.safeParse({ ...initialContent.campaigns[0], video: b.video })
      .success,
    true,
  );
  const c = structuredClone(initialContent);
  c.financeBanners[0].video = b.video;
  assert.equal(contentSchema.safeParse(c).success, false);
  Object.assign(c.financeBanners[0], { image: b.image, imageAlt: b.imageAlt });
  assert.equal(contentSchema.safeParse(c).success, true);
});
