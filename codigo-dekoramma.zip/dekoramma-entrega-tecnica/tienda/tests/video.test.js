import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import path from "node:path";
import os from "node:os";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import ffmpeg from "ffmpeg-static";
import { saveMedia } from "../server/services/media.service.js";
const run = promisify(execFile);
test(
  "Reels MP4 reales: admite 180 segundos y rechaza 181 segundos",
  { timeout: 30000 },
  async () => {
    const tmp = await fs.mkdtemp(path.join(os.tmpdir(), "dekoramma-video-"));
    try {
      for (const duration of [180, 181]) {
        const file = path.join(tmp, "video-" + duration + ".mp4");
        await run(
          ffmpeg,
          [
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=c=black:s=32x32:r=1",
            "-t",
            String(duration),
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            "-movflags",
            "+faststart",
            file,
          ],
          { timeout: 15000 },
        );
        const input = {
          originalname: "video.mp4",
          buffer: await fs.readFile(file),
        };
        if (duration === 180)
          assert.match(
            (await saveMedia(input, path.join(tmp, "uploads"))).url,
            /\.mp4$/,
          );
        else
          await assert.rejects(
            () => saveMedia(input, path.join(tmp, "uploads")),
            (e) => e.status === 400 && e.message.includes("180 segundos"),
          );
      }
      assert.equal((await fs.readdir(path.join(tmp, "uploads"))).length, 1);
    } finally {
      await fs.rm(tmp, { recursive: true, force: true });
    }
  },
);
