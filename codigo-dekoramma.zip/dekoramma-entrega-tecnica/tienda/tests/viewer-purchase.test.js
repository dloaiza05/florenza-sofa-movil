import test from "node:test";
import assert from "node:assert/strict";
import { viewerPurchase } from "../src/viewer-purchase.js";
test("Compra desde 3D: conserva el color y evita cobrar como base una personalización", () => {
  const product = { id: "canela", colors: ["Arena", "Rosa"] };
  assert.deepEqual(viewerPurchase(product, "Rosa"), { product, color: "Rosa" });
  assert.equal(viewerPurchase(product, "No existe"), null);
  assert.equal(viewerPurchase(product, "Rosa", { seat: "verde" }), null);
  assert.equal(viewerPurchase(product, "Rosa", {}, "metal"), null);
  assert.deepEqual(viewerPurchase(product, "Arena", { seat: "" }), {
    product,
    color: "Arena",
  });
});
