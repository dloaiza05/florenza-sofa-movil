import { test } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { openDatabase } from "../server/db.js";
import { createApp } from "../server/app.js";
import { passwordHash, random } from "../server/security.js";

test("Producción: archivos privados bloqueados, sesión segura y origen obligatorio", async () => {
  const db = await openDatabase({ url: "", dir: "memory://" });
  const password = random();
  await db.query(
    "INSERT INTO admins(id,email,password_hash) VALUES($1,$2,$3)",
    [randomUUID(), "security@example.com", passwordHash(password)],
  );
  const app = createApp(db, {
    production: true,
    origin: "https://tienda.example",
  });
  // Si llega al manejador público, la protección no interceptó la ruta.
  app.use((req, res) => res.status(200).send("public fallback"));
  const server = app.listen(0, "127.0.0.1");
  await new Promise((resolve) => server.once("listening", resolve));
  const base = "http://127.0.0.1:" + server.address().port;
  try {
    for (const route of [
      "/.env",
      "/assets/sala.blend",
      "/assets/sala%2Eblend",
      "/uploads/logo.ai",
      "/uploads/catalogo.psd",
      "/%64ata/private.txt",
      "/.env.production",
      "/.git/config",
      "/data/acceso-administracion.txt",
      "/server/security.js",
      "/qa/admin.png",
      "/README.md",
      "/package-lock.json",
      "/uploads/access.dpapi",
      "/_next/static/chunks/main.js.map",
    ]) {
      const response = await fetch(base + route);
      assert.equal(response.status, 404, route);
      assert.equal(await response.text(), "");
    }
    const admin = await fetch(base + "/admin");
    assert.equal(admin.headers.get("cache-control"), "no-store");
    assert.match(admin.headers.get("x-robots-tag"), /noindex/);
    assert.equal(admin.headers.get("x-powered-by"), null);
    assert.match(admin.headers.get("content-security-policy"), /nonce-/);
    const login = (origin) =>
      fetch(base + "/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(origin ? { Origin: origin } : {}),
        },
        body: JSON.stringify({ email: "security@example.com", password }),
      });
    assert.equal((await login()).status, 403);
    assert.equal((await login("https://foreign.example")).status, 403);
    const response = await login("https://tienda.example");
    assert.equal(response.status, 200);
    const cookie = response.headers.get("set-cookie");
    for (const flag of ["HttpOnly", "Secure", "SameSite=Strict"])
      assert.ok(cookie.includes(flag), flag);
    const user = await response.json();
    assert.equal(user.password, undefined);
    assert.equal(user.password_hash, undefined);
    const sessions = await db.query("SELECT token_hash FROM sessions");
    assert.ok(!cookie.includes(sessions.rows[0].token_hash));
  } finally {
    await new Promise((resolve) => server.close(resolve));
    await db.close();
  }
});
