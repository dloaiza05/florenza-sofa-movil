import test from 'node:test';
import assert from 'node:assert/strict';
import { convertObj } from '../src/obj-to-glb.js';
import { productSchema } from '../server/validators/schemas.js';

const cube = `v 0 0 0
v 200 0 0
v 200 90 0
v 0 90 0
v 0 0 100
v 200 0 100
v 200 90 100
v 0 90 100
f 1 2 3 4
f 5 8 7 6
f 1 5 6 2
f 4 3 7 8
f 1 4 8 5
f 2 6 7 3`;
// The exporter uses the browser FileReader API; supply only its binary operation.
globalThis.FileReader = class {
  readAsArrayBuffer(blob) {
    blob.arrayBuffer().then(result => { this.result=result; this.onloadend?.(); });
  }
};
test('OBJ: centimetres become metre-scale GLB; malformed and wrong-scale files fail', async () => {
  const result=await convertObj(cube,'cm');
  assert.deepEqual([result.width,result.depth,result.height],[200,100,90]);
  const data=Buffer.from(result.buffer);
  assert.equal(data.toString('ascii',0,4),'glTF');
  assert.equal(data.readUInt32LE(4),2);
  assert.equal(data.readUInt32LE(8),data.length);
  const json=JSON.parse(data.subarray(20,20+data.readUInt32LE(12)).toString());
  assert.equal(json.asset.version,'2.0');
  assert.ok(json.buffers.every(b=>!b.uri));
  await assert.rejects(convertObj('just text','cm'),/superficies/);
  await assert.rejects(convertObj(cube,'m'),/dimensiones/);
  await assert.rejects(convertObj(cube,'inch'),/unidad/);
});
test('Viewer settings survive validation; remote model URLs and invalid colors fail', () => {
  const p={id:'sofa-test',name:'Sofá',category:'Sofás',price:1000000,description:'Prueba',image:'/assets/sofa.webp',width:200,depth:100,height:90,colors:['Arena'],active:false,modelUrl:'/uploads/model.glb',usdzUrl:'',modelDemo:false,videoUrl:''};
  assert.equal(productSchema.parse(p).viewer.arEnabled,true);
  const viewer={arEnabled:false,showDimensions:true,showFit:false,showRotate:true,materialName:'Tapizado',colors:[{label:'Arena',hex:'#ddccbb',modelUrl:'/uploads/arena.glb',usdzUrl:''}]};
  assert.deepEqual(productSchema.parse({...p,viewer}).viewer,viewer);
  assert.equal(productSchema.safeParse({...p,viewer:{...viewer,colors:[{...viewer.colors[0],modelUrl:'https://evil.example/sofa.glb'}]}}).success,false);
  assert.equal(productSchema.safeParse({...p,viewer:{...viewer,colors:[{...viewer.colors[0],hex:'red'}]}}).success,false);
});
