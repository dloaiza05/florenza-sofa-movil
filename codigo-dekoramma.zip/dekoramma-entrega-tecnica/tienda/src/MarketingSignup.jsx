"use client";
import React, { useState } from "react";
import { Mail, MessageCircle, ArrowRight } from "lucide-react";
import { api } from "./api";
import { marketingConsent } from "./consent-copy";
export default function MarketingSignup({
  legalFingerprint,
  onAdvice,
  settings,
}) {
  const [open, setOpen] = useState(false),
    [channels, setChannels] = useState([]),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [result, setResult] = useState(null);
  return (
    <section
      className="wrap relationship-section"
      aria-labelledby="relationship-title"
    >
      <div>
        <span className="eyebrow">Hagamos espacio para tus ideas</span>
        <h2 id="relationship-title">Tu próximo espacio empieza aquí.</h2>
        <p>
          Recibe ideas y novedades, o conversemos sobre el mueble que necesitas.
        </p>
        <div className="relationship-actions">
          <button
            className="outline"
            onClick={() => setOpen(!open)}
            aria-expanded={open}
            aria-controls="newsletter-form"
          >
            <Mail size={18} /> Recibe novedades y ofertas
          </button>
          <button onClick={onAdvice}>
            <MessageCircle size={18} /> Agenda una asesoría{" "}
            <ArrowRight size={18} />
          </button>
        </div>
      </div>
      {open && (
        <div id="newsletter-form" className="newsletter-panel">
          {result ? (
            <div role="status">
              <h3>Solicitud guardada</h3>
              <p>{result.message}</p>
              <a href={result.managementPath}>
                Guardar o abrir mi enlace privado para retirar la autorización
              </a>
              <p className="caption">
                También puedes solicitarlo a{" "}
                <a href={"mailto:" + settings.email}>{settings.email}</a>.
              </p>
            </div>
          ) : (
            <form
              className="form-grid"
              onSubmit={async (e) => {
                e.preventDefault();
                setBusy(true);
                setError("");
                const f = new FormData(e.currentTarget);
                try {
                  setResult(
                    await api("/marketing", {
                      method: "POST",
                      body: {
                        name: f.get("name"),
                        email: f.get("email") || "",
                        phone: f.get("phone") || "",
                        channels,
                        consent: f.get("marketingConsent") === "on",
                        legalFingerprint,
                      },
                    }),
                  );
                } catch (e) {
                  setError(e.message);
                } finally {
                  setBusy(false);
                }
              }}
            >
              <h3>Solo por los canales que tú elijas.</h3>
              <p className="caption">
                Nombre opcional. Elige correo, WhatsApp o ambos; no necesitas
                suscribirte para comprar.
              </p>
              <label>
                Nombre (opcional)
                <input name="name" autoComplete="given-name" maxLength={100} />
              </label>
              <fieldset className="channel-choices">
                <legend>¿Dónde quieres recibir novedades?</legend>
                {[
                  ["email", "Correo electrónico"],
                  ["whatsapp", "WhatsApp"],
                ].map(([key, label]) => (
                  <label className="check" key={key}>
                    <input
                      type="checkbox"
                      checked={channels.includes(key)}
                      onChange={(e) =>
                        setChannels(
                          e.target.checked
                            ? [...channels, key]
                            : channels.filter((x) => x !== key),
                        )
                      }
                    />
                    {label}
                  </label>
                ))}
              </fieldset>
              {channels.includes("email") && (
                <label>
                  Correo electrónico
                  <input
                    name="email"
                    type="email"
                    required
                    autoComplete="email"
                    maxLength={254}
                  />
                </label>
              )}
              {channels.includes("whatsapp") && (
                <label>
                  Celular de Colombia
                  <input
                    name="phone"
                    type="tel"
                    required
                    autoComplete="tel"
                    placeholder="3001234567"
                    pattern="(\+?57)?3[0-9]{9}"
                  />
                </label>
              )}
              <p className="caption">
                Responsable:{" "}
                {settings.legalName ||
                  "identificación legal pendiente por completar"}{" "}
                · Dekoramma. Consulta la{" "}
                <a
                  href="/informacion#privacidad"
                  target="_blank"
                  rel="noreferrer"
                >
                  política de privacidad
                </a>
                .
              </p>
              <label className="check">
                <input name="marketingConsent" type="checkbox" required />
                {marketingConsent}
              </label>
              {error && (
                <p role="alert" className="error">
                  {error}
                </p>
              )}
              <button disabled={busy || !channels.length}>
                {busy ? "Guardando…" : "Quiero recibir novedades"}
              </button>
            </form>
          )}
        </div>
      )}
    </section>
  );
}
