import React from "react";
import { welcomeDefaults } from "./welcome-banner";
export default function WelcomeBannerEditor({
  value = welcomeDefaults,
  onChange,
  Media,
}) {
  const update = (key, next) => onChange({ ...value, [key]: next });
  return (
    <details className="editor-section">
      <summary>Banner al entrar · imagen o video</summary>
      <a href="/?vista=bienvenida" target="_blank" rel="noreferrer">
        Ver bienvenida guardada en otra pestaña ↗
      </a>
      <p>
        Aparece cada vez que se abre o refresca la tienda, incluso al entrar
        directamente al catálogo. Se puede cerrar inmediatamente. El video
        inicia al pulsar reproducir.
      </p>
      <label>
        <input
          type="checkbox"
          checked={value.enabled}
          onChange={(e) => update("enabled", e.target.checked)}
        />{" "}
        Activar bienvenida
      </label>
      {[
        ["title", "Título", 90],
        ["text", "Descripción", 400],
        ["imageAlt", "Descripción accesible del contenido", 180],
        ["buttonText", "Texto del botón", 50],
      ].map(([key, label, max]) => (
        <label key={key}>
          {label}
          <input
            required
            maxLength={max}
            value={value[key]}
            onChange={(e) => update(key, e.target.value)}
          />
        </label>
      ))}
      <label>
        Destino del botón
        <select
          value={value.target}
          onChange={(e) => update("target", e.target.value)}
        >
          {[
            ["catalogo", "Catálogo"],
            ["financiacion", "Financiación"],
            ["configurador", "Diseña tu mueble"],
            ["contacto", "Visítanos"],
          ].map(([id, label]) => (
            <option key={id} value={id}>
              {label}
            </option>
          ))}
        </select>
      </label>
      <Media
        label="Imagen o portada del video"
        value={value.image}
        accept=".png,.jpg,.jpeg,.webp"
        onChange={(v) => update("image", v)}
      />
      <Media
        label="Imagen para celular (opcional)"
        value={value.mobileImage}
        accept=".png,.jpg,.jpeg,.webp"
        onChange={(v) => update("mobileImage", v)}
      />
      <Media
        label="Video de bienvenida MP4 · máximo 3 minutos (opcional)"
        value={value.video}
        accept=".mp4"
        onChange={(v) => update("video", v)}
      />
      <p>
        Si hay video se usa en todos los tamaños; la imagen queda como portada.
        Incluye en el texto la información importante del video y subtítulos
        incorporados si contiene voz.
      </p>
      {[
        ["startsAt", "Inicio opcional"],
        ["endsAt", "Cierre opcional"],
      ].map(([key, label]) => (
        <label key={key}>
          {label} · Bogotá
          <input
            type="datetime-local"
            value={
              value[key]
                ? new Date(Date.parse(value[key]) - 5 * 3600000)
                    .toISOString()
                    .slice(0, 16)
                : ""
            }
            onChange={(e) =>
              update(key, e.target.value ? `${e.target.value}:00-05:00` : "")
            }
          />
        </label>
      ))}
      <label>
        Versión de campaña
        <input
          type="number"
          min="1"
          max="999999"
          step="1"
          value={value.revision}
          onChange={(e) => update("revision", Number(e.target.value))}
        />
      </label>
      <p>
        Sube la versión solo para una campaña nueva: permitirá mostrarla de
        nuevo a quien ya vio la anterior.
      </p>
    </details>
  );
}
