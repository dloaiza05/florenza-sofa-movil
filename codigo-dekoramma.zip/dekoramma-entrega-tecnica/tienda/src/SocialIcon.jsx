import React from "react";
export default function SocialIcon({ brand }) {
  if (!["facebook", "whatsapp", "instagram"].includes(brand)) return null;
  return (
    <span className={`social-brand social-brand--${brand}`} aria-hidden="true">
      <img
        src={`/assets/social/${brand}.${brand === "instagram" ? "png" : "svg"}`}
        alt=""
        width="24"
        height="24"
      />
    </span>
  );
}
