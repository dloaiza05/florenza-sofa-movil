import React from "react";
import { Box } from "lucide-react";
export default function Explore3DButton({
  onClick,
  productName,
  hero = false,
  inline = false,
}) {
  return (
    <button
      className={`explore-3d ${inline ? "explore-3d--inline" : "model-badge"} ${hero ? "explore-3d--hero" : ""}`}
      onClick={onClick}
      aria-label={`Ver ${productName || "el mueble"} en 3D`}
    >
      <Box size={18} aria-hidden="true" />
      <span>Ver en 3D</span>
    </button>
  );
}
