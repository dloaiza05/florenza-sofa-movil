import React from "react";
export const paymentArtwork = {
  Bold: "bold.svg",
  PSE: "pse.svg",
  Addi: "addi.svg",
  "Sistecrédito": "sistecredito.svg",
  "Vanti Listo": "vanti-listo.png",
  Nequi: "nequi.svg",
  Visa: "visa.svg",
  Mastercard: "mastercard.svg",
};
export default function PaymentBrand({ method }) {
  const file = paymentArtwork[method];
  return file ? (
    <img
      className={`payment-brand brand-${file.split(".")[0]}`}
      src={`/assets/payments/${file}`}
      alt={method === "Daviplata" ? "DaviPlata" : method}
      loading="lazy"
    />
  ) : (
    <span className="payment-brand-name">{method === "Daviplata" ? "DaviPlata" : method}</span>
  );
}
