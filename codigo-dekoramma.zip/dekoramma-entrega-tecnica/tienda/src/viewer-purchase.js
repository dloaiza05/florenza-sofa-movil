export function viewerPurchase(product, color, parts = {}, legOption = "") {
  if (
    !product?.colors?.includes(color) ||
    legOption ||
    Object.values(parts).some(Boolean)
  )
    return null;
  return { product, color };
}
