"use client";
import React from "react";
import { partLabels } from "./product-options";
export default function ModelConfigEditor({ product: p, onChange, Media }) {
  return (
    <fieldset className="media-editor">
      <legend>Personalización 3D por piezas</legend>
      <p>
        El GLB de Blender debe tener materiales separados por pieza. Escribe sus
        nombres exactos; un material no puede controlar dos piezas
        independientes.
      </p>
      <div className="admin-edit-grid">
        {Object.entries(partLabels).map(([key, label]) => (
          <label key={key}>
            Materiales de {label.toLowerCase()} (separados por coma)
            <input
              value={(p.modelParts?.[key] || []).join(",")}
              onChange={(e) =>
                onChange({
                  modelParts: {
                    ...p.modelParts,
                    [key]: e.target.value
                      .split(",")
                      .map((x) => x.trim())
                      .filter(Boolean),
                  },
                })
              }
            />
          </label>
        ))}
      </div>
      <h3>Acabados disponibles</h3>
      {(p.finishes || []).map((f, i) => (
        <div className="finish-edit" key={i}>
          {[
            ["id", "Código"],
            ["label", "Nombre"],
            ["hex", "Color"],
          ].map(([key, label]) => (
            <label key={key}>
              {label}
              <input
                type={key === "hex" ? "color" : "text"}
                value={f[key]}
                onChange={(e) =>
                  onChange({
                    finishes: p.finishes.map((x, n) =>
                      n === i ? { ...x, [key]: e.target.value } : x,
                    ),
                  })
                }
              />
            </label>
          ))}
          <button
            type="button"
            className="outline"
            onClick={() =>
              onChange({ finishes: p.finishes.filter((_, n) => n !== i) })
            }
          >
            Quitar acabado
          </button>
        </div>
      ))}
      <button
        type="button"
        className="outline"
        disabled={(p.finishes || []).length >= 20}
        onClick={() =>
          onChange({
            finishes: [
              ...(p.finishes || []),
              {
                id: "acabado-" + Date.now(),
                label: "Nuevo acabado",
                hex: "#888888",
              },
            ],
          })
        }
      >
        Añadir acabado
      </button>
      <h3>Opciones de patas con geometría real</h3>
      <p>
        Carga el mueble completo con cada opción de patas de Blender. Conserva
        escala, origen y nombres de materiales en todos los archivos. No se
        simula madera, plástico o metal cambiando únicamente el color.
      </p>
      {(p.legOptions || []).map((option, i) => (
        <div className="media-edit-card" key={option.id}>
          <label>
            Nombre de la opción
            <input
              value={option.label}
              onChange={(e) =>
                onChange({
                  legOptions: p.legOptions.map((x, n) =>
                    n === i ? { ...x, label: e.target.value } : x,
                  ),
                })
              }
            />
          </label>
          <Media
            label={"GLB · " + option.label}
            value={option.modelUrl}
            accept=".glb"
            onChange={(url) =>
              onChange({
                legOptions: p.legOptions.map((x, n) =>
                  n === i ? { ...x, modelUrl: url } : x,
                ),
              })
            }
          />
          <Media
            label={"USDZ · " + option.label}
            value={option.usdzUrl}
            accept=".usdz"
            onChange={(url) =>
              onChange({
                legOptions: p.legOptions.map((x, n) =>
                  n === i ? { ...x, usdzUrl: url } : x,
                ),
              })
            }
          />
          <button
            type="button"
            className="outline"
            onClick={() =>
              onChange({ legOptions: p.legOptions.filter((_, n) => n !== i) })
            }
          >
            Quitar opción
          </button>
        </div>
      ))}
      <button
        type="button"
        className="outline"
        disabled={(p.legOptions || []).length >= 6}
        onClick={() =>
          onChange({
            legOptions: [
              ...(p.legOptions || []),
              {
                id: "patas-" + Date.now(),
                label: "Patas de madera",
                modelUrl: "",
                usdzUrl: "",
              },
            ],
          })
        }
      >
        Añadir opción de patas
      </button>
    </fieldset>
  );
}
