"use client";
import React, { useState } from "react";
import dynamic from "next/dynamic";
import { api } from "./api";
const Viewer = dynamic(() => import("./Viewer"), {ssr:false});
export default function ModelConfigEditor({ product:p, onChange, Media, onBusy=()=>{} }) {
 const [preview,setPreview]=useState(false),[units,setUnits]=useState('cm'),[status,setStatus]=useState(''),[busy,setBusy]=useState(false);
 const settings={arEnabled:true,showDimensions:true,showFit:true,showRotate:true,materialName:'',colors:[],...p.viewer};
 const update=fields=>onChange({viewer:{...settings,...fields}});
 const editColor=(i,fields)=>update({colors:settings.colors.map((c,n)=>n===i?{...c,...fields}:c)});
 return <fieldset className="media-editor">
  <legend>Modelo del producto y experiencia en el celular</legend>
  <p>Carga el GLB y, si lo tienes, el USDZ en los campos del producto. Verifica que sus medidas reales coincidan con ancho, fondo y alto. La cámara coloca este mueble sobre el piso; no escanea paredes ni comprueba obstáculos.</p>
  <div className="admin-edit-grid">
   {[["arEnabled","Ofrecer «Ver en mi espacio» con cámara"],["showDimensions","Mostrar las medidas del producto"],["showFit","Mostrar comparación con el espacio disponible"],["showRotate","Sugerir girar el celular horizontalmente"]].map(([key,label])=><label className="check" key={key}><input type="checkbox" checked={settings[key]} onChange={e=>update({[key]:e.target.checked})}/>{label}</label>)}
  </div>
  <h3>Colores del modelo</h3>
  <p>Para conservar cada color al abrir el visor nativo, carga un GLB del mueble completo por acabado, con la misma forma y escala. El USDZ de cada color es opcional. Los controles sobre la cámara solo aparecen en WebXR.</p>
  <label>Nombre exacto del material de tapizado en el GLB (opcional)<input value={settings.materialName} maxLength={100} placeholder="Ej. Tapizado" onChange={e=>update({materialName:e.target.value})}/></label>
  <p>Ese material permite aproximar el color sobre la cámara WebXR. Si se deja vacío, los colores se eligen antes de abrir la cámara. No se modifican patas ni piezas.</p>
  {settings.colors.map((color,i)=><div className="media-edit-card" key={i}>
   <label>Nombre del color<input required maxLength={50} value={color.label} onChange={e=>editColor(i,{label:e.target.value})}/></label>
   <label>Muestra orientativa<input type="color" value={color.hex} onChange={e=>editColor(i,{hex:e.target.value})}/></label>
   <Media label={`GLB del color ${i+1}`} value={color.modelUrl} accept=".glb" onBusy={onBusy} onChange={url=>editColor(i,{modelUrl:url})}/>
   <Media label={`USDZ del color ${i+1} (opcional)`} value={color.usdzUrl} accept=".usdz" onBusy={onBusy} onChange={url=>editColor(i,{usdzUrl:url})}/>
   <button type="button" className="outline" onClick={()=>update({colors:settings.colors.filter((_,n)=>n!==i)})}>Quitar color</button>
  </div>)}
  <button type="button" className="outline" disabled={settings.colors.length>=20} onClick={()=>update({colors:[...settings.colors,{label:'Nuevo color',hex:'#888888',modelUrl:'',usdzUrl:''}]})}>Añadir color con archivo 3D</button>
  <details><summary>Importar un OBJ básico</summary>
   <p>Convierte la geometría del OBJ a GLB. No incorpora archivos MTL, fotografías ni texturas externas. Para acabados fotorrealistas, exporta un GLB preparado desde Blender. Máximo 20 MB y 300.000 vértices resultantes; comprueba la orientación y la escala antes de guardar.</p>
   <label>Unidad usada al crear el OBJ<select value={units} onChange={e=>setUnits(e.target.value)}><option value="cm">Centímetros</option><option value="m">Metros</option><option value="mm">Milímetros</option></select></label>
   <input type="file" accept=".obj" aria-label="Importar OBJ básico" disabled={busy} onChange={async e=>{
    const file=e.target.files?.[0];if(!file)return;
    setBusy(true);onBusy(true);setStatus('Convirtiendo el OBJ…');
    try{
     if(file.size>20*1024*1024)throw Error('El OBJ supera 20 MB. Optimízalo en Blender.');
     const {convertObj}=await import('./obj-to-glb');
     const result=await convertObj(await file.text(),units);
     const body=new FormData();body.append('file',new File([result.buffer],'modelo.glb',{type:'model/gltf-binary'}));
     const data=await api('/admin/upload',{method:'POST',body});
     onChange({modelUrl:data.url,usdzUrl:'',modelDemo:false,width:result.width,depth:result.depth,height:result.height,viewer:{...settings,materialName:'Tapizado',colors:[]}});
     setStatus('GLB convertido y subido. Revisa la vista previa, la orientación y las medidas; después guarda el producto.');
    }catch(error){setStatus(error.message)}finally{setBusy(false);onBusy(false);e.target.value=''}
   }}/><p role="status">{status}</p>
  </details>
  <div className="model-preview-panel"><button type="button" className="outline" onClick={()=>setPreview(!preview)}>{preview?'Cerrar vista previa 3D':'Revisar el modelo como lo verá el cliente'}</button>
   {preview&&<><p>Esta vista usa los cambios del formulario. Para publicarlos, pulsa «Guardar producto». El aviso de cámara siempre se conserva.</p><Viewer product={p}/></>}
  </div>
 </fieldset>;
}
