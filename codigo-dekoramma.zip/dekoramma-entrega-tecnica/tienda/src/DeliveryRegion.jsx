import React, { useState } from "react";
export const regionKey = "dekoramma-delivery-region";
const departments = ["Amazonas", "Antioquia", "Arauca", "Atlántico", "Bogotá D.C.", "Bolívar", "Boyacá", "Caldas", "Caquetá", "Casanare", "Cauca", "Cesar", "Chocó", "Córdoba", "Cundinamarca", "Guainía", "Guaviare", "Huila", "La Guajira", "Magdalena", "Meta", "Nariño", "Norte de Santander", "Putumayo", "Quindío", "Risaralda", "San Andrés, Providencia y Santa Catalina", "Santander", "Sucre", "Tolima", "Valle del Cauca", "Vaupés", "Vichada"];
export default function DeliveryRegion({ value, onSave }) {
  const [department, setDepartment] = useState(value?.department || "");
  const [city, setCity] = useState(value?.city || "");
  return <form className="form-grid" onSubmit={e => { e.preventDefault(); onSave({ department, city: city.trim() }); }}>
    <p>Cuéntanos dónde recibirías tu mueble para preparar tu consulta de entrega.</p>
    <label>Departamento o distrito<select required value={department} onChange={e => { setDepartment(e.target.value); setCity(e.target.value === "Bogotá D.C." ? "Bogotá" : ""); }}><option value="">Selecciona</option>{departments.map(name => <option key={name}>{name}</option>)}</select></label>
    <label>Ciudad o municipio<input required maxLength={80} value={city} onChange={e => setCity(e.target.value)} placeholder="Escribe tu ciudad" /></label>
    <p className="caption">Dekoramma te confirmará cobertura, costo y plazo de envío. Elegir una ciudad no confirma una tarifa ni solicita tu ubicación GPS.</p>
    <button type="submit" disabled={!department || !city.trim()}>Guardar lugar de entrega</button>
  </form>;
}
