export const welcomeDefaults = {
  enabled: true,
  revision: 1,
  title: "Un espacio hecho para ti.",
  text: "Elige tu mueble, descubre sus colores y conversemos sobre las medidas de tu hogar.",
  image: "/assets/sala-industrial.png",
  mobileImage: "",
  video: "",
  imageAlt: "Sala modular petróleo en un ambiente industrial ilustrativo",
  buttonText: "Explorar muebles",
  target: "catalogo",
  startsAt: "",
  endsAt: "",
};
export function welcomeKey(banner) {
  return `dekoramma:welcome:${banner.revision}`;
}
export function welcomeEligible(banner, now, seen, hash = "") {
  return (
    banner.enabled &&
    !seen &&
    !hash &&
    (!banner.startsAt || now >= Date.parse(banner.startsAt)) &&
    (!banner.endsAt || now < Date.parse(banner.endsAt))
  );
}
