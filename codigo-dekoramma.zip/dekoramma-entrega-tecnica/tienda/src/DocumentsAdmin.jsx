"use client";
import React, { useEffect, useState } from "react";
import { api } from "./api";
const names = {
  terms: "Términos y condiciones",
  privacy: "Privacidad",
  warranty: "Garantías",
  withdrawal: "Retracto y reversión",
  rut: "RUT",
  chamber: "Cámara de Comercio",
  other: "Documento interno / aprobación",
};
const states = {
  draft: "Borrador",
  approved: "Aprobado",
  published: "Publicado",
  archived: "Archivado",
};
const actions = {
  uploaded: "Carga",
  approved: "Aprobación",
  published: "Publicación",
  archived: "Archivo",
};
const date = (v) =>
  new Date(v).toLocaleString("es-CO", {
    timeZone: "America/Bogota",
    dateStyle: "medium",
    timeStyle: "medium",
  });
export default function DocumentsAdmin() {
  const [data, setData] = useState({ documents: [], events: [] }),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [filter, setFilter] = useState("all"),
    [notice, setNotice] = useState("");
  const refresh = () => api("/admin/documents").then(setData);
  useEffect(() => {
    refresh().catch((e) => setError(e.message));
  }, []);
  async function change(doc, status) {
    setBusy(true);
    setError("");
    try {
      await api("/admin/documents/" + doc.id, {
        method: "PATCH",
        body: { status },
      });
      await refresh();
      setNotice(
        "Estado actualizado. La versión anterior y su historial se conservan.",
      );
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <div className="admin-card">
        <h2>Biblioteca documental</h2>
        <p>
          Cada PDF conserva su versión, año, fecha, hora y usuario. Una carga
          nueva no reemplaza el archivo anterior. RUT, Cámara de Comercio y
          documentos internos permanecen privados incluso después de aprobarlos.
        </p>
        <p>
          El NIT del negocio se completa en Tienda. No es necesario inventar
          ceros: mientras no esté confirmado se muestra «Pendiente por editar».
        </p>
        <form
          className="form-grid"
          onSubmit={async (e) => {
            e.preventDefault();
            const form = e.currentTarget;
            const body = new FormData(form);
            setBusy(true);
            setError("");
            try {
              await api("/admin/documents", { method: "POST", body });
              form.reset();
              await refresh();
              setNotice("PDF guardado como borrador con una nueva versión.");
            } catch (e) {
              setError(e.message);
            } finally {
              setBusy(false);
            }
          }}
        >
          <label>
            Título del documento
            <input
              name="title"
              required
              minLength={3}
              maxLength={160}
              placeholder="Ej. RUT actualizado 2026"
            />
          </label>
          <div className="form-two">
            <label>
              Tipo de documento
              <select name="category">
                {Object.entries(names).map(([key, label]) => (
                  <option key={key} value={key}>
                    {label}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Año del documento
              <input
                name="year"
                type="number"
                min={1900}
                max={2100}
                defaultValue={new Date().getFullYear()}
                required
              />
            </label>
          </div>
          <label>
            Archivo PDF · hasta 20 MB
            <input
              name="file"
              type="file"
              accept=".pdf,application/pdf"
              required
            />
          </label>
          <button disabled={busy}>Guardar nueva versión como borrador</button>
        </form>
      </div>
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
      {notice && <p role="status">{notice}</p>}
      <label>
        Filtrar documentos
        <select value={filter} onChange={(e) => setFilter(e.target.value)}>
          <option value="all">Todos</option>
          {Object.entries(names).map(([key, label]) => (
            <option key={key} value={key}>
              {label}
            </option>
          ))}
        </select>
      </label>
      <div className="document-cards">
        {data.documents
          .filter((x) => filter === "all" || x.category === filter)
          .map((doc) => (
            <article className="admin-card" key={doc.id}>
              <p className="eyebrow">
                {names[doc.category]} · {states[doc.status]}
              </p>
              <h3>{doc.title}</h3>
              <p>
                Año {doc.document_year} · Versión {doc.version} ·{" "}
                {Math.ceil(doc.byte_size / 1024)} KB
              </p>
              <p>
                Cargado: {date(doc.created_at)}
                <br />
                Por: {doc.created_by}
                <br />
                Último cambio: {date(doc.updated_at)}
              </p>
              <a
                href={"/api/admin/documents/" + doc.id + "/file"}
                target="_blank"
                rel="noreferrer"
              >
                Descargar esta versión
              </a>
              <div className="actions">
                {doc.status === "draft" && (
                  <button
                    disabled={busy}
                    onClick={() => change(doc, "approved")}
                  >
                    Marcar como aprobado
                  </button>
                )}
                {doc.status === "approved" &&
                  ["terms", "privacy", "warranty", "withdrawal"].includes(
                    doc.category,
                  ) && (
                    <button
                      disabled={busy}
                      onClick={() => change(doc, "published")}
                    >
                      Publicar en información al cliente
                    </button>
                  )}
                {doc.status !== "archived" && (
                  <button
                    className="outline"
                    disabled={busy}
                    onClick={() => change(doc, "archived")}
                  >
                    Archivar conservando historial
                  </button>
                )}
              </div>
              <details>
                <summary>Huella de integridad del archivo</summary>
                <code className="document-hash">SHA-256: {doc.sha256}</code>
              </details>
            </article>
          ))}
      </div>
      {!data.documents.length && <p>Todavía no hay PDFs cargados.</p>}
      <div className="admin-card table-scroll">
        <h2>Registro documental</h2>
        <p>
          Fechas y horas mostradas en la zona de Bogotá. El historial conserva
          cargas y cambios de estado.
        </p>
        <table className="admin-table">
          <thead>
            <tr>
              <th>Fecha y hora</th>
              <th>Documento</th>
              <th>Acción</th>
              <th>Usuario</th>
            </tr>
          </thead>
          <tbody>
            {data.events.map((event) => (
              <tr key={event.id}>
                <td>{date(event.created_at)}</td>
                <td>{event.title}</td>
                <td>{actions[event.action] || event.action}</td>
                <td>{event.actor}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
