// Convenience gate for the public GitHub demonstration, NOT server authentication.
// Never use this module to authorize access to private information or real writes.
export async function verifyDemoAccess(email, password, config) {
  const input = new TextEncoder().encode(email.trim().toLowerCase() + '\n' + password);
  const key = await crypto.subtle.importKey('raw', input, 'PBKDF2', false, ['deriveBits']);
  const salt = Uint8Array.from(config.salt.match(/.{2}/g), h => parseInt(h, 16));
  const bits = await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt,iterations:config.iterations},key,256);
  const actual = Array.from(new Uint8Array(bits), b=>b.toString(16).padStart(2,'0')).join('');
  return actual === config.digest;
}
export function demoSessionValid(value, version, now = Date.now()) {
  try {
    const session = JSON.parse(value);
    return session?.version === version && Number.isFinite(session.expires) && session.expires > now && session.expires <= now + 8*3600000;
  } catch { return false; }
}
