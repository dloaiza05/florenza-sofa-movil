"use client";
import React, { useState } from "react";
import { api, mediaUrl } from "./api";
export default function ProductMediaEditor({ product: p, onChange, onBusy }) {
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const photos = p.gallery?.length
    ? p.gallery
    : p.image
      ? [{ url: p.image, color: "", alt: p.name }]
      : [];
  const videos = p.videos?.length
    ? p.videos
    : p.videoUrl
      ? [{ url: p.videoUrl, title: "Video del producto" }]
      : [];
  function savePhotos(next) {
    onChange({ gallery: next, image: next[0]?.url || "" });
  }
  async function upload(e, video = false) {
    const files = Array.from(e.target.files || []);
    e.target.value = "";
    if (!files.length) return;
    const limit = video ? 3 : 10,
      existing = video ? videos : photos;
    if (existing.length + files.length > limit) {
      setError(
        "Puedes guardar hasta " +
          limit +
          " " +
          (video ? "videos" : "fotografías") +
          " por producto.",
      );
      return;
    }
    setBusy(true);
    onBusy(true);
    setError("");
    const next = [...existing];
    try {
      for (const file of files) {
        if (file.size > 100 * 1024 * 1024)
          throw Error("Cada archivo debe pesar como máximo 100 MB.");
        const body = new FormData();
        body.append("file", file);
        const result = await api("/admin/upload", { method: "POST", body });
        next.push(
          video
            ? {
                url: result.url,
                title: file.name.replace(/\.mp4$/i, "").slice(0, 100),
              }
            : { url: result.url, color: "", alt: p.name },
        );
        if (video)
          onChange({ videos: [...next], videoUrl: next[0]?.url || "" });
        else savePhotos([...next]);
      }
    } catch (err) {
      setError(
        err.message +
          " Los archivos subidos correctamente permanecen en el formulario.",
      );
    } finally {
      setBusy(false);
      onBusy(false);
    }
  }
  return (
    <fieldset disabled={busy} className="media-editor">
      <legend>Fotografías y videos del producto</legend>
      <p>
        Hasta 10 fotos y 3 videos MP4 de 3 minutos. Puedes seleccionar varios
        archivos. La primera foto es la portada; vincula las demás con sus
        colores.
      </p>
      <label>
        Subir fotografías ({photos.length}/10)
        <input
          type="file"
          multiple
          accept=".png,.jpg,.jpeg,.webp"
          onChange={(e) => upload(e)}
        />
      </label>
      <div className="media-edit-grid">
        {photos.map((photo, i) => (
          <div className="media-edit-card" key={i}>
            <img
              src={mediaUrl(photo.url)}
              alt={photo.alt || "Fotografía " + (i + 1)}
              loading="lazy"
            />
            <strong>{i === 0 ? "Portada" : "Foto " + (i + 1)}</strong>
            <label>
              Color de esta foto
              <select
                value={photo.color}
                onChange={(e) =>
                  savePhotos(
                    photos.map((x, n) =>
                      n === i ? { ...x, color: e.target.value } : x,
                    ),
                  )
                }
              >
                <option value="">Vista general</option>
                {p.colors.filter(Boolean).map((c) => (
                  <option key={c}>{c}</option>
                ))}
              </select>
            </label>
            <label>
              Descripción accesible
              <input
                maxLength={160}
                value={photo.alt}
                onChange={(e) =>
                  savePhotos(
                    photos.map((x, n) =>
                      n === i ? { ...x, alt: e.target.value } : x,
                    ),
                  )
                }
              />
            </label>
            <div className="actions">
              {i > 0 && (
                <button
                  type="button"
                  className="outline"
                  onClick={() =>
                    savePhotos([photo, ...photos.filter((_, n) => n !== i)])
                  }
                >
                  Usar de portada
                </button>
              )}
              <button
                type="button"
                className="outline"
                onClick={() => savePhotos(photos.filter((_, n) => n !== i))}
              >
                Quitar foto
              </button>
            </div>
          </div>
        ))}
      </div>
      <label>
        Subir videos ({videos.length}/3)
        <input
          type="file"
          multiple
          accept=".mp4"
          onChange={(e) => upload(e, true)}
        />
      </label>
      {videos.map((video, i) => (
        <div className="media-edit-card" key={i}>
          <video className="video" src={video.url} preload="none" controls />
          <label>
            Título del video
            <input
              value={video.title}
              required
              maxLength={100}
              onChange={(e) =>
                onChange({
                  videos: videos.map((x, n) =>
                    n === i ? { ...x, title: e.target.value } : x,
                  ),
                })
              }
            />
          </label>
          <button
            type="button"
            className="outline"
            onClick={() => {
              const next = videos.filter((_, n) => n !== i);
              onChange({ videos: next, videoUrl: next[0]?.url || "" });
            }}
          >
            Quitar video
          </button>
        </div>
      ))}
      {busy && (
        <p role="status">
          Subiendo y validando archivos… Espera antes de guardar.
        </p>
      )}
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
    </fieldset>
  );
}
