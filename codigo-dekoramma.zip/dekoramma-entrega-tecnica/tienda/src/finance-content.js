export const financeBanners = [
  {
    id: "credit",
    title: "Tu próximo espacio, a tu ritmo.",
    text: "Conoce las opciones de financiación para el mueble que tienes en mente.",
    button: "Consultar financiación",
  },
  {
    id: "bank",
    title: "Elige tu mueble. Elige cómo pagar.",
    text: "Tarjeta débito, crédito o PSE. Revisa las condiciones del canal que prefieras.",
    button: "Ver opciones de pago",
  },
  {
    id: "wallet",
    title: "Desde tu celular, más cerca de casa.",
    text: "Consulta las opciones disponibles con tu billetera digital.",
    button: "Consultar billeteras",
  },
];
