import React from "react";
import directory from "./official-payment-directory.json";

function Entries({ items }) {
  return items.map((item) => (
    <article key={item.name}>
      <strong>{item.name}</strong>
      <p>{item.note}</p>
      <a href={item.url} target="_blank" rel="noopener noreferrer">
        Sitio oficial ↗
      </a>
      {item.socials.map((url) => (
        <a key={url} href={url} target="_blank" rel="noopener noreferrer">
          {new URL(url).hostname.replace(/^www\./, "")} ·{" "}
          {decodeURIComponent(new URL(url).pathname).replace(/\/$/, "")} ↗
        </a>
      ))}
    </article>
  ));
}
export default function OfficialPaymentDirectory() {
  return (
    <details className="editor-section official-payment-directory">
      <summary>Directorio de entidades · sitios y redes oficiales</summary>
      <p>
        Consulta realizada el {directory.checked}. Directorio de referencia para
        el equipo: estos enlaces no son enlaces de cobro y no activan convenios.
      </p>
      <h3>Crédito, pasarelas y billeteras</h3>
      <Entries items={directory.providers} />
      <details>
        <summary>
          Ver {directory.banks.length} bancos enlazados desde PSE
        </summary>
        <p>
          La lista se obtuvo del{" "}
          <a
            href="https://www.pse.com.co/persona"
            target="_blank"
            rel="noopener noreferrer"
          >
            sitio de PSE
          </a>
          . Pagar desde un banco no implica financiación de la compra. Las redes
          se incluyen cuando estaban enlazadas desde su sitio; las demás quedan
          pendientes de comprobar.
        </p>
        <Entries items={directory.banks} />
      </details>
    </details>
  );
}
