"use client";
import React, { useState, useRef, useEffect } from "react";
import { ArrowLeft, ArrowRight, LockKeyhole, Check } from "lucide-react";
import { api } from "./api";
import PaymentChoices from "./PaymentChoices";

export default function Checkout({ items, methods, onDone, legalFingerprint }) {
  const [step, setStep] = useState(1),
    [furthest, setFurthest] = useState(1),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const [customer, setCustomer] = useState({
      email: "",
      name: "",
      phone: "",
      city: "",
      address: "",
      notes: "",
    }),
    [method, setMethod] = useState(""),
    [consent, setConsent] = useState(false),
    [termsAccepted, setTermsAccepted] = useState(false);
  const key = useRef(crypto.randomUUID()),
    token = useRef(
      Array.from(crypto.getRandomValues(new Uint8Array(32)), (x) =>
        x.toString(16).padStart(2, "0"),
      ).join(""),
    ),
    heading = useRef(null),
    previousStep = useRef(1);
  useEffect(() => {
    if (previousStep.current !== step) {
      heading.current?.focus();
      previousStep.current = step;
    }
  }, [step]);
  const change = (e) =>
    setCustomer({ ...customer, [e.target.name]: e.target.value });
  const navigate = (n) => {
    setError("");
    setStep(n);
  };
  async function submit(e) {
    e.preventDefault();
    setError("");
    if (step < 3) {
      setFurthest(Math.max(furthest, step + 1));
      setStep(step + 1);
      return;
    }
    setBusy(true);
    try {
      const result = await api("/orders", {
        method: "POST",
        body: {
          items,
          method,
          customer: { ...customer, consent },
          termsAccepted,
          legalFingerprint,
          idempotencyKey: key.current,
          trackingToken: token.current,
        },
      });
      try {
        localStorage.setItem(
          "dk-tracking",
          JSON.stringify({ id: result.id, token: token.current }),
        );
      } catch {
        /* Purchase result remains available even when browser storage is disabled. */
      }
      onDone({ ...result, trackingToken: token.current });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <form className="form-grid progressive-checkout" onSubmit={submit}>
      <nav className="checkout-steps" aria-label="Pasos de compra">
        {["Contacto", "Entrega", "Pago"].map((label, i) => (
          <button
            key={label}
            type="button"
            disabled={busy || i + 1 > furthest}
            aria-current={step === i + 1 ? "step" : undefined}
            onClick={(e) => {
              if (i + 1 > step && !e.currentTarget.form.reportValidity())
                return;
              navigate(i + 1);
            }}
          >
            <span>{i + 1 < step ? <Check size={14} /> : i + 1}</span>
            {label}
          </button>
        ))}
      </nav>
      <h3 ref={heading} tabIndex={-1}>
        {step === 1
          ? "Empecemos por tu correo."
          : step === 2
            ? "¿Quién recibe y dónde?"
            : "Elige cómo quieres pagar."}
      </h3>
      {step === 1 && (
        <>
          <p className="caption">
            Compra como invitado, sin crear una cuenta. El correo nos permite
            asociar tu solicitud y sus comprobantes.
          </p>
          <label>
            Correo electrónico
            <input
              name="email"
              type="email"
              value={customer.email}
              onChange={change}
              autoComplete="email"
              required
              maxLength={150}
              placeholder="tu@correo.com"
            />
          </label>
          <p className="caption">
            Tus datos no se enviarán hasta confirmar la solicitud. Consulta la{" "}
            <a href="/informacion#privacidad" target="_blank" rel="noreferrer">
              política de privacidad
            </a>
            .
          </p>
          <div
            className="checkout-method-preview"
            aria-label="Opciones de pago por habilitar"
          >
            <span>Tarjetas</span>
            <span>PSE</span>
            <span>Financiación</span>
          </div>
        </>
      )}
      {step === 2 && (
        <>
          <p className="caption">
            Solo los datos necesarios para coordinar tu entrega. El flete se
            confirmará antes del cobro.
          </p>
          <label>
            Nombre completo
            <input
              name="name"
              value={customer.name}
              onChange={change}
              autoComplete="name"
              required
              maxLength={100}
            />
          </label>
          <label>
            Celular de contacto
            <input
              name="phone"
              type="tel"
              value={customer.phone}
              onChange={change}
              autoComplete="tel"
              required
              pattern={"[+0-9\\s\\-]{7,22}"}
              maxLength={22}
            />
          </label>
          <label>
            Ciudad
            <input
              name="city"
              value={customer.city}
              onChange={change}
              autoComplete="address-level2"
              required
              maxLength={100}
            />
          </label>
          <label>
            Dirección de entrega
            <input
              name="address"
              value={customer.address}
              onChange={change}
              autoComplete="street-address"
              required
              maxLength={250}
            />
          </label>
          <details className="checkout-optional">
            <summary>
              Apartamento, indicaciones u observaciones (opcional)
            </summary>
            <textarea
              aria-label="Indicaciones de entrega"
              name="notes"
              value={customer.notes}
              onChange={change}
              maxLength={1000}
            />
          </details>
        </>
      )}
      {step === 3 && (
        <>
          <div className="checkout-contact-summary">
            <strong>{customer.name}</strong>
            <p>
              {customer.email} · {customer.phone}
            </p>
            <p>
              {customer.address}, {customer.city}
            </p>
            <button
              type="button"
              className="text-button"
              onClick={() => navigate(2)}
            >
              Editar entrega
            </button>
          </div>
          <PaymentChoices
            methods={methods}
            value={method}
            onChange={setMethod}
          />
          <p className="caption">
            Consulta los{" "}
            <a href="/informacion#terminos" target="_blank" rel="noreferrer">
              términos
            </a>
            , la{" "}
            <a href="/informacion#privacidad" target="_blank" rel="noreferrer">
              privacidad
            </a>{" "}
            y las{" "}
            <a href="/informacion#garantias" target="_blank" rel="noreferrer">
              garantías
            </a>
            .
          </p>
          <label className="check">
            <input
              type="checkbox"
              checked={consent}
              onChange={(e) => setConsent(e.target.checked)}
              required
            />
            Autorizo usar estos datos para atender mi solicitud.
          </label>
          <label className="check">
            <input
              type="checkbox"
              checked={termsAccepted}
              onChange={(e) => setTermsAccepted(e.target.checked)}
              required
            />
            He leído y acepto los términos de esta solicitud de compra.
          </label>
        </>
      )}
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
      <div className="checkout-actions">
        {step > 1 && (
          <button
            type="button"
            disabled={busy}
            className="outline"
            onClick={() => navigate(step - 1)}
          >
            <ArrowLeft size={16} /> Volver
          </button>
        )}
        <button disabled={busy}>
          {busy
            ? "Registrando…"
            : step === 1
              ? "Continuar a entrega"
              : step === 2
                ? "Elegir forma de pago"
                : "Enviar solicitud de compra"}
          {step < 3 && <ArrowRight size={16} />}
        </button>
      </div>
      <p className="payment-security">
        <LockKeyhole size={16} />
        Tus datos de tarjeta se ingresarán únicamente en la pasarela al
        habilitar el cobro.
      </p>
    </form>
  );
}
