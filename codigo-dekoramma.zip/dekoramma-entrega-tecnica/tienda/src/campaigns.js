export function activeCampaigns(campaigns, demo, now) {
  if (demo !== true) return [];
  return campaigns.filter(
    (c) =>
      c.enabled &&
      c.simulation === true &&
      Date.parse(c.startsAt) <= now &&
      now < Date.parse(c.endsAt),
  );
}
export function remainingTime(end, now) {
  const seconds = Math.max(0, Math.ceil((Date.parse(end) - now) / 1000) || 0);
  return [
    Math.floor(seconds / 86400),
    Math.floor(seconds / 3600) % 24,
    Math.floor(seconds / 60) % 60,
    seconds % 60,
  ];
}
