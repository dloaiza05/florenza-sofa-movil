// Browser-only rehearsal data. This module never writes to GitHub or the server.
const databaseName='dekoramma-rehearsal-v1';
const prefix='demo-media:';
let opened;
const objectUrls=new Map(),reverseUrls=new Map();
function database(){
  return opened ||= new Promise((resolve,reject)=>{
    const request=indexedDB.open(databaseName,1);
    request.onupgradeneeded=()=>{request.result.createObjectStore('state');request.result.createObjectStore('media')};
    request.onsuccess=()=>resolve(request.result);
    request.onerror=()=>reject(Error('Este navegador no permite guardar la prueba. Revisa sus ajustes de almacenamiento.'));
  });
}
async function transaction(store,mode,operation){
  const db=await database();
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(store,mode),request=operation(tx.objectStore(store));
    tx.oncomplete=()=>resolve(request?.result);
    tx.onerror=tx.onabort=()=>reject(Error('No se guardó la prueba. Puede faltar espacio en este dispositivo.'));
  });
}
async function hydrate(value){
  if(typeof value==='string'&&value.startsWith(prefix)){
    if(!objectUrls.has(value)){
      const blob=await transaction('media','readonly',s=>s.get(value));
      if(!blob)return '';
      const url=URL.createObjectURL(blob)+'#'+value.slice(prefix.length);
      objectUrls.set(value,url);reverseUrls.set(url,value);
    }
    return objectUrls.get(value);
  }
  if(Array.isArray(value))return Promise.all(value.map(hydrate));
  if(value&&typeof value==='object')return Object.fromEntries(await Promise.all(Object.entries(value).map(async([k,v])=>[k,await hydrate(v)])));
  return value;
}
function dehydrate(value){
  if(typeof value==='string')return reverseUrls.get(value)||value;
  if(Array.isArray(value))return value.map(dehydrate);
  if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,dehydrate(v)]));
  return value;
}
export function detectDemoMedia(bytes){
  const text=new TextDecoder().decode(bytes);
  if(bytes[0]===255&&bytes[1]===216&&bytes[2]===255)return ['jpg','image/jpeg'];
  if(bytes[0]===137&&text.slice(1,4)==='PNG')return ['png','image/png'];
  if(text.slice(0,4)==='RIFF'&&text.slice(8,12)==='WEBP')return ['webp','image/webp'];
  if(text.slice(4,8)==='ftyp')return ['mp4','video/mp4'];
  if(text.slice(0,4)==='glTF')return ['glb','model/gltf-binary'];
  if(bytes[0]===80&&bytes[1]===75&&bytes[2]===3&&bytes[3]===4)return ['usdz','model/vnd.usdz+zip'];
  if(text.startsWith('%PDF-'))return ['pdf','application/pdf'];
  throw Error('Usa JPG, PNG, WEBP, MP4, GLB, USDZ o PDF. El contenido del archivo debe corresponder al formato.');
}
function videoDuration(blob){return new Promise((resolve,reject)=>{
  const video=document.createElement('video'),url=URL.createObjectURL(blob);
  const finish=(error)=>{clearTimeout(timer);video.removeAttribute('src');video.load();URL.revokeObjectURL(url);error?reject(Error(error)):resolve()};
  const timer=setTimeout(()=>finish('No pudimos leer este video. Prueba un MP4 compatible.'),15000);
  video.preload='metadata';video.onloadedmetadata=()=>finish(Number.isFinite(video.duration)&&video.duration>0&&video.duration<=180?null:'El video debe durar como máximo 3 minutos.');
  video.onerror=()=>finish('Este video no se puede reproducir. Usa MP4 compatible.');video.src=url;
})}
export function createRehearsalStore(fallback){
  let queue=Promise.resolve();
  const read=async()=>structuredClone(await transaction('state','readonly',s=>s.get('catalog'))||fallback);
  const notify=()=>{if(typeof BroadcastChannel!=='undefined'){const c=new BroadcastChannel(databaseName);c.postMessage('changed');c.close()}};
  const mutate=fn=>{
    const next=queue.then(async()=>{const state=await read();const result=fn(state);await transaction('state','readwrite',s=>s.put(dehydrate(state),'catalog'));notify();return hydrate(result)});
    queue=next.catch(()=>{});return next;
  };
  return {
    catalog:async()=>hydrate(await read()),
    reset(){
      const next=queue.then(async()=>{
        const db=await database();
        await new Promise((resolve,reject)=>{
          const tx=db.transaction(['state','media'],'readwrite');
          tx.objectStore('state').clear();tx.objectStore('media').clear();
          tx.oncomplete=resolve;tx.onerror=tx.onabort=()=>reject(Error('No se pudo restablecer la prueba. Inténtalo nuevamente.'));
        });
        for(const url of objectUrls.values())URL.revokeObjectURL(url.split('#')[0]);objectUrls.clear();reverseUrls.clear();notify();
      });
      queue=next.catch(()=>{});return next;
    },
    async request(url,{method='GET',body}={}){
      if(method==='GET'){
        const state=await hydrate(await read());
        if(url==='/admin/data')return {products:state.products,settings:state.settings,orders:[],leads:[]};
        if(url==='/admin/content')return state.content;
        if(url==='/admin/documents')return state.documents||{documents:[],events:[]};
        if(url.startsWith('/admin/marketing?'))return {contacts:[],total:0,pages:1};
      }
      if(method==='POST'&&url==='/admin/upload'){
        const file=body.get('file');
        if(!(file instanceof Blob)||!file.size)throw Error('Selecciona un archivo.');
        if(file.size>100*1024*1024)throw Error('Máximo 100 MB por archivo. Para probar con agilidad, usa archivos pequeños.');
        const [extension,mime]=detectDemoMedia(new Uint8Array(await file.slice(0,32).arrayBuffer()));
        if(extension==='pdf')throw Error('Los PDF se cargan en Documentos.');
        const blob=new Blob([file],{type:mime});
        if(extension==='mp4')await videoDuration(blob);
        if(extension==='glb'){
          const buffer=await blob.arrayBuffer(), view=new DataView(buffer);
          if(buffer.byteLength<20||view.getUint32(4,true)!==2||view.getUint32(8,true)!==buffer.byteLength||view.getUint32(16,true)!==0x4e4f534a)throw Error('El GLB no es un modelo válido de versión 2.');
          const length=view.getUint32(12,true);
          if(length>buffer.byteLength-20)throw Error('El GLB está incompleto.');
          const scene=JSON.parse(new TextDecoder().decode(new Uint8Array(buffer,20,length)));
          if([...(scene.buffers||[]),...(scene.images||[])].some(item=>item.uri&&!item.uri.startsWith('data:')))throw Error('Exporta un GLB con sus texturas y recursos incorporados.');
        }
        const key=prefix+crypto.randomUUID()+'.'+extension;
        await transaction('media','readwrite',s=>s.put(blob,key));
        return {url:await hydrate(key)};
      }
      if(method==='PUT')return mutate(state=>{
        if(url==='/admin/settings'){state.settings=dehydrate(body);return state.settings}
        if(url==='/admin/content'){state.content=dehydrate(body);return state.content}
        if(url.startsWith('/admin/products/')){
          const product=dehydrate(body),i=state.products.findIndex(p=>p.id===product.id);
          if(i<0)state.products.push(product);else state.products[i]=product;
          return product;
        }
        throw Error('Esta acción todavía requiere el servidor de la tienda.');
      });
      if(method==='DELETE'&&url.startsWith('/admin/products/'))return mutate(state=>{const p=state.products.find(p=>p.id===url.split('/').at(-1));if(p)p.active=false;return {ok:true}});
      throw Error('Esta función requiere el servidor. En este ensayo puedes guardar productos, fotos, videos, modelos, textos y campañas en este navegador.');
    }
  };
}
