import React, { useEffect, useRef, useState } from "react";
import BannerMedia from "./BannerMedia";
import { welcomeDefaults, welcomeEligible } from "./welcome-banner";
export default function WelcomeBanner({
  banner = welcomeDefaults,
  Modal,
  suppressed = false,
}) {
  const [open, setOpen] = useState(false);
  const shown = useRef(false);
  useEffect(() => {
    if (suppressed || shown.current) return;
    // Show once per page load, including refreshes and direct section links.
    if (!welcomeEligible(banner, Date.now())) return;
    shown.current = true;
    setOpen(true);
  }, [banner, suppressed]);
  if (!open || !banner.enabled) return null;
  return (
    <Modal title={banner.title} onClose={() => setOpen(false)} wide>
      <div className="welcome-banner">
        <BannerMedia banner={banner} />
        <div className="welcome-banner-copy">
          <p>{banner.text}</p>
          <a
            className="button"
            href={`#${banner.target}`}
            onClick={() => setOpen(false)}
          >
            {banner.buttonText}
          </a>
          <button className="text-button" onClick={() => setOpen(false)}>
            Continuar viendo la tienda
          </button>
        </div>
      </div>
    </Modal>
  );
}
