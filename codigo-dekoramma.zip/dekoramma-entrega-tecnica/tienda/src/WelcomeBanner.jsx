import React, { useEffect, useRef, useState } from "react";
import BannerMedia from "./BannerMedia";
import { welcomeDefaults, welcomeEligible, welcomeKey } from "./welcome-banner";
export default function WelcomeBanner({
  banner = welcomeDefaults,
  Modal,
  suppressed = false,
}) {
  const [open, setOpen] = useState(false);
  const shown = useRef(false);
  useEffect(() => {
    if (suppressed || shown.current) return;
    let seen = false;
    const preview =
      new URLSearchParams(location.search).get("vista") === "bienvenida";
    try {
      seen = sessionStorage.getItem(welcomeKey(banner)) === "seen";
    } catch {}
    if (
      !welcomeEligible(
        banner,
        Date.now(),
        preview ? false : seen,
        preview ? "" : location.hash,
      )
    )
      return;
    shown.current = true;
    try {
      if (!preview) sessionStorage.setItem(welcomeKey(banner), "seen");
    } catch {}
    setOpen(true);
  }, [banner, suppressed]);
  if (!open || !banner.enabled) return null;
  return (
    <Modal title={banner.title} onClose={() => setOpen(false)} wide>
      <div className="welcome-banner">
        <BannerMedia banner={banner} />
        <div className="welcome-banner-copy">
          <p>{banner.text}</p>
          <a
            className="button"
            href={`#${banner.target}`}
            onClick={() => setOpen(false)}
          >
            {banner.buttonText}
          </a>
          <button className="text-button" onClick={() => setOpen(false)}>
            Continuar viendo la tienda
          </button>
        </div>
      </div>
    </Modal>
  );
}
