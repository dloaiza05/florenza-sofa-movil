// This adapter never calls administrative endpoints or persists changes.
export function createAdminPreviewApi(catalog) {
  const state = structuredClone({
    products: catalog.products,
    settings: catalog.settings,
    content: catalog.content,
  });
  const documents = { documents: [], events: [] };
  return async (url, { method = "GET", body } = {}) => {
    if (method === "GET") {
      if (url === "/admin/data")
        return structuredClone({
          products: state.products,
          settings: state.settings,
          orders: [],
          leads: [],
        });
      if (url === "/admin/content") return structuredClone(state.content);
      if (url === "/admin/documents") return structuredClone(documents);
      if (url.startsWith("/admin/marketing?"))
        return { contacts: [], total: 0, pages: 1 };
    }
    if (method === "PUT") {
      if (url === "/admin/content") {
        state.content = structuredClone(body);
        return structuredClone(body);
      }
      if (url === "/admin/settings") {
        state.settings = structuredClone(body);
        return structuredClone(body);
      }
      if (url.startsWith("/admin/products/")) {
        const copy = structuredClone(body),
          index = state.products.findIndex((p) => p.id === copy.id);
        if (index < 0) state.products.push(copy);
        else state.products[index] = copy;
        return structuredClone(copy);
      }
    }
    if (method === "DELETE" && url.startsWith("/admin/products/")) {
      const item = state.products.find((p) => p.id === url.split("/").at(-1));
      if (item) item.active = false;
      return { ok: true };
    }
    throw new Error(
      "Esta acción requiere iniciar sesión. La demostración no sube archivos ni modifica la tienda.",
    );
  };
}
let preview;
export function adminPreviewRequest(url, options) {
  preview ||= fetch("/api/catalog", { credentials: "omit" }).then(
    async (response) => {
      if (!response.ok)
        throw new Error("No se pudo cargar la demostración del catálogo");
      return createAdminPreviewApi(await response.json());
    },
  );
  return preview.then((request) => request(url, options));
}
