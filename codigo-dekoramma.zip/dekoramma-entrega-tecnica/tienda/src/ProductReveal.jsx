import React, { useEffect, useRef, useState } from "react";
import "./product-reveal.css";

export default function ProductReveal({ children }) {
  const element = useRef(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const motion = window.matchMedia("(prefers-reduced-motion: reduce)");
    let observer;
    const observe = () => {
      observer?.disconnect();
      setVisible(false);
      if (motion.matches || !window.IntersectionObserver) return;
      observer = new IntersectionObserver(([entry]) => {
        if (entry.intersectionRatio >= .3) setVisible(true);
        else if (!entry.isIntersecting) setVisible(false);
      }, { threshold: [0, .3], rootMargin: "0px 0px -6% 0px" });
      if (element.current) observer.observe(element.current);
    };
    observe();
    motion.addEventListener("change", observe);
    return () => { observer?.disconnect(); motion.removeEventListener("change", observe); };
  }, []);
  return <div ref={element} className="product-photo photo-reveal" data-in-view={visible}>{children}</div>;
}
