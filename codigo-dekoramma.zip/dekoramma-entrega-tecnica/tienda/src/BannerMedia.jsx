import React, { useEffect, useRef } from "react";
import { mediaUrl } from "./api";
export default function BannerMedia({ banner, onPlay }) {
  const video = useRef(null);
  useEffect(() => {
    const node = video.current;
    if (!node) return;
    const pause = () => {
      if (document.hidden) node.pause();
    };
    const observer = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting) node.pause();
    });
    observer.observe(node);
    document.addEventListener("visibilitychange", pause);
    return () => {
      node.pause();
      observer.disconnect();
      document.removeEventListener("visibilitychange", pause);
    };
  }, [banner.video]);
  if (banner.video)
    return (
      <video
        ref={video}
        className="banner-video"
        controls
        playsInline
        preload="none"
        poster={mediaUrl(banner.image)}
        aria-label={banner.imageAlt}
        onPlay={onPlay}
        key={banner.video}
      >
        <source src={mediaUrl(banner.video)} type="video/mp4" />
        Tu navegador no permite reproducir este video.
      </video>
    );
  return (
    <picture>
      {banner.mobileImage && (
        <source
          media="(max-width:600px)"
          srcSet={mediaUrl(banner.mobileImage)}
        />
      )}
      <img src={mediaUrl(banner.image)} alt={banner.imageAlt} />
    </picture>
  );
}
