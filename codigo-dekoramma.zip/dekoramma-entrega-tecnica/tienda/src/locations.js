/** Hecho por Leidy Rodriguez · 11/09/2026 · Florenza Digital */
export function mapSearch(query, placeId = "") {
  const params = new URLSearchParams({ api: "1", query });
  if (placeId) params.set("query_place_id", placeId);
  return "https://www.google.com/maps/search/?" + params;
}
export function storeDirections(settings) {
  const params = new URLSearchParams({
    api: "1",
    destination: settings.address,
  });
  if (settings.mapsPlaceId)
    params.set("destination_place_id", settings.mapsPlaceId);
  return "https://www.google.com/maps/dir/?" + params;
}
export const whatsappDraft = (phone, text) =>
  "https://wa.me/" + phone + "?text=" + encodeURIComponent(text);
export function storeShare(settings) {
  return whatsappDraft(
    "",
    settings.storeName +
      "\n" +
      settings.address +
      "\n" +
      mapSearch(settings.address, settings.mapsPlaceId),
  );
}
export function deliveryDraft(settings, { address = "", coordinates = null }) {
  const query = coordinates
    ? coordinates.latitude.toFixed(6) + "," + coordinates.longitude.toFixed(6)
    : address.trim();
  return {
    map: mapSearch(query),
    url: whatsappDraft(
      settings.phone,
      "Hola " +
        settings.storeName +
        ", quiero cotizar la entrega de un mueble.\n" +
        (coordinates ? "Esta es mi ubicación elegida." : address.trim()) +
        "\n" +
        mapSearch(query) +
        "\nPor favor confirmen cobertura y costo.",
    ),
  };
}
