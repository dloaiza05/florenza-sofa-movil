"use client";
import React, { useState } from "react";
import { money, mediaUrl } from "./api";
import Explore3DButton from "./Explore3DButton";
export default function ProductDetail({
  product: p,
  initialColor,
  onAdd,
  on3d,
  onQuote,
}) {
  const photos = p.gallery?.length
    ? p.gallery
    : [{ url: p.image, alt: p.name, color: "" }];
  const selectedColor = p.colors.includes(initialColor)
    ? initialColor
    : p.colors[0];
  const [index, setIndex] = useState(
      Math.max(
        0,
        photos.findIndex((x) => x.color === selectedColor),
      ),
    ),
    [color, setColor] = useState(selectedColor);
  const videos = p.videos?.length
    ? p.videos
    : p.videoUrl
      ? [{ url: p.videoUrl, title: "Conoce este producto" }]
      : [];
  return (
    <div className="product-detail">
      <div className="product-gallery">
        <a
          href={mediaUrl(photos[index].url)}
          target="_blank"
          rel="noreferrer"
          title="Abrir fotografía en tamaño completo"
        >
          <img
            className="detail-photo"
            src={mediaUrl(photos[index].url)}
            alt={photos[index].alt || p.name}
          />
        </a>
        <div className="photo-thumbs" aria-label="Fotografías del producto">
          {photos.map((photo, i) => (
            <button
              key={i}
              className={i === index ? "selected" : ""}
              aria-label={
                "Ver foto " + (i + 1) + (photo.color ? " · " + photo.color : "")
              }
              aria-pressed={i === index}
              onClick={() => {
                setIndex(i);
                if (photo.color) setColor(photo.color);
              }}
            >
              <img
                loading="lazy"
                src={mediaUrl(photo.url)}
                alt={photo.alt || p.name}
              />
            </button>
          ))}
        </div>
        <p className="caption">
          Foto {index + 1} de {photos.length}
          {photos[index].color ? " · " + photos[index].color : ""}. Abre la
          fotografía para ampliarla.
        </p>
        {/ilustrativa|generada/i.test(photos[index].alt || "") && (
          <p className="caption">
            Imagen ilustrativa generada. Confirma el tono y acabado con la
            muestra de tela real.
          </p>
        )}
        {videos.map((video, i) => (
          <div key={video.url}>
            <h4>{video.title}</h4>
            <video
              className="video"
              controls
              playsInline
              preload="none"
              src={video.url}
            />
          </div>
        ))}
      </div>
      <div>
        <p className="eyebrow">{p.category}</p>
        <h3>{money(p.price)}</h3>
        <p>{p.description}</p>
        <label>
          Color seleccionado
          <select
            value={color}
            onChange={(e) => {
              setColor(e.target.value);
              const i = photos.findIndex((x) => x.color === e.target.value);
              if (i >= 0) setIndex(i);
            }}
          >
            {p.colors.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </label>
        {!photos.some((x) => x.color === color) && (
          <p className="caption">
            La fotografía es de referencia; aún no hay una foto vinculada a este
            color.
          </p>
        )}
        <dl className="product-specs">
          <dt>Medidas · ancho × fondo × alto</dt>
          <dd>
            {p.width} × {p.depth} × {p.height} cm
          </dd>
          {p.materials && (
            <>
              <dt>Materiales</dt>
              <dd>{p.materials}</dd>
            </>
          )}
          {p.leadTime && (
            <>
              <dt>Disponibilidad y plazo</dt>
              <dd>{p.leadTime}</dd>
            </>
          )}
          {p.care && (
            <>
              <dt>Cuidados</dt>
              <dd>{p.care}</dd>
            </>
          )}
        </dl>
        {p.madeToMeasure && (
          <p className="made-to-measure">
            Fabricación a tu medida. Cotizamos los ajustes antes de confirmar el
            pedido.
          </p>
        )}
        <div className="actions">
          <button onClick={() => onAdd(p, color)}>Comprar ahora</button>
          {p.modelUrl && (
            <Explore3DButton
              inline
              productName={p.name}
              onClick={() => on3d(color)}
            />
          )}
          {p.madeToMeasure && (
            <button className="outline" onClick={() => onQuote(color)}>
              Cotizar a mi medida
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
