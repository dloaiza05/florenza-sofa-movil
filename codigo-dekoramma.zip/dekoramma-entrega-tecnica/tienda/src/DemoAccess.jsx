"use client";
import React, {useState} from 'react';
import {verifyDemoAccess, demoSessionValid} from './demo-access';
import config from './demo-access-config.json';
import {resetRehearsal} from './api';
const sessionKey='dekoramma-demo-access';
function restore(){try{return demoSessionValid(sessionStorage.getItem(sessionKey),config.digest)}catch{return false}}
export default function DemoAccess({children}) {
  const [allowed,setAllowed]=useState(restore),[email,setEmail]=useState(''),[password,setPassword]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState('');
  if(allowed)return <><div className="demo-session"><span>Revisión administrativa · demostración</span><button type="button" className="outline" onClick={()=>{try{sessionStorage.removeItem(sessionKey)}catch{}setAllowed(false)}}>Cerrar acceso de prueba</button></div>{children}</>;
  return <main className="demo-access"><section className="demo-access-card">
    <a className="demo-access-brand" href="./dekoramma.html"><img src="/assets/logo.png" alt="Dekoramma · Estilo y arte"/></a>
    <p className="eyebrow">ESPACIO DE REVISIÓN</p>
    <h1>Entra a tu panel.</h1>
    <p>Revisa productos, contenido y el visor 3D desde tu computador, tableta o celular.</p>
    <form onSubmit={async e=>{
      e.preventDefault();setError('');setBusy(true);
      try {
        if(!await verifyDemoAccess(email,password,config)){setError('Revisa el correo y la contraseña e inténtalo otra vez.');return;}
        try{sessionStorage.setItem(sessionKey,JSON.stringify({version:config.digest,expires:Date.now()+8*3600000}))}catch{}
        setPassword('');setEmail('');setAllowed(true);
      }catch{setError('No se pudo abrir el acceso. Usa un navegador actualizado y el enlace HTTPS.')}finally{setBusy(false)}
    }}>
      <label>Correo de acceso<input type="email" autoComplete="username" inputMode="email" autoCapitalize="none" spellCheck={false} required maxLength={150} value={email} onChange={e=>setEmail(e.target.value)}/></label>
      <label>Contraseña<input type="password" autoComplete="current-password" required maxLength={200} value={password} onChange={e=>setPassword(e.target.value)}/></label>
      {error&&<p role="alert" className="error">{error}</p>}
      <button type="submit" disabled={busy}>{busy?'Abriendo…':'Ingresar al panel'}</button>
    </form>
    <p className="demo-access-note">Acceso a una demostración con datos de ejemplo. Los cambios y archivos de prueba quedan en este navegador. Puedes verlos en la tienda y restablecer la versión original cuando quieras.</p>
    <a href="./dekoramma.html">Volver a ver la tienda</a>
  </section></main>;
}

export function RehearsalToolbar(){
 const [confirm,setConfirm]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState('');
 return <div className="rehearsal-toolbar"><span>Modo ensayo · cambios solo en este navegador</span><details><summary>Opciones de prueba</summary><button type="button" className="outline" onClick={()=>setConfirm(true)}>Restablecer página original</button><p>Recupera el diseño y contenido base. No modifica el código de GitHub.</p></details>
 {confirm&&<div className="rehearsal-confirm" role="dialog" aria-modal="true" aria-labelledby="reset-title"><section><h2 id="reset-title">¿Restablecer la prueba?</h2><p>Se eliminarán los textos, descuentos y archivos que hayas guardado en este ensayo del navegador. Volverás al contenido original. Esta acción no cambia el código ni la versión pública.</p>{error&&<p role="alert">{error}</p>}<button type="button" disabled={busy} onClick={async()=>{setBusy(true);setError('');try{await resetRehearsal();location.assign('./dekoramma.html')}catch(e){setError(e.message);setBusy(false)}}}>{busy?'Restableciendo…':'Sí, restablecer'}</button><button type="button" className="outline" disabled={busy} onClick={()=>setConfirm(false)}>Conservar mis cambios</button></section></div>}
 </div>;
}
