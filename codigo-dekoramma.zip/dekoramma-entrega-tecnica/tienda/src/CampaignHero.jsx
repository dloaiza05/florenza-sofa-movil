import React, { useEffect, useState, useRef } from "react";
import {
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Pause,
  Play,
} from "lucide-react";
import { mediaUrl } from "./api";
import { activeCampaigns, remainingTime } from "./campaigns";
import BannerMedia from "./BannerMedia";

export default function CampaignHero({
  children,
  campaigns = [],
  demo,
  onCategory,
}) {
  const root = useRef(null);
  const [inView, setInView] = useState(false);
  const [now, setNow] = useState(0),
    [selected, setSelected] = useState("home");
  const [paused, setPaused] = useState(false),
    [hover, setHover] = useState(false);
  const [reduced, setReduced] = useState(true),
    [hidden, setHidden] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => setInView(entry.isIntersecting),
      { threshold: 0 },
    );
    if (root.current) observer.observe(root.current);
    const motion = matchMedia("(prefers-reduced-motion: reduce)");
    const updateMotion = () => setReduced(motion.matches);
    const visibility = () => setHidden(document.hidden);
    updateMotion();
    visibility();
    setNow(Date.now());
    motion.addEventListener("change", updateMotion);
    document.addEventListener("visibilitychange", visibility);
    const tick = setInterval(() => setNow(Date.now()), 1000);
    return () => {
      observer.disconnect();
      clearInterval(tick);
      motion.removeEventListener("change", updateMotion);
      document.removeEventListener("visibilitychange", visibility);
    };
  }, []);
  const active = activeCampaigns(campaigns, demo, now);
  const slides = [{ id: "home", title: "Nuestro taller" }, ...active];
  const index = Math.max(
    0,
    slides.findIndex((c) => c.id === selected),
  );
  const current = index ? slides[index] : null;
  const ids = slides.map((c) => c.id).join("|");
  useEffect(() => {
    if (paused || hover || reduced || hidden || !inView || slides.length < 2)
      return;
    const interval = setInterval(
      () =>
        setSelected((old) => {
          const position = slides.findIndex((c) => c.id === old);
          return slides[(position + 1) % slides.length].id;
        }),
      10000,
    );
    return () => clearInterval(interval);
  }, [ids, paused, hover, reduced, hidden, inView]);
  function choose(i) {
    setPaused(true);
    setSelected(slides[(i + slides.length) % slides.length].id);
  }
  const endLabel =
    current &&
    new Intl.DateTimeFormat("es-CO", {
      timeZone: "America/Bogota",
      dateStyle: "medium",
      timeStyle: "short",
    }).format(new Date(current.endsAt));
  return (
    <div
      ref={root}
      className="campaign-carousel"
      role="region"
      aria-roledescription="carrusel"
      aria-label="Colecciones y campañas"
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      onFocusCapture={() => setPaused(true)}
    >
      {current ? (
        <section className="campaign-slide" aria-label={current.title}>
          <div className="campaign-copy">
            <span className="campaign-demo">
              Simulación de campaña · sin descuento aplicado
            </span>
            <span className="eyebrow">DE NUESTRO TALLER A TU HOGAR</span>
            <h1>{current.title}</h1>
            <p>{current.text}</p>
            <div className="campaign-offer">
              <span>Hasta</span>
              <strong>
                {current.discountPercent}
                <small>%</small>
              </strong>
              <span>
                menos
                <br />
                en {current.category.toLowerCase()}
              </span>
            </div>
            <button onClick={() => onCategory(current.category)}>
              {current.buttonText}
              <ArrowRight size={18} />
            </button>
          </div>
          <div className="campaign-photo">
            <BannerMedia banner={current} onPlay={() => setPaused(true)} />
            {!current.video && <span>Ambiente ilustrativo</span>}
          </div>
          <div className="campaign-deadline">
            <div>
              <strong>Esta campaña de ejemplo termina en</strong>
              <small>{endLabel} · hora de Bogotá</small>
            </div>
            <div className="campaign-clock" aria-label={`Cierre: ${endLabel}`}>
              {remainingTime(current.endsAt, now).map((n, i) => (
                <span key={i}>
                  <b>{String(n).padStart(2, "0")}</b>
                  <small>{["días", "horas", "min", "seg"][i]}</small>
                </span>
              ))}
            </div>
            <details
              onToggle={(e) => {
                if (e.currentTarget.open) setPaused(true);
              }}
            >
              <summary>Ver condiciones</summary>
              <p>{current.terms}</p>
            </details>
          </div>
        </section>
      ) : (
        children
      )}
      {slides.length > 1 && (
        <div className="campaign-controls">
          <div className="campaign-tabs">
            {slides.map((c, i) => (
              <button
                key={c.id}
                aria-pressed={i === index}
                onClick={() => choose(i)}
              >
                <span>{String(i + 1).padStart(2, "0")}</span>
                {i ? c.category : c.title}
              </button>
            ))}
          </div>
          <div className="campaign-arrows">
            <button
              aria-label="Campaña anterior"
              onClick={() => choose(index - 1)}
            >
              <ChevronLeft size={18} />
              <span>Anterior</span>
            </button>
            <span>
              {index + 1} / {slides.length}
            </span>
            <button
              aria-label="Campaña siguiente"
              onClick={() => choose(index + 1)}
            >
              <ChevronRight size={18} />
              <span>Siguiente</span>
            </button>
            <button
              aria-label={
                paused || reduced ? "Reproducir campañas" : "Pausar campañas"
              }
              onClick={() => {
                setReduced(false);
                setPaused(!(paused || reduced));
              }}
            >
              {paused || reduced ? <Play size={16} /> : <Pause size={16} />}
              <span>{paused || reduced ? "Auto" : "Pausar"}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
