import React, { useEffect, useState, useRef } from "react";
import {
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Pause,
  Play,
  X,
} from "lucide-react";
import { mediaUrl } from "./api";
import { activeCampaigns, remainingTime } from "./campaigns";
import BannerMedia from "./BannerMedia";

function CampaignConditions({ campaign, onClose }) {
  const dialog = useRef(null);
  useEffect(() => {
    dialog.current?.showModal();
  }, []);
  const end = new Intl.DateTimeFormat("es-CO", {
    timeZone: "America/Bogota", dateStyle: "long", timeStyle: "short",
  }).format(new Date(campaign.endsAt));
  return <dialog ref={dialog} className="campaign-conditions" aria-labelledby="campaign-conditions-title"
    onClose={onClose} onClick={event => { if (event.target === event.currentTarget) dialog.current.close(); }}>
    <div className="campaign-conditions-heading">
      <h2 id="campaign-conditions-title">Condiciones de la campaña</h2>
      <button autoFocus aria-label="Cerrar condiciones" onClick={() => dialog.current.close()}><X size={20}/></button>
    </div>
    <strong>{campaign.title}</strong>
    <p>Simulación de campaña · sin descuento aplicado.</p>
    <p>Esta campaña de ejemplo termina el {end}, hora de Bogotá.</p>
    <p className="campaign-conditions-text">{campaign.terms}</p>
  </dialog>;
}

export default function CampaignHero({
  children,
  campaigns = [],
  demo,
  onCategory,
}) {
  const root = useRef(null);
  const [inView, setInView] = useState(false);
  const [now, setNow] = useState(0),
    [selected, setSelected] = useState("home");
  const [paused, setPaused] = useState(false);
  const [conditions, setConditions] = useState(null);
  const [reduced, setReduced] = useState(true),
    [hidden, setHidden] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => setInView(entry.isIntersecting),
      { threshold: 0 },
    );
    if (root.current) observer.observe(root.current);
    const motion = matchMedia("(prefers-reduced-motion: reduce)");
    const updateMotion = () => setReduced(motion.matches);
    const visibility = () => setHidden(document.hidden);
    updateMotion();
    visibility();
    setNow(Date.now());
    motion.addEventListener("change", updateMotion);
    document.addEventListener("visibilitychange", visibility);
    const tick = setInterval(() => setNow(Date.now()), 1000);
    return () => {
      observer.disconnect();
      clearInterval(tick);
      motion.removeEventListener("change", updateMotion);
      document.removeEventListener("visibilitychange", visibility);
    };
  }, []);
  const active = activeCampaigns(campaigns, demo, now);
  const slides = [{ id: "home", title: "Nuestro taller" }, ...active];
  const index = Math.max(
    0,
    slides.findIndex((c) => c.id === selected),
  );
  const ids = slides.map((c) => c.id).join("|");
  useEffect(() => {
    if (paused || reduced || hidden || !inView || slides.length < 2)
      return;
    const interval = setInterval(
      () =>
        setSelected((old) => {
          const position = slides.findIndex((c) => c.id === old);
          return slides[(position + 1) % slides.length].id;
        }),
      10000,
    );
    return () => clearInterval(interval);
  }, [ids, selected, paused, reduced, hidden, inView]);
  function choose(i) {
    setSelected(slides[(i + slides.length) % slides.length].id);
  }
  useEffect(() => {
    root.current?.querySelectorAll(".campaign-pane[inert] video").forEach(video => video.pause());
  }, [selected]);
  return (
    <div
      ref={root}
      className="campaign-carousel"
      role="region"
      aria-roledescription="carrusel"
      aria-label="Colecciones y campañas"
      onFocusCapture={(event) => { if(event.target.matches(":focus-visible")) setPaused(true); }}
    >
      <div className="campaign-stage">
      {slides.map((slide, slideIndex) => {
        const current = slideIndex ? slide : null;
        const endLabel = current && new Intl.DateTimeFormat("es-CO", {timeZone:"America/Bogota",dateStyle:"medium",timeStyle:"short"}).format(new Date(current.endsAt));
        return <div key={slide.id} className={"campaign-pane" + (slideIndex === index ? " is-active" : "")} inert={slideIndex !== index} aria-hidden={slideIndex !== index}>
      {current ? (
        <section className="campaign-slide" aria-label={current.title}>
          <div className="campaign-copy">
            <span className="eyebrow">DE NUESTRO TALLER A TU HOGAR</span>
            <h1>{current.title}</h1>
            <p>{current.text}</p>
            <div className="campaign-offer">
              <span>Hasta</span>
              <strong>
                {current.discountPercent}
                <small>%</small>
              </strong>
              <span>
                menos
                <br />
                en {current.category.toLowerCase()}
              </span>
            </div>
            <button onClick={() => onCategory(current.category)}>
              {current.buttonText}
              <ArrowRight size={18} />
            </button>
          </div>
          <div className="campaign-photo">
            <BannerMedia banner={current} onPlay={() => setPaused(true)} />
            <span className="campaign-demo">Simulación de campaña · sin descuento aplicado</span>
            {!current.video && <span className="campaign-illustration">Ambiente ilustrativo</span>}
          <div className="campaign-deadline">
            <span className="campaign-deadline-label">Termina en</span>
            <div className="campaign-clock" aria-label={`Cierre: ${endLabel}`}>
              {remainingTime(current.endsAt, now).map((n, i) => (
                <span key={i}>
                  <b>{String(n).padStart(2, "0")}</b>
                  <small>{["días", "horas", "min", "seg"][i]}</small>
                </span>
              ))}
            </div>
            <button className="campaign-terms-button" onClick={() => { setPaused(true); setConditions(current); }}>Ver condiciones</button>
          </div>
          </div>
        </section>
      ) : (
        children
      )}
        </div>;
      })}
      </div>
      {slides.length > 1 && (
        <div className="campaign-navigation">
          <button className="campaign-side campaign-side--previous" aria-label="Campaña anterior" onClick={() => choose(index - 1)}><ChevronLeft size={23}/></button>
          <button className="campaign-side campaign-side--next" aria-label="Campaña siguiente" onClick={() => choose(index + 1)}><ChevronRight size={23}/></button>
          <div className="campaign-dot-bar">
          <div className="campaign-dots" role="group" aria-label="Elegir banner">
            {slides.map((c, i) => (
              <button
                key={c.id}
                aria-label={`Ver banner ${i + 1}: ${i ? c.category : c.title}`}
                title={i ? c.category : c.title}
                aria-pressed={i === index}
                onClick={() => choose(i)}
              >
                <span aria-hidden="true" />
              </button>
            ))}
          </div>
            <button
              className="campaign-playback"
              aria-label={
                paused || reduced ? "Reproducir campañas" : "Pausar campañas"
              }
              onClick={() => {
                setReduced(false);
                setPaused(!(paused || reduced));
              }}
            >
              {paused || reduced ? <Play size={16} /> : <Pause size={16} />}
            </button>
          </div>
        </div>
      )}
      {conditions && <CampaignConditions campaign={conditions} onClose={() => setConditions(null)}/>}
    </div>
  );
}
