"use client";
import { useState } from "react";
import { MapPin, Navigation } from "lucide-react";
import { deliveryDraft } from "./locations";
export default function DeliveryLocation({ settings, region }) {
  const [address, setAddress] = useState(""),
    [coordinates, setCoordinates] = useState(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const draft =
    coordinates || address.trim().length >= 8
      ? deliveryDraft(settings, { address: [address, region?.city, region?.department].filter(Boolean).join(", "), coordinates })
      : null;
  function locate() {
    setError("");
    if (!navigator.geolocation) {
      setError(
        "Este navegador no ofrece ubicación. Escribe la dirección de entrega.",
      );
      return;
    }
    setBusy(true);
    navigator.geolocation.getCurrentPosition(
      ({ coords }) => {
        setCoordinates({
          latitude: coords.latitude,
          longitude: coords.longitude,
          accuracy: coords.accuracy,
        });
        setBusy(false);
      },
      () => {
        setError(
          "No se pudo obtener la ubicación. Puedes escribir la dirección y ciudad.",
        );
        setBusy(false);
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 },
    );
  }
  return (
    <div className="form-grid">
      <p>
        Prepara un mensaje para el WhatsApp de {settings.storeName}:{" "}
        <strong>+{settings.phone}</strong>.
      </p>
      <label>
        Dirección y ciudad de entrega
        <input
          value={address}
          maxLength={250}
          placeholder="Ej. Calle 10 #20-30, Bogotá"
          onChange={(e) => {
            setAddress(e.target.value);
            setCoordinates(null);
          }}
        />
      </label>
      <p className="caption">
        También puedes usar tu ubicación actual. El navegador pedirá permiso;
        revísala antes de compartirla con la tienda.
      </p>
      <button className="outline" disabled={busy} onClick={locate}>
        <Navigation size={17} />
        {busy ? "Buscando ubicación…" : "Usar mi ubicación actual"}
      </button>
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
      {coordinates && (
        <div className="location-preview">
          <MapPin size={20} />
          <p>
            Ubicación obtenida. Precisión aproximada:{" "}
            {Math.round(coordinates.accuracy)} m.{" "}
            <button
              className="text-button"
              onClick={() => setCoordinates(null)}
            >
              Quitar ubicación
            </button>
          </p>
        </div>
      )}
      {draft && (
        <div className="actions">
          <a
            className="button outline"
            href={draft.map}
            target="_blank"
            rel="noreferrer"
          >
            Revisar en Google Maps
          </a>
          <a
            className="button"
            href={draft.url}
            target="_blank"
            rel="noreferrer"
          >
            Abrir mensaje en WhatsApp
          </a>
        </div>
      )}
      <p className="caption">
        Se comparte un enlace al mapa. WhatsApp abre el mensaje preparado y tú
        decides enviarlo. Esta pantalla no guarda tus coordenadas ni envía
        mensajes automáticamente.
      </p>
    </div>
  );
}
