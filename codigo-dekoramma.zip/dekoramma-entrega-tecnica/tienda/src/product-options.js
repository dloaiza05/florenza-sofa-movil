export const partLabels = {
  arms: "Brazos",
  back: "Espaldar",
  seat: "Asiento",
  legs: "Patas",
};
export const demoFinishes = [
  { id: "petroleo", label: "Petróleo", hex: "#2e7680" },
  { id: "arena", label: "Arena", hex: "#d9cdb4" },
  { id: "terracota", label: "Terracota", hex: "#b06d59" },
  { id: "gris", label: "Gris", hex: "#888b86" },
];
export function modelOptions(p) {
  return {
    parts:
      p.modelDemo && !Object.values(p.modelParts || {}).some((x) => x.length)
        ? {
            arms: ["brazos"],
            back: ["espaldar"],
            seat: ["asiento"],
            legs: ["patas"],
          }
        : p.modelParts || {},
    finishes: p.finishes?.length ? p.finishes : p.modelDemo ? demoFinishes : [],
    legs: p.legOptions || [],
  };
}
