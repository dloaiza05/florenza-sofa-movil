"use client";
import React, { useState, useEffect } from "react";
import { api, setCsrf, money, categories, mediaUrl } from "./api";
import ProductMediaEditor from "./ProductMediaEditor";
import ModelConfigEditor from "./ModelConfigEditor";
import DocumentsAdmin from "./DocumentsAdmin";
import MarketingAdmin from "./MarketingAdmin";
import CampaignEditor from "./CampaignEditor";
import FinanceBannerEditor from "./FinanceBannerEditor";
import OfficialPaymentDirectory from "./OfficialPaymentDirectory";
import WelcomeBannerEditor from "./WelcomeBannerEditor";
const labels = {
  financeBanners: "Banners de financiación: títulos y botones",
  button: "Texto del botón",
  marketingEnabled: "Mostrar captura de novedades y ofertas",
  legalName: "Razón social o nombre del comerciante (pendiente si está vacío)",
  taxId: "NIT (pendiente si está vacío)",
  registration: "Matrícula mercantil",
  legalDraft: "Textos legales en borrador",
  legalVersion: "Versión de los textos legales",
  withdrawal: "Retracto y reversión",
  documentation: "Solicitud de documentos comerciales",
  hero: "Portada",
  eyebrow: "Texto superior",
  title: "Título",
  text: "Texto",
  primary: "Botón principal",
  secondary: "Botón secundario",
  benefits: "Franja en movimiento",
  reels: "Reels y videos",
  gallery: "Galería de ambientes",
  faq: "Preguntas frecuentes",
  sections: "Secciones: orden y visibilidad",
  workshop: "Taller",
  delivery: "Envíos",
  navigation: "Navegación",
  drawer: "Menú de catálogo lateral",
  image: "Imagen",
  video: "Video MP4 · máximo 3 minutos",
  description: "Descripción",
  subtitle: "Subtítulo",
  visible: "Visible para el cliente",
  steps: "Pasos del taller",
  cities: "Zonas de entrega",
  icon: "Icono",
  target: "Sección de destino",
  storeName: "Nombre de tienda",
  phone: "WhatsApp (país + número, sin +)",
  email: "Correo de la tienda",
  mapsPlaceId: "Google Maps Place ID (solo si la ubicación fue confirmada)",
  address: "Dirección",
  hours: "Horarios",
  announcement: "Franja superior",
  heroTitle: "Título de respaldo",
  heroImage: "Foto principal",
  facebook: "Facebook",
  instagram: "Instagram",
  paymentMethods: "Formas de pago",
  paymentNote: "Condiciones de financiación",
  privacy: "Política de privacidad",
  terms: "Términos y condiciones",
  warranty: "Garantía",
  demo: "Mostrar aviso de vista de desarrollo",
};
function Media({ value, onChange, label, accept, onBusy = () => {} }) {
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  return (
    <div className="media-field">
      <strong>{label}</strong>
      {value && /\.(png|jpg|jpeg|webp)$/.test(value) && (
        <img src={mediaUrl(value)} alt="Vista previa" />
      )}
      {value && /\.mp4$/.test(value) && (
        <video
          controls
          playsInline
          preload="none"
          src={mediaUrl(value)}
          aria-label={`Vista previa: ${label}`}
        />
      )}
      {value && (
        <a href={value} target="_blank" rel="noreferrer">
          Abrir archivo actual
        </a>
      )}
      <input
        aria-label={label}
        type="file"
        accept={accept || ".png,.jpg,.jpeg,.webp"}
        disabled={busy}
        onChange={async (e) => {
          const file = e.target.files?.[0];
          if (!file) return;
          setError("");
          if (file.size > 100 * 1024 * 1024) {
            setError("Máximo 100 MB");
            return;
          }
          setBusy(true);
          onBusy(true);
          try {
            const body = new FormData();
            body.append("file", file);
            const data = await api("/admin/upload", { method: "POST", body });
            onChange(data.url);
          } catch (err) {
            setError(err.message);
          } finally {
            setBusy(false);
            onBusy(false);
            e.target.value = "";
          }
        }}
      />
      {value && (
        <button type="button" className="outline" onClick={() => onChange("")}>
          Quitar archivo
        </button>
      )}
      {busy && <span className="uploading">Subiendo y validando…</span>}
      {error && <span className="error">{error}</span>}
    </div>
  );
}
function Fields({ value, onChange, path = "" }) {
  return (
    <div className="nested-fields">
      {Object.entries(value).map(([key, v]) => {
        if (key === "id") return null;
        const label = labels[key] || key;
        const change = (next) => onChange({ ...value, [key]: next });
        if (["image", "heroImage", "video"].includes(key))
          return (
            <Media
              key={key}
              value={v}
              onChange={change}
              label={label}
              accept={key === "video" ? ".mp4" : undefined}
            />
          );
        if (typeof v === "boolean")
          return (
            <label key={key} className="check">
              <input
                type="checkbox"
                checked={v}
                onChange={(e) => change(e.target.checked)}
              />
              {label}
            </label>
          );
        if (Array.isArray(v)) {
          return (
            <div key={key}>
              <h3>{label}</h3>
              {v.map((item, i) => (
                <div key={item?.id || i} className="array-item">
                  {typeof item === "string" ? (
                    <input
                      value={item}
                      onChange={(e) =>
                        change(v.map((x, j) => (j === i ? e.target.value : x)))
                      }
                    />
                  ) : (
                    <Fields
                      value={item}
                      path={path + "." + key}
                      onChange={(next) =>
                        change(v.map((x, j) => (j === i ? next : x)))
                      }
                    />
                  )}
                  <div className="array-actions">
                    <button
                      type="button"
                      className="outline"
                      disabled={i === 0}
                      onClick={() => {
                        const a = [...v];
                        [a[i - 1], a[i]] = [a[i], a[i - 1]];
                        change(a);
                      }}
                    >
                      Subir ↑
                    </button>
                    <button
                      type="button"
                      className="outline"
                      disabled={i === v.length - 1}
                      onClick={() => {
                        const a = [...v];
                        [a[i + 1], a[i]] = [a[i], a[i + 1]];
                        change(a);
                      }}
                    >
                      Bajar ↓
                    </button>
                    {key !== "sections" && (
                      <button
                        type="button"
                        className="outline"
                        onClick={() => change(v.filter((_, j) => i !== j))}
                      >
                        Eliminar
                      </button>
                    )}
                  </div>
                </div>
              ))}
              {key !== "sections" && (
                <button
                  type="button"
                  className="outline"
                  onClick={() => {
                    const templates = {
                      reels: {
                        id: crypto.randomUUID(),
                        title: "Nuevo video",
                        image: "",
                        video: "",
                        description: "Describe este video",
                      },
                      gallery: {
                        id: crypto.randomUUID(),
                        title: "Nuevo ambiente",
                        image: "",
                      },
                      faq: {
                        id: crypto.randomUUID(),
                        title: "Nueva pregunta",
                        text: "Respuesta",
                      },
                      benefits: {
                        id: crypto.randomUUID(),
                        title: "Beneficio",
                        text: "Descripción",
                        icon: "cube",
                        target: "espacio",
                      },
                      steps: { title: "Nuevo paso", text: "Descripción" },
                    };
                    change([
                      ...v,
                      templates[key] ||
                        (typeof v[0] === "object"
                          ? { ...v[0], id: crypto.randomUUID() }
                          : "Nuevo elemento"),
                    ]);
                  }}
                >
                  Añadir {label.toLowerCase()}
                </button>
              )}
            </div>
          );
        }
        if (v && typeof v === "object")
          return (
            <details key={key} className="editor-section">
              <summary>{label}</summary>
              <Fields value={v} path={path + "." + key} onChange={change} />
            </details>
          );
        if (["icon", "target"].includes(key))
          return (
            <label key={key}>
              {label}
              <select value={v} onChange={(e) => change(e.target.value)}>
                {(key === "icon"
                  ? ["factory", "ruler", "truck", "card", "cube"]
                  : [
                      "taller",
                      "configurador",
                      "envios",
                      "financiacion",
                      "espacio",
                    ]
                ).map((x) => (
                  <option key={x}>{x}</option>
                ))}
              </select>
            </label>
          );
        return (
          <label key={key}>
            {label}
            {typeof v === "string" &&
            (v.length > 120 ||
              [
                "title",
                "text",
                "description",
                "subtitle",
                "privacy",
                "terms",
                "warranty",
                "paymentNote",
              ].includes(key)) ? (
              <textarea
                aria-label={label}
                value={v}
                onChange={(e) => change(e.target.value)}
              />
            ) : (
              <input
                aria-label={label}
                value={v ?? ""}
                onChange={(e) => change(e.target.value)}
              />
            )}
          </label>
        );
      })}
    </div>
  );
}
export default function Admin({ preview = false }) {
  const [googleEnabled, setGoogleEnabled] = useState(false);
  const [user, setUser] = useState(null),
    [loading, setLoading] = useState(true),
    [data, setData] = useState(null),
    [content, setContent] = useState(null),
    [tab, setTab] = useState("Resumen"),
    [error, setError] = useState(""),
    [status, setStatus] = useState(""),
    [busy, setBusy] = useState(false),
    [edit, setEdit] = useState(null),
    [mediaBusy, setMediaBusy] = useState(false),
    [productQuery, setProductQuery] = useState(""),
    [productCategory, setProductCategory] = useState("Todo"),
    [adminPage, setAdminPage] = useState(1);
  useEffect(() => {
    setAdminPage(1);
  }, [productQuery, productCategory]);
  async function refresh() {
    const [d, c] = await Promise.all([
      api("/admin/data"),
      api("/admin/content"),
    ]);
    setData(d);
    setContent(c);
  }
  useEffect(() => {
    if (preview) {
      setUser({ preview: true });
      refresh()
        .catch((e) => setError(e.message))
        .finally(() => setLoading(false));
      return;
    }
    api("/auth/options")
      .then((x) => setGoogleEnabled(x.google === true))
      .catch(() => {});
    if (
      new URLSearchParams(window.location.search).get("acceso") ===
      "no-autorizado"
    )
      setError(
        "No se pudo autorizar esa cuenta. Usa un acceso aprobado o contacta al responsable de la tienda.",
      );
    api("/admin/me")
      .then(async (u) => {
        setUser(u);
        setCsrf(u.csrf);
        await refresh();
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);
  async function action(fn, message) {
    setBusy(true);
    setError("");
    setStatus("");
    try {
      await fn();
      setStatus(
        preview
          ? "Cambio probado en esta demostración. No se ha publicado nada; al recargar se restablece."
          : message,
      );
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }
  if (loading) return <div className="loading">Abriendo administración…</div>;
  if (!user)
    return (
      <main className="login">
        <a href="/">
          <img
            style={{ width: 110, margin: "0 auto" }}
            src="/assets/logo.png"
            alt="Dekoramma"
          />
        </a>
        <h1>Administración</h1>
        <p>Gestiona tu tienda y el contenido que ven tus clientes.</p>
        <p>
          <a href="/admin/vista-previa">
            Conocer el panel sin iniciar sesión →
          </a>
        </p>
        {googleEnabled && (
          <div className="admin-google-access">
            <a className="outline" href="/api/auth/google/start">
              Continuar con Google
            </a>
            <p>Solo cuentas autorizadas. No hay registro público.</p>
          </div>
        )}
        <form
          className="form-grid"
          onSubmit={(e) => {
            e.preventDefault();
            const f = new FormData(e.currentTarget);
            action(async () => {
              const u = await api("/login", {
                method: "POST",
                body: { email: f.get("email"), password: f.get("password") },
              });
              setCsrf(u.csrf);
              setUser(u);
              await refresh();
            }, "Sesión iniciada");
          }}
        >
          <label>
            Correo
            <input name="email" type="email" autoComplete="username" required />
          </label>
          <label>
            Contraseña
            <input
              name="password"
              type="password"
              autoComplete="current-password"
              required
            />
          </label>
          {error && <p className="error">{error}</p>}
          <button disabled={busy}>Entrar</button>
          <a href="/">Volver a la tienda</a>
        </form>
      </main>
    );
  return (
    <div className="admin-shell">
      <aside className="admin-side">
        <a className="logo" href="/">
          <img
            style={{ height: 80, objectFit: "contain", width: "100%" }}
            src="/assets/logo.png"
            alt="Dekoramma"
          />
        </a>
        {[
          "Resumen",
          "Productos",
          "Contenido",
          "Tienda",
          "Solicitudes",
          "Asesorías",
          "Documentos",
          "Permisos de contacto",
        ].map((x) => (
          <button
            className={tab === x ? "active" : ""}
            key={x}
            onClick={() => {
              setTab(x);
              setEdit(null);
              setStatus("");
              setError("");
            }}
          >
            {x}
          </button>
        ))}
        <a href="/" target="_blank" rel="noreferrer">
          Ver tienda ↗
        </a>
        {preview ? (
          <a href="/admin">Entrar para publicar →</a>
        ) : (
          <button
            onClick={() =>
              action(async () => {
                await api("/admin/logout", { method: "POST" });
                setUser(null);
                setCsrf("");
              }, "")
            }
          >
            Cerrar sesión
          </button>
        )}
      </aside>
      <main className="admin-main">
        {preview && (
          <div className="admin-preview-notice" role="note">
            <div>
              <strong>Así se administra tu tienda</strong>
              <p>
                Recorre las secciones y prueba los campos. Esta demostración usa
                el catálogo público; no muestra clientes, documentos privados ni
                cuentas. Para subir archivos o publicar, inicia sesión.
              </p>
            </div>
            <a href="/admin">Entrar al administrador →</a>
          </div>
        )}
        <div className="admin-top">
          <div>
            <span className="eyebrow" style={{ color: "#ad4527" }}>
              DEKORAMMA · ADMINISTRACIÓN
            </span>
            <h1>{tab}</h1>
          </div>
          <button
            className="outline"
            onClick={() => action(refresh, "Datos actualizados")}
          >
            Actualizar
          </button>
        </div>
        {error && (
          <p className="error" role="alert">
            {error}
          </p>
        )}
        {status && (
          <p className="admin-status" role="status">
            {status}
          </p>
        )}
        {!data ? (
          <p>Cargando datos…</p>
        ) : (
          <>
            {tab === "Resumen" && (
              <>
                <div className="admin-grid">
                  {[
                    [
                      "Productos activos",
                      data.products.filter((p) => p.active).length,
                    ],
                    ["Solicitudes de compra", data.orders.length],
                    ["Asesorías", data.leads.length],
                  ].map(([label, n]) => (
                    <div className="admin-card stat" key={label}>
                      {label}
                      <strong>{n}</strong>
                    </div>
                  ))}
                </div>
                <div className="admin-card">
                  <h2>Tu tienda, sección por sección</h2>
                  <p>
                    En Contenido puedes editar portada, franja móvil, reels,
                    galería, preguntas, taller, orden y visibilidad. En
                    Productos puedes cargar fotografías, GLB, USDZ y videos.
                  </p>
                  <p>
                    Videos: MP4, máximo 3 minutos y 100 MB. Los modelos de
                    ejemplo deben reemplazarse por los modelos reales. Las
                    solicitudes no acreditan un pago.
                  </p>
                  <button onClick={() => setTab("Contenido")}>
                    Editar contenido
                  </button>
                </div>
                <div className="admin-tour-grid">
                  {[
                    [
                      "01",
                      "Portada, banners y videos",
                      "Contenido",
                      "Cambia textos e imágenes, programa campañas y decide el orden de las secciones.",
                    ],
                    [
                      "02",
                      "Productos, colores y 3D",
                      "Productos",
                      "Edita precios y medidas. Organiza fotos por color, videos y modelos del mueble.",
                    ],
                    [
                      "03",
                      "Información de la tienda",
                      "Tienda",
                      "Actualiza WhatsApp, ubicación, horarios, datos comerciales y condiciones.",
                    ],
                    [
                      "04",
                      "PDFs y aprobaciones",
                      "Documentos",
                      "Consulta el formulario de carga, las versiones y los estados de aprobación.",
                    ],
                  ].map(([n, title, target, description]) => (
                    <button
                      className="admin-tour-card"
                      key={n}
                      onClick={() => setTab(target)}
                    >
                      <span>{n}</span>
                      <h2>{title}</h2>
                      <p>{description}</p>
                      <strong>Abrir sección →</strong>
                    </button>
                  ))}
                </div>
                {preview && (
                  <p className="admin-hint">
                    Solicitudes, asesorías y documentos aparecen vacíos para
                    proteger la información real.
                  </p>
                )}
              </>
            )}
            {tab === "Productos" &&
              (edit ? (
                <form
                  className="admin-card form-grid"
                  onSubmit={(e) => {
                    e.preventDefault();
                    action(async () => {
                      await api("/admin/products/" + edit.id, {
                        method: "PUT",
                        body: edit,
                      });
                      await refresh();
                      setEdit(null);
                    }, "Producto guardado");
                  }}
                >
                  <h2>{edit.name || "Nuevo producto"}</h2>
                  <ProductMediaEditor
                    product={edit}
                    onChange={(fields) =>
                      setEdit((previous) => ({ ...previous, ...fields }))
                    }
                    onBusy={setMediaBusy}
                  />
                  <ModelConfigEditor
                    product={edit}
                    onChange={(fields) =>
                      setEdit((previous) => ({ ...previous, ...fields }))
                    }
                    Media={Media}
                    onBusy={setMediaBusy}
                  />
                  <div className="admin-edit-grid">
                    {[
                      ["id", "Identificador"],
                      ["name", "Nombre"],
                      ["description", "Descripción"],
                    ].map(([key, label]) => (
                      <label key={key}>
                        {label}
                        <input
                          required
                          value={edit[key]}
                          onChange={(e) =>
                            setEdit({ ...edit, [key]: e.target.value })
                          }
                        />
                      </label>
                    ))}
                    <label>
                      Categoría
                      <select
                        value={edit.category}
                        onChange={(e) =>
                          setEdit({ ...edit, category: e.target.value })
                        }
                      >
                        {categories.map((x) => (
                          <option key={x}>{x}</option>
                        ))}
                      </select>
                    </label>
                    {[
                      ["price", "Precio COP"],
                      ["width", "Ancho cm"],
                      ["depth", "Fondo cm"],
                      ["height", "Alto cm"],
                    ].map(([key, label]) => (
                      <label key={key}>
                        {label}
                        <input
                          required
                          type="number"
                          min={key === "price" ? 1000 : 10}
                          value={edit[key]}
                          onChange={(e) =>
                            setEdit({ ...edit, [key]: +e.target.value })
                          }
                        />
                      </label>
                    ))}
                    <label>
                      Colores (separados por coma)
                      <input
                        value={edit.colors.join(", ")}
                        onChange={(e) =>
                          setEdit({
                            ...edit,
                            colors: e.target.value
                              .split(",")
                              .map((x) => x.trim()),
                          })
                        }
                      />
                    </label>
                    <label className="check">
                      <input
                        type="checkbox"
                        checked={edit.active}
                        onChange={(e) =>
                          setEdit({ ...edit, active: e.target.checked })
                        }
                      />
                      Producto visible
                    </label>
                    <label className="check">
                      <input
                        type="checkbox"
                        checked={edit.modelDemo}
                        onChange={(e) =>
                          setEdit({ ...edit, modelDemo: e.target.checked })
                        }
                      />
                      El modelo 3D es una demostración
                    </label>
                    <Media
                      value={edit.modelUrl}
                      label="Modelo 3D · GLB"
                      accept=".glb"
                      onChange={(url) =>
                        setEdit({ ...edit, modelUrl: url, modelDemo: false })
                      }
                    />
                    <Media
                      value={edit.usdzUrl}
                      label="Modelo iPhone · USDZ (opcional)"
                      accept=".usdz"
                      onChange={(url) => setEdit({ ...edit, usdzUrl: url })}
                    />
                    <label className="check">
                      <input
                        type="checkbox"
                        checked={edit.madeToMeasure || false}
                        onChange={(e) =>
                          setEdit({ ...edit, madeToMeasure: e.target.checked })
                        }
                      />
                      Fabricación a medida disponible
                    </label>
                    {[
                      ["materials", "Materiales y acabados"],
                      ["care", "Cuidados"],
                      ["leadTime", "Disponibilidad y plazo estimado"],
                    ].map(([key, label]) => (
                      <label key={key}>
                        {label}
                        <textarea
                          value={edit[key] || ""}
                          onChange={(e) =>
                            setEdit({ ...edit, [key]: e.target.value })
                          }
                        />
                      </label>
                    ))}
                  </div>
                  <div className="actions">
                    <button disabled={busy || mediaBusy}>
                      Guardar producto
                    </button>
                    <button
                      type="button"
                      className="outline"
                      onClick={() => setEdit(null)}
                    >
                      Cancelar
                    </button>
                  </div>
                </form>
              ) : (
                <>
                  <button
                    onClick={() =>
                      setEdit({
                        id: "producto-" + Date.now(),
                        name: "",
                        category: categories[0],
                        price: 1000000,
                        description: "",
                        image: "",
                        width: 270,
                        depth: 170,
                        height: 90,
                        colors: ["Arena"],
                        active: false,
                        modelUrl: "",
                        usdzUrl: "",
                        modelDemo: false,
                        videoUrl: "",
                      })
                    }
                  >
                    Añadir producto
                  </button>
                  <div className="filter">
                    <label>
                      Buscar referencia
                      <input
                        value={productQuery}
                        onChange={(e) => setProductQuery(e.target.value)}
                        placeholder="Nombre o identificador"
                      />
                    </label>
                    <label>
                      Categoría
                      <select
                        value={productCategory}
                        onChange={(e) => setProductCategory(e.target.value)}
                      >
                        {["Todo", ...categories].map((x) => (
                          <option key={x}>{x}</option>
                        ))}
                      </select>
                    </label>
                  </div>
                  <div className="admin-card table-scroll">
                    <table className="admin-table">
                      <thead>
                        <tr>
                          <th>Foto</th>
                          <th>Producto</th>
                          <th>Precio</th>
                          <th>Estado</th>
                          <th>Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
                        {data.products
                          .filter(
                            (p) =>
                              (productCategory === "Todo" ||
                                p.category === productCategory) &&
                              (p.name + " " + p.id)
                                .toLowerCase()
                                .includes(productQuery.toLowerCase()),
                          )
                          .slice((adminPage - 1) * 24, adminPage * 24)
                          .map((p) => (
                            <tr key={p.id}>
                              <td>
                                <img
                                  src={mediaUrl(p.image)}
                                  alt=""
                                  loading="lazy"
                                />
                              </td>
                              <td>
                                {p.name}
                                <small style={{ display: "block" }}>
                                  {p.modelUrl
                                    ? "Tiene modelo 3D"
                                    : "Sin modelo 3D"}
                                </small>
                              </td>
                              <td>{money(p.price)}</td>
                              <td>{p.active ? "Visible" : "Oculto"}</td>
                              <td>
                                <button
                                  className="outline"
                                  onClick={() => setEdit(structuredClone(p))}
                                >
                                  Editar
                                </button>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                  <nav
                    className="pagination"
                    aria-label="Páginas de administración"
                  >
                    <button
                      className="outline"
                      disabled={adminPage === 1}
                      onClick={() => setAdminPage(adminPage - 1)}
                    >
                      Anterior
                    </button>
                    <span>
                      Página {adminPage} ·{" "}
                      {
                        data.products.filter(
                          (p) =>
                            (productCategory === "Todo" ||
                              p.category === productCategory) &&
                            (p.name + " " + p.id)
                              .toLowerCase()
                              .includes(productQuery.toLowerCase()),
                        ).length
                      }{" "}
                      referencias
                    </span>
                    <button
                      className="outline"
                      disabled={
                        adminPage * 24 >=
                        data.products.filter(
                          (p) =>
                            (productCategory === "Todo" ||
                              p.category === productCategory) &&
                            (p.name + " " + p.id)
                              .toLowerCase()
                              .includes(productQuery.toLowerCase()),
                        ).length
                      }
                      onClick={() => setAdminPage(adminPage + 1)}
                    >
                      Siguiente
                    </button>
                  </nav>
                </>
              ))}
            {tab === "Contenido" && content && (
              <form
                className="admin-card form-grid"
                onSubmit={(e) => {
                  e.preventDefault();
                  action(
                    () =>
                      api("/admin/content", { method: "PUT", body: content }),
                    "Contenido publicado en la tienda. Actualiza la vista de cliente para verlo.",
                  );
                }}
              >
                <p>
                  Los cambios se aplican al pulsar Guardar. Las secciones se
                  ordenan con Subir / Bajar. Conserva al menos una imagen para
                  cada reel.
                </p>
                {[
                  "hero",
                  "benefits",
                  "sections",
                  "reels",
                  "workshop",
                  "gallery",
                  "delivery",
                  "faq",
                  "navigation",
                ]
                  .map((key) => [key, content[key]])
                  .map(([key, value]) => (
                    <details className="editor-section" key={key}>
                      <summary>{labels[key] || key}</summary>
                      <Fields
                        value={Array.isArray(value) ? { [key]: value } : value}
                        onChange={(v) =>
                          setContent({
                            ...content,
                            [key]: Array.isArray(value) ? v[key] : v,
                          })
                        }
                      />
                    </details>
                  ))}
                <FinanceBannerEditor
                  value={content.financeBanners}
                  onChange={(financeBanners) =>
                    setContent({ ...content, financeBanners })
                  }
                  Media={Media}
                />
                <CampaignEditor
                  campaigns={content.campaigns}
                  onChange={(campaigns) =>
                    setContent({ ...content, campaigns })
                  }
                  Media={Media}
                />
                <WelcomeBannerEditor
                  value={content.welcomeBanner}
                  onChange={(welcomeBanner) =>
                    setContent({ ...content, welcomeBanner })
                  }
                  Media={Media}
                />
                <OfficialPaymentDirectory />
                <button disabled={busy}>Guardar contenido</button>
              </form>
            )}
            {tab === "Tienda" && (
              <form
                className="admin-card form-grid"
                onSubmit={(e) => {
                  e.preventDefault();
                  action(
                    () =>
                      api("/admin/settings", {
                        method: "PUT",
                        body: data.settings,
                      }),
                    "Información de tienda guardada",
                  );
                }}
              >
                <Fields
                  value={data.settings}
                  onChange={(settings) => setData({ ...data, settings })}
                />
                <button disabled={busy}>Guardar tienda</button>
              </form>
            )}
            {tab === "Solicitudes" && (
              <>
                {!data.orders.length && (
                  <p>Aún no hay solicitudes de compra.</p>
                )}
                {data.orders.map((o) => (
                  <article className="admin-card" key={o.id}>
                    <h3>
                      {o.data.customer.name} · {money(o.data.total)}
                    </h3>
                    <p>
                      <code>{o.id}</code> ·{" "}
                      {new Date(o.created_at).toLocaleString("es-CO")}
                    </p>
                    <p>
                      {o.data.customer.email} · {o.data.customer.phone}
                      <br />
                      {o.data.customer.city} · {o.data.customer.address}
                    </p>
                    <div className="order-lines">
                      {o.data.items.map((x, i) => (
                        <p key={i}>
                          {x.quantity} × {x.name} · {x.color} · {money(x.price)}
                        </p>
                      ))}
                    </div>
                    <p>
                      Preferencia: {o.data.method} · Pago pendiente de
                      confirmación · Envío por cotizar
                    </p>
                    <p>{o.data.customer.notes}</p>
                    <label>
                      Estado de la solicitud
                      <select
                        value={o.status}
                        onChange={(e) =>
                          action(async () => {
                            await api("/admin/orders/" + o.id, {
                              method: "PATCH",
                              body: { status: e.target.value },
                            });
                            await refresh();
                          }, "Estado actualizado")
                        }
                      >
                        {[
                          "recibido",
                          "contactado",
                          "confirmado",
                          "en_fabricacion",
                          "enviado",
                          "entregado",
                          "cancelado",
                        ].map((x) => (
                          <option key={x}>{x}</option>
                        ))}
                      </select>
                    </label>
                  </article>
                ))}
              </>
            )}
            {tab === "Documentos" && <DocumentsAdmin />}
            {tab === "Permisos de contacto" && <MarketingAdmin />}
            {tab === "Asesorías" && (
              <>
                {!data.leads.length && <p>Aún no hay asesorías registradas.</p>}
                {data.leads.map((l) => (
                  <article className="admin-card admin-lead" key={l.id}>
                    <h3>
                      {l.data.name} · {l.data.type}
                    </h3>
                    <p>
                      {l.data.phone} · {l.data.city}
                    </p>
                    <p>{l.data.message}</p>
                    <p>
                      Canal autorizado:{" "}
                      {
                        {
                          email: "Correo electrónico",
                          phone: "Llamada",
                          whatsapp: "WhatsApp",
                        }[l.data.contactChannel || "whatsapp"]
                      }{" "}
                      {l.data.email || ""}
                    </p>
                    {l.data.preferredDate && (
                      <p>
                        Cita solicitada (por confirmar): {l.data.preferredDate}{" "}
                        ·{" "}
                        {{ morning: "Mañana", afternoon: "Tarde" }[
                          l.data.preferredTime
                        ] || "Sin preferencia de franja"}
                      </p>
                    )}
                    {l.data.contactConsent && (
                      <details>
                        <summary>Autorización para esta asesoría</summary>
                        <p>{l.data.contactConsent.text}</p>
                        <p>
                          {l.data.contactConsent.acceptedAt} ·{" "}
                          {l.data.contactConsent.version}
                        </p>
                        <p>Publicidad: no autorizada por esta solicitud.</p>
                      </details>
                    )}
                    {l.data.configuration && (
                      <p>
                        Configuración:{" "}
                        {l.data.configuration.kind === "product" ? (
                          <>
                            {l.data.configuration.productName} ·{" "}
                            {l.data.configuration.color} ·{" "}
                            {l.data.configuration.summary} ·{" "}
                            {l.data.configuration.legLabel}
                          </>
                        ) : (
                          <>
                            {l.data.configuration.shape} ·{" "}
                            {l.data.configuration.fabric} ·{" "}
                            {l.data.configuration.extras.join(", ")}
                          </>
                        )}
                      </p>
                    )}
                    <small>
                      {new Date(l.created_at).toLocaleString("es-CO")}
                    </small>
                    {(!l.data.contactChannel ||
                      l.data.contactChannel === "whatsapp") && (
                      <p>
                        <a
                          className="button outline"
                          target="_blank"
                          rel="noreferrer"
                          href={
                            "https://wa.me/" + l.data.phone.replace(/\D/g, "")
                          }
                        >
                          Abrir WhatsApp
                        </a>
                      </p>
                    )}
                    {l.data.contactChannel === "email" && (
                      <a
                        className="button outline"
                        href={"mailto:" + l.data.email}
                      >
                        Preparar respuesta por correo
                      </a>
                    )}
                    {l.data.contactChannel === "phone" && (
                      <a
                        className="button outline"
                        href={"tel:" + l.data.phone.replace(/[^+\d]/g, "")}
                      >
                        Llamar por el canal autorizado
                      </a>
                    )}
                  </article>
                ))}
              </>
            )}
          </>
        )}
      </main>
    </div>
  );
}
