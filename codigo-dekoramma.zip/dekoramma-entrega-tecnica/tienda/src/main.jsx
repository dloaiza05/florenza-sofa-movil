"use client";
/**
 * Hecho por Leidy Rodriguez · Iniciado el 11/09/2026
 * [contacto privado omitido en copia pública] · Realizado por Florenza Digital
 */
import React, { useState, useEffect, useRef, lazy, Suspense } from "react";
import dynamic from "next/dynamic";
import {
  Search,
  ShoppingBag,
  User,
  Menu,
  X,
  Box,
  Factory,
  Ruler,
  Truck,
  CreditCard,
  Play,
  ArrowRight,
  MessageCircle,
  MapPin,
  SlidersHorizontal,
  Pause,
  Check,
  Plus,
  Minus,
} from "lucide-react";
import { api, money, categories, mediaUrl } from "./api";
import DeliveryLocation from "./DeliveryLocation";
import DeliveryRegion, { regionKey } from "./DeliveryRegion";
import ProductDetail from "./ProductDetail";
import MarketingSignup from "./MarketingSignup";
import Checkout from "./Checkout";
import CampaignHero from "./CampaignHero";
import WelcomeBanner from "./WelcomeBanner";
import Explore3DButton from "./Explore3DButton";
import SocialIcon from "./SocialIcon";
import FinanceShowcase from "./FinanceShowcase";
import PaymentBrand from "./PaymentBrand";
import { productPhoto } from "./product-photo";
import ProductReveal from "./ProductReveal";
import { adviceConsent } from "./consent-copy";
import { partLabels } from "./product-options";
import { storeDirections, storeShare, mapSearch } from "./locations";

const Viewer = dynamic(() => import("./Viewer"), {
  ssr: false,
  loading: () => <p>Cargando visor 3D…</p>,
});
const colorHex = {
  Arena: "#d9cdb4",
  Gris: "#888b86",
  Petróleo: "#2e7680",
  Rosa: "#bd8584",
  Terracota: "#b06d59",
  Mostaza: "#b68a49",
};
export function Logo() {
  return (
    <a className="logo" href="/" aria-label="Dekoramma, inicio">
      <svg
        viewBox="0 0 208 64"
        role="img"
        aria-label="Dekoramma · Estilo y arte"
      >
        <defs>
          <image
            id="original-logo"
            href="/assets/logo.png"
            width="640"
            height="640"
          />
        </defs>
        <svg x="0" y="8" width="46" height="44" viewBox="200 116 232 210">
          <use href="#original-logo" />
        </svg>
        <svg x="57" y="3" width="139" height="56" viewBox="60 348 510 210">
          <use href="#original-logo" />
        </svg>
      </svg>
    </a>
  );
}
export function Modal({ title, onClose, children, wide = false }) {
  const ref = useRef();
  useEffect(() => {
    const prior = document.activeElement;
    ref.current.showModal();
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "";
      prior?.focus?.();
    };
  }, []);
  return (
    <dialog
      ref={ref}
      className={"modal " + (wide ? "wide" : "")}
      aria-label={title}
      onCancel={onClose}
      onClick={(e) => {
        if (e.target === ref.current) onClose();
      }}
    >
      <div className="modal-head">
        <h2>{title}</h2>
        <button className="icon" aria-label="Cerrar" onClick={onClose}>
          <X />
        </button>
      </div>
      {children}
    </dialog>
  );
}
export default function App({ initialData = null }) {
  const [deliveryRegion, setDeliveryRegion] = useState(null);
  const [showTop, setShowTop] = useState(false);
  useEffect(() => {
    try { const value = JSON.parse(localStorage.getItem(regionKey)); if (typeof value?.department === "string" && typeof value?.city === "string") setDeliveryRegion(value); } catch {}
    const update = () => setShowTop(window.scrollY > 600);
    update(); window.addEventListener("scroll", update, { passive: true });
    return () => window.removeEventListener("scroll", update);
  }, []);
  const [data, setData] = useState(initialData),
    [error, setError] = useState(""),
    [category, setCategory] = useState("Todo"),
    [query, setQuery] = useState(""),
    [sort, setSort] = useState("featured"),
    [filter, setFilter] = useState(false),
    [drawer, setDrawer] = useState(false),
    [paused, setPaused] = useState(false),
    [modal, setModal] = useState(null),
    [cart, setCart] = useState([]),
    [cartLoaded, setCartLoaded] = useState(false),
    [notice, setNotice] = useState(""),
    [shape, setShape] = useState("En L"),
    [fabric, setFabric] = useState("Petróleo"),
    [extras, setExtras] = useState([]),
    [amount, setAmount] = useState(2450000),
    [budget, setBudget] = useState("3000000"),
    [people, setPeople] = useState("3"),
    [needBed, setNeedBed] = useState(false),
    [maxPrice, setMaxPrice] = useState(null),
    [page, setPage] = useState(1),
    [paged, setPaged] = useState(null),
    [catalogError, setCatalogError] = useState(""),
    [catalogBusy, setCatalogBusy] = useState(false);
  useEffect(() => {
    setPage(1);
  }, [category, query, sort, maxPrice]);
  useEffect(() => {
    let active = true;
    setCatalogBusy(true);
    const timer = setTimeout(() => {
      const params = new URLSearchParams({
        category,
        q: query,
        sort,
        page: String(page),
        pageSize: "12",
      });
      if (maxPrice) params.set("maxPrice", String(maxPrice));
      api("/products?" + params)
        .then((result) => {
          if (active) {
            setPaged(result);
            setCatalogError("");
          }
        })
        .catch((e) => {
          if (active) setCatalogError(e.message);
        })
        .finally(() => {
          if (active) setCatalogBusy(false);
        });
    }, 200);
    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [category, query, sort, maxPrice, page]);
  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem("dk-cart") || "[]");
      if (Array.isArray(saved))
        setCart(
          saved
            .slice(0, 20)
            .filter(
              (x) =>
                typeof x.id === "string" &&
                typeof x.color === "string" &&
                Number.isInteger(x.quantity) &&
                x.quantity > 0 &&
                x.quantity <= 10,
            ),
        );
    } catch {}
    setCartLoaded(true);
  }, []);
  useEffect(() => {
    api("/catalog")
      .then(setData)
      .catch((e) => setError(e.message));
  }, []);
  useEffect(() => {
    if (cartLoaded)
      try {
        localStorage.setItem("dk-cart", JSON.stringify(cart));
      } catch {}
  }, [cart, cartLoaded]);
  useEffect(() => {
    if (notice) {
      const t = setTimeout(() => setNotice(""), 5000);
      return () => clearTimeout(t);
    }
  }, [notice]);
  if (error)
    return (
      <main className="loading">
        <h1>No pudimos cargar la tienda</h1>
        <p>{error}</p>
        <button onClick={() => location.reload()}>Reintentar</button>
      </main>
    );
  if (!data) return <div className="loading">Preparando tu próxima sala…</div>;
  const { products, settings: s, content: c } = data,
    section = (id) => c.sections.find((x) => x.id === id),
    bruna = products.find((p) => p.id === "bruna") || products[0],
    heroProduct = bruna;
  const wa = (message) =>
      "https://wa.me/" + s.phone + "?text=" + encodeURIComponent(message),
    go = (id) => {
      setDrawer(false);
      document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    },
    openLead = (type = "asesoria") =>
      setModal({ type: "lead", leadType: type });
  const add = (p, color = p.colors[0]) => {
    setCart((old) => {
      const found = old.find((x) => x.id === p.id && x.color === color);
      return found
        ? old.map((x) =>
            x === found ? { ...x, quantity: Math.min(10, x.quantity + 1) } : x,
          )
        : [...old, { id: p.id, color, quantity: 1 }];
    });
    setNotice(p.name + " añadido a tu bolsa");
    setModal({ type: "cart", checkout: true });
  };
  const cartItems = cart.map((x) => ({
      ...x,
      product: products.find((p) => p.id === x.id),
    })),
    total = cartItems.reduce(
      (n, x) => n + (x.product?.price || 0) * x.quantity,
      0,
    ),
    count = cart.reduce((n, x) => n + x.quantity, 0);
  let list = products.filter(
    (p) =>
      (!maxPrice || p.price <= maxPrice) &&
      (category === "Todo" || p.category === category) &&
      [p.name, p.category, p.description]
        .join(" ")
        .toLowerCase()
        .includes(query.toLowerCase()),
  );
  if (sort !== "featured")
    list = [...list].sort((a, b) =>
      sort === "low" ? a.price - b.price : b.price - a.price,
    );
  else
    list = [...list].sort(
      (a, b) =>
        ["canela", "milan", "aurora", "bruna", "rose", "nara"].indexOf(a.id) -
        ["canela", "milan", "aurora", "bruna", "rose", "nara"].indexOf(b.id),
    );
  const catalogTotal = paged?.total ?? list.length;
  const catalogPages = paged?.pages ?? Math.max(1, Math.ceil(list.length / 12));
  list = paged?.items ?? list.slice(0, 12);
  const openProduct = async (
    p,
    type = "product",
    initialColor = p.colors[0],
  ) => {
    try {
      const full = await api("/products/" + p.id);
      setModal({ type, p: full, initialColor });
    } catch (e) {
      setNotice(e.message);
    }
  };
  const icons = {
    factory: Factory,
    ruler: Ruler,
    truck: Truck,
    card: CreditCard,
    cube: Box,
  };
  const sections = {
    catalogo: (
      <section id="catalogo" className="wrap catalog">
        <h2>{section("catalogo").title}</h2>
        <div className="catalog-tools">
          <div className="tabs" aria-label="Categorías">
            {["Todo", ...categories].map((x) => (
              <button
                key={x}
                className={category === x ? "active" : ""}
                onClick={() => setCategory(x)}
              >
                {x}
              </button>
            ))}
          </div>
          <button
            className="icon"
            aria-label="Buscar y filtrar productos"
            onClick={() => setFilter(!filter)}
          >
            <Search />
            <SlidersHorizontal />
          </button>
        </div>
        {filter && (
          <div className="filter">
            <label>
              Buscar producto
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Nombre, tipo o descripción"
              />
            </label>
            <label>
              Ordenar
              <select value={sort} onChange={(e) => setSort(e.target.value)}>
                <option value="featured">Destacados</option>
                <option value="low">Menor precio</option>
                <option value="high">Mayor precio</option>
              </select>
            </label>
          </div>
        )}
        <p className="catalog-count" aria-live="polite">
          {catalogBusy
            ? "Actualizando catálogo…"
            : `${catalogTotal} ${catalogTotal === 1 ? "referencia" : "referencias"} · Página ${paged?.page || page} de ${catalogPages}`}
        </p>
        {catalogError && (
          <p role="alert" className="error">
            {catalogError}
          </p>
        )}
        <div className="products" aria-busy={catalogBusy}>
          {list.map((p, i) => (
            <Product
              key={p.id}
              p={p}
              i={i + ((paged?.page || page) - 1) * 12}
              onAdd={add}
              onDetails={(color) => openProduct(p, "product", color)}
              on3d={(color) => openProduct(p, "3d", color)}
            />
          ))}
        </div>
        {!list.length && (
          <p className="empty">
            No encontramos productos con esos filtros.{" "}
            <button
              onClick={() => {
                setCategory("Todo");
                setQuery("");
                setMaxPrice(null);
              }}
            >
              Ver todas
            </button>
          </p>
        )}
        {catalogPages > 1 && (
          <nav className="pagination" aria-label="Páginas del catálogo">
            <button
              className="outline"
              disabled={catalogBusy || page <= 1}
              onClick={() => {
                setPage(Math.max(1, (paged?.page || page) - 1));
                go("catalogo");
              }}
            >
              Anterior
            </button>
            <span>
              Página {paged?.page || page} de {catalogPages}
            </span>
            <button
              className="outline"
              disabled={catalogBusy || (paged?.page || page) >= catalogPages}
              onClick={() => {
                setPage((paged?.page || page) + 1);
                go("catalogo");
              }}
            >
              Siguiente
            </button>
          </nav>
        )}
        <div className="center">
          <button
            className="outline"
            onClick={() => {
              setCategory("Todo");
              setQuery("");
              setMaxPrice(null);
              setFilter(true);
              go("catalogo");
            }}
          >
            Ver catálogo completo · {products.length} modelos
          </button>
        </div>
      </section>
    ),
    reels: (
      <section id="reels" className="wrap split-strip">
        <h2>{section("reels").title}</h2>
        <div className="reels">
          {c.reels.map((r) => (
            <button
              className="reel"
              key={r.id}
              onClick={() => setModal({ type: "reel", r })}
            >
              <img loading="lazy" src={mediaUrl(r.image)} alt={r.title} />
              <span className="play">
                <Play size={19} />
              </span>
              <strong>{r.title}</strong>
            </button>
          ))}
        </div>
      </section>
    ),
    configurador: (
      <section id="configurador" className="wrap configurator">
        <div>
          <h2>{section("configurador").title}</h2>
          <p>{section("configurador").subtitle}</p>
        </div>
        <div>
          <img
            className="config-photo"
            src={mediaUrl(bruna?.image)}
            alt="Referencia de sala modular"
          />
          <p className="caption">
            Referencia de configuración · medidas por confirmar
          </p>
        </div>
        <div className="config-options">
          <label>1. Configuración</label>
          <div className="tabs">
            {["Lineal", "En L", "En U"].map((x) => (
              <button
                className={x === shape ? "active" : ""}
                key={x}
                onClick={() => setShape(x)}
              >
                {x}
              </button>
            ))}
          </div>
          <label>2. Tela · {fabric}</label>
          <div className="swatches">
            {["Petróleo", "Terracota", "Mostaza", "Gris", "Arena"].map((x) => (
              <button
                key={x}
                className={fabric === x ? "chosen" : ""}
                style={{ background: colorHex[x] }}
                aria-label={"Tela " + x}
                aria-pressed={fabric === x}
                onClick={() => setFabric(x)}
              />
            ))}
          </div>
          <label>3. Extras (opcionales)</label>
          {["Baúl", "Mesa de centro", "Antifluidos"].map((x) => (
            <label className="check" key={x}>
              <input
                type="checkbox"
                checked={extras.includes(x)}
                onChange={() =>
                  setExtras(
                    extras.includes(x)
                      ? extras.filter((y) => y !== x)
                      : [...extras, x],
                  )
                }
              />
              {x}
            </label>
          ))}
        </div>
        <div className="configuration-summary">
          <small>Tu diseño</small>
          <div
            className={"room-shape " + shape.replace(" ", "").toLowerCase()}
            style={{ "--fabric": colorHex[fabric] }}
          >
            <span />
            <span />
            <span />
          </div>
          <strong>
            {shape} · {fabric}
          </strong>
          <p>{extras.join(" · ") || "Sin extras"}</p>
          <small>Precio y medidas sujetos a cotización</small>
          <button onClick={() => openLead("personalizacion")}>
            Cotizar mi diseño
          </button>
        </div>
      </section>
    ),
    espacio: (
      <section id="espacio" className="wrap two-panels">
        <article>
          <div>
            <h2>{section("espacio").title}</h2>
            <p>{section("espacio").subtitle}</p>
            <Explore3DButton
              inline
              productName={heroProduct?.name}
              onClick={() => setModal({ type: "3d", p: heroProduct })}
            />
            <button
              className="text-button"
              onClick={() => setModal({ type: "3d", p: heroProduct })}
            >
              Ver en mi espacio
            </button>
            <a className="text-button" href="/prueba3d/index.html">
              Probar sofá de Blender · cámara del celular
            </a>
          </div>
          <div className="phone-visual">
            <img src={mediaUrl(bruna?.image)} alt="Sala en tu espacio" />
            <span>
              <Box size={17} /> 3D · Girar
            </span>
          </div>
        </article>
        <article>
          <div>
            <h2>¿Cuál va contigo?</h2>
            <p>Responde 3 preguntas y encuentra la sala que encaja contigo.</p>
            <button
              className="outline"
              onClick={() => setModal({ type: "quiz" })}
            >
              Empezar asesor rápido
            </button>
          </div>
          <MessageCircle size={68} />
        </article>
      </section>
    ),
    financiacion: (
      <section id="financiacion" className="wrap finance finance--branded">
        <FinanceShowcase
          title={section("financiacion").title}
          onBrowse={(methods, title) =>
            setModal({ type: "payment-options", methods, title })
          }
          subtitle={section("financiacion").subtitle}
          banners={c.financeBanners}
          methods={s.paymentMethods}
          demo={s.demo}
          onChoose={(method) => setModal({ type: "payment", method })}
        />
        <div className="calculator">
          <h3>Simula tu cuota</h3>
          <div className="price-line">
            <label htmlFor="amount">Valor de la sala</label>
            <strong>{money(amount)}</strong>
          </div>
          <input
            id="amount"
            type="range"
            min="1000000"
            max="10000000"
            step="50000"
            value={amount}
            onChange={(e) => setAmount(+e.target.value)}
          />
          <div className="two-panels">
            <div>
              <small>Referencia: 3 partes</small>
              <strong>{money(Math.ceil(amount / 3))} / mes</strong>
            </div>
            <div>
              <small>Referencia: apartado del 20 %</small>
              <strong>{money(amount * 0.2)}</strong>
            </div>
          </div>
          <p className="caption">
            Simulación matemática. No constituye aprobación de crédito ni
            incluye intereses.
          </p>
          <p className="caption">{s.paymentNote}</p>
        </div>
      </section>
    ),
    taller: (
      <section id="taller" className="wrap workshop">
        <div>
          <h2>{section("taller").title}</h2>
          <p>{section("taller").subtitle}</p>
          <button onClick={() => setModal({ type: "workshop" })}>
            Conoce el taller
          </button>
        </div>
        <img
          loading="lazy"
          src={mediaUrl(c.workshop.image)}
          alt="Fabricación en el taller"
        />
        <div>
          {c.workshop.steps.map((x, i) => {
            const I = [Ruler, Factory, Truck][i % 3];
            return (
              <article key={i}>
                <I />
                <div>
                  <h3>{x.title}</h3>
                  <p>{x.text}</p>
                </div>
              </article>
            );
          })}
        </div>
      </section>
    ),
    galeria: (
      <section id="galeria" className="wrap">
        <div className="section-top">
          <h2>{section("galeria").title}</h2>
          <a href={s.facebook} target="_blank" rel="noreferrer">
            Ver opiniones en Facebook →
          </a>
        </div>
        <div className="gallery">
          {c.gallery.map((x) => (
            <button
              key={x.id}
              onClick={() =>
                setModal({ type: "image", image: x.image, title: x.title })
              }
            >
              <img loading="lazy" src={mediaUrl(x.image)} alt={x.title} />
            </button>
          ))}
        </div>
      </section>
    ),
    contacto: (
      <section id="contacto" className="wrap contact-grid">
        <article id="envios">
          <h2>Llegamos hasta tu hogar</h2>
          <p>{c.delivery.text}</p>
          {c.delivery.cities.map((city) => (
            <p key={city}>
              <MapPin size={17} />
              {city}
            </p>
          ))}
          <button onClick={() => openLead("envio")}>Consultar mi ciudad</button>
          <button
            className="text-button"
            onClick={() => setModal({ type: "location" })}
          >
            Enviar ubicación de entrega por WhatsApp
          </button>
        </article>
        <article>
          <div>
            <h2>{section("contacto").title}</h2>
            <p>
              <strong>{s.address}</strong>
            </p>
            <p>{s.hours}</p>
            <div className="actions">
              <a
                className="button outline"
                href={storeDirections(s)}
                target="_blank"
                rel="noreferrer"
              >
                Cómo llegar
              </a>
              <a
                className="button"
                href={wa("Hola, quiero conocer las salas de Dekoramma.")}
                target="_blank"
                rel="noreferrer"
              >
                Escribir por WhatsApp
              </a>
              <a
                className="button outline"
                href={mapSearch(s.address, s.mapsPlaceId)}
                target="_blank"
                rel="noreferrer"
              >
                Ver mapa de la tienda
              </a>
              <a
                className="text-button"
                href={storeShare(s)}
                target="_blank"
                rel="noreferrer"
              >
                Compartir ubicación por WhatsApp
              </a>
            </div>
          </div>
          <img
            loading="lazy"
            src={mediaUrl(products[0]?.image)}
            alt="Visita nuestra tienda"
          />
        </article>
      </section>
    ),
  };
  return (
    <>
      <WelcomeBanner
        banner={c.welcomeBanner}
        Modal={Modal}
        suppressed={!!modal || drawer}
      />
      <div className="announcement">{s.announcement}</div>
      <header className="header">
        <div className="wrap header-inner">
          <button
            className={
              "icon menu-button " + (c.navigation.drawer ? "always" : "")
            }
            aria-label="Abrir catálogo"
            onClick={() => setDrawer(true)}
          >
            <Menu />
          </button>
          <Logo />
          <nav>
            <a href="#catalogo">Catálogo</a>
            <a href="#configurador">Diséñala</a>
            <a href="#financiacion">Financiación</a>
            <a href="#taller">El taller</a>
            <a href="#contacto">Visítanos</a>
          </nav>
          <div className="header-actions">
            <button className="delivery-picker" aria-label={deliveryRegion ? `Entrega en ${deliveryRegion.city}. Cambiar ciudad` : "Elegir ciudad de entrega"} title="Elegir ciudad de entrega" onClick={() => setModal({ type: "region" })}><MapPin size={19}/><span><small>Enviar a</small><strong>{deliveryRegion?.city || "Elegir ciudad"}</strong></span></button>
            <button
              className="icon"
              aria-label="Buscar"
              onClick={() => {
                setFilter(true);
                go("catalogo");
              }}
            >
              <Search />
            </button>
            <button
              className="icon bag"
              aria-label={"Bolsa, " + count + " productos"}
              onClick={() => setModal({ type: "cart" })}
            >
              <ShoppingBag />
              {count > 0 && <span>{count}</span>}
            </button>
            <a
              className="icon"
              aria-label="Ingresar a administración"
              title="Administración"
              href="/admin"
            >
              <User />
            </a>
            <button className="advice" onClick={() => openLead()}>
              Asesoría
            </button>
          </div>
        </div>
      </header>
      <main>
        <CampaignHero
          campaigns={c.campaigns}
          demo={s.demo}
          onCategory={(value) => {
            setCategory(value);
            setQuery("");
            go("catalogo");
          }}
        >
          <section className="hero">
            <div className="hero-copy">
              <span className="eyebrow">{c.hero.eyebrow}</span>
              <h1>
                {c.hero.title.split("\n").map((x, i) => (
                  <React.Fragment key={i}>
                    {x}
                    <br />
                  </React.Fragment>
                ))}
              </h1>
              <p>{c.hero.text}</p>
              <div className="actions">
                <button onClick={() => go("catalogo")}>{c.hero.primary}</button>
                <button
                  className="outline light"
                  onClick={() => setModal({ type: "3d", p: heroProduct })}
                >
                  {c.hero.secondary}
                </button>
              </div>
            </div>
            <div className="hero-image">
              <img
                src={mediaUrl(s.heroImage)}
                alt="Sala modular petróleo en un ambiente industrial"
              />
              <Explore3DButton
                hero
                productName={heroProduct?.name}
                onClick={() => setModal({ type: "3d", p: heroProduct })}
              />
            </div>
          </section>
        </CampaignHero>
        <div className="wrap benefit-container">
          <div className={"benefit-track " + (paused ? "paused" : "")}>
            {[...c.benefits, ...c.benefits].map((b, i) => {
              const I = icons[b.icon] || Box;
              return (
                <a
                  key={i}
                  href={"#" + b.target}
                  tabIndex={i >= c.benefits.length ? -1 : 0}
                  aria-hidden={i >= c.benefits.length || undefined}
                >
                  <I />
                  <div>
                    <strong>{b.title}</strong>
                    <small>{b.text}</small>
                  </div>
                </a>
              );
            })}
          </div>
          <button
            className="icon pause"
            aria-label={paused ? "Reanudar franja" : "Pausar franja"}
            onClick={() => setPaused(!paused)}
          >
            {paused ? <Play size={15} /> : <Pause size={15} />}
          </button>
        </div>
        {c.sections
          .filter((x) => x.visible)
          .map((x) => (
            <React.Fragment key={x.id}>{sections[x.id]}</React.Fragment>
          ))}
        <section className="wrap faqs">
          {c.faq.map((x) => (
            <details key={x.id}>
              <summary>{x.title}</summary>
              <p>{x.text}</p>
            </details>
          ))}
        </section>
      </main>
      {s.marketingEnabled !== false && (
        <MarketingSignup
          legalFingerprint={data.legalFingerprint}
          settings={s}
          onAdvice={() => openLead("asesoria")}
        />
      )}
      <section className="wrap information-strip">
        <div>
          <h2>Estamos aquí para acompañarte.</h2>
          <p>
            Ubicación, garantías, condiciones de compra y documentación de
            Dekoramma.
          </p>
        </div>
        <a className="button outline" href="/informacion">
          Consultar información y documentos
        </a>
      </section>
      <footer>
        <div className="wrap footer-connect">
          <div><h3>Medios de pago y financiación</h3><div className="footer-payment-brands">{[...new Set([...(s.paymentMethods || []), ...(s.paymentMethods?.includes("Bold") ? ["Visa", "Mastercard"] : [])])].map(method => <button key={method} aria-label={`Consultar condiciones de ${method}`} onClick={() => setModal({ type: "payment", method })}><PaymentBrand method={method}/></button>)}</div><p className="caption">Consulta disponibilidad y condiciones con Dekoramma.</p></div>
          <div className="footer-community"><h3>Más ideas para tu hogar</h3><p>Conoce nuestros muebles y novedades.</p><nav aria-label="Redes sociales de Dekoramma">{[["facebook", s.facebook, "Facebook"], ["instagram", s.instagram, "Instagram"]].filter(([, url]) => url).map(([brand, url, label]) => <a key={brand} href={url} target="_blank" rel="noopener noreferrer"><SocialIcon brand={brand}/><span>{label}</span></a>)}</nav></div>
        </div>
        <div className="wrap footer-grid">
          <div className="footer-logo">
            <Logo />
          </div>
          <div>
            <h3>Catálogo</h3>
            {categories.slice(0, 4).map((x) => (
              <button
                key={x}
                onClick={() => {
                  setCategory(x);
                  go("catalogo");
                }}
              >
                {x}
              </button>
            ))}
          </div>
          <div>
            <h3>Ayuda</h3>
            <a href="#configurador">Medidas y telas</a>
            <button onClick={() => openLead("envio")}>Envíos y entregas</button>
            <a href="#financiacion">Financiación</a>
            <button onClick={() => setModal({ type: "track" })}>
              Seguimiento de solicitud
            </button>
          </div>
          <div>
            <h3>Información</h3>
            <a href="/informacion#terminos">Términos y condiciones</a>
            <a href="/informacion#privacidad">Política de privacidad</a>
            <a href="/informacion#garantias">Garantías</a>
            <a href="/informacion#retracto">Derecho de retracto</a>
            <a href="https://www.sic.gov.co/" target="_blank" rel="noreferrer">
              Superintendencia de Industria y Comercio
            </a>
            <a href="/informacion#documentos">Documentación comercial</a>
          </div>
          <div>
            <h3>Contacto</h3>
            {s.email && <a href={"mailto:" + s.email}>{s.email}</a>}
            <a href={"tel:+" + s.phone}>+{s.phone}</a>
            <p>Bogotá, Colombia</p>
            <a href="/admin">Administración</a>
          </div>
        </div>
        <div className="wrap footer-bottom">
          Diseño y desarrollo · Florenza Estudio Digital
          {s.demo && (
            <span>
              Vista de desarrollo · productos, imágenes y precios ilustrativos
            </span>
          )}
        </div>
      </footer>
      {showTop && <button className="back-to-top" aria-label="Volver arriba" onClick={() => window.scrollTo({ top: 0, behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" })}><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true"><path d="m6 12 6-5 6 5M6 18l6-5 6 5"/></svg><span>Arriba</span></button>}
      <a
        className="whatsapp"
        aria-label="Asesoría por WhatsApp"
        href={wa("Hola, me interesa una sala a medida.")}
        target="_blank"
        rel="noreferrer"
      >
        <SocialIcon brand="whatsapp" />
      </a>
      {notice && (
        <div className="toast" role="status">
          <Check size={18} />
          {notice}
          <button
            className="text-button"
            onClick={() => setModal({ type: "cart" })}
          >
            Ver bolsa
          </button>
        </div>
      )}
      {drawer && (
        <Modal title="Catálogo" onClose={() => setDrawer(false)}>
          <div className="drawer-links">
            {["Todo", ...categories].map((x) => (
              <button
                key={x}
                onClick={() => {
                  setCategory(x);
                  go("catalogo");
                }}
              >
                {x}
                <ArrowRight size={18} />
              </button>
            ))}
            <a href="#configurador" onClick={() => setDrawer(false)}>
              Diseña tu sala
            </a>
            <a href="/admin">Administración</a>
          </div>
        </Modal>
      )}
      {modal && (
        <Modal
          title={
            {
              success: "Solicitud recibida",
              cart: modal.checkout ? "Finaliza tu compra" : "Tu bolsa",
              product: modal.p?.name,
              "3d": "Mírala en 3D",
              lead: "Hablemos de tu sala",
              quiz: "Encuentra tu sala",
              payment: modal.method,
              "payment-options": modal.title,
              track: "Sigue tu solicitud",
              location: "Ubicación para tu entrega",
              region: "¿Dónde recibes tu mueble?",
              reel: modal.r?.title,
              workshop: "Nuestro taller",
              image: modal.title,
              text: modal.title,
            }[modal.type]
          }
          wide={["3d", "product"].includes(modal.type)}
          onClose={() => setModal(null)}
        >
          {modal.type === "3d" && (
            <Suspense fallback={<p>Cargando visor…</p>}>
              <Viewer
                product={modal.p}
                initialColor={modal.initialColor}
                onBuy={add}
                onQuote={(configuration) =>
                  setModal({
                    type: "lead",
                    leadType: "personalizacion",
                    configuration,
                  })
                }
              />
            </Suspense>
          )}
          {modal.type === "product" && (
            <ProductDetail
              key={modal.p.id}
              product={modal.p}
              initialColor={modal.initialColor}
              onAdd={(p, color) => {
                add(p, color);
              }}
              on3d={(color) =>
                setModal({ type: "3d", p: modal.p, initialColor: color })
              }
              onQuote={(color) =>
                setModal({
                  type: "lead",
                  leadType: "personalizacion",
                  configuration: {
                    kind: "product",
                    productId: modal.p.id,
                    productName: modal.p.name,
                    color,
                    parts: {},
                    legOption: "",
                  },
                })
              }
            />
          )}
          {modal.type === "cart" && (
            <>
              <div className="checkout-order-summary">
                {cartItems.length === 0 ? (
                  <p className="empty">
                    Tu bolsa está vacía. Encuentra una sala que vaya contigo.
                  </p>
                ) : (
                  cartItems.map((x, i) => (
                    <div className="cart-row" key={x.id + x.color}>
                      <img
                        src={mediaUrl(productPhoto(x.product, x.color).url)}
                        alt={productPhoto(x.product, x.color).alt}
                      />
                      <div>
                        <strong>
                          {x.product?.name || "Producto no disponible"}
                        </strong>
                        <small>
                          Color seleccionado: {x.color} ·{" "}
                          {money((x.product?.price || 0) * x.quantity)}
                        </small>
                        {!productPhoto(x.product, x.color).matched && (
                          <small className="caption">
                            Imagen de referencia; foto de este color pendiente.
                          </small>
                        )}
                        {productPhoto(x.product, x.color).matched &&
                          /ilustrativa|generada/i.test(
                            productPhoto(x.product, x.color).alt,
                          ) && (
                            <small className="caption">
                              Imagen ilustrativa generada · tono por confirmar
                              con la tela real.
                            </small>
                          )}
                        <div className="quantity">
                          <button
                            className="icon"
                            aria-label="Restar unidad"
                            onClick={() =>
                              setCart(
                                cart.map((y, j) =>
                                  j === i
                                    ? {
                                        ...y,
                                        quantity: Math.max(1, y.quantity - 1),
                                      }
                                    : y,
                                ),
                              )
                            }
                          >
                            <Minus size={14} />
                          </button>
                          {x.quantity}
                          <button
                            className="icon"
                            aria-label="Sumar unidad"
                            onClick={() =>
                              setCart(
                                cart.map((y, j) =>
                                  j === i
                                    ? {
                                        ...y,
                                        quantity: Math.min(10, y.quantity + 1),
                                      }
                                    : y,
                                ),
                              )
                            }
                          >
                            <Plus size={14} />
                          </button>
                          <button
                            className="text-button"
                            onClick={() =>
                              setCart(cart.filter((_, j) => i !== j))
                            }
                          >
                            Quitar
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
              {cart.length > 0 && (
                <>
                  <h3>Subtotal {money(total)}</h3>
                  <p>
                    Envío por cotizar. La solicitud no realiza ningún cobro.
                  </p>
                  <Checkout
                    items={cart}
                    methods={s.paymentMethods}
                    legalFingerprint={data.legalFingerprint}
                    onDone={(result) => {
                      setCart([]);
                      setModal({ type: "success", result });
                    }}
                  />
                </>
              )}
            </>
          )}
          {modal.type === "success" && (
            <>
              <p>
                Tu referencia: <strong>{modal.result.id}</strong>
              </p>
              <p>
                Conserva tu referencia y clave de seguimiento. Un asesor debe
                confirmar precio, envío y pago.
              </p>
              {modal.result.trackingToken && (
                <details>
                  <summary>Ver mi clave privada de seguimiento</summary>
                  <code className="private-tracking-key">
                    {modal.result.trackingToken}
                  </code>
                  <p>
                    No compartas esta clave; permite consultar tu solicitud.
                  </p>
                </details>
              )}
              <button onClick={() => setModal({ type: "track" })}>
                Consultar estado
              </button>
            </>
          )}
          {modal.type === "lead" && (
            <Lead
              legalFingerprint={data.legalFingerprint}
              type={modal.leadType}
              config={modal.configuration || { shape, fabric, extras }}
              onSuccess={() =>
                setModal({
                  type: "text",
                  title: "Solicitud recibida",
                  text: "Tu solicitud quedó registrada. El equipo de la tienda podrá verla en Administración → Asesorías.",
                })
              }
            />
          )}
          {modal.type === "quiz" && (
            <div className="form-grid">
              <label>
                Presupuesto máximo
                <select
                  value={budget}
                  onChange={(e) => setBudget(e.target.value)}
                >
                  <option value="1500000">Hasta $1.500.000</option>
                  <option value="3000000">Hasta $3.000.000</option>
                  <option value="10000000">Más de $3.000.000</option>
                </select>
              </label>
              <label>
                Personas
                <select
                  value={people}
                  onChange={(e) => setPeople(e.target.value)}
                >
                  <option value="1">1–2 personas</option>
                  <option value="3">3–4 personas</option>
                  <option value="5">5 o más personas</option>
                </select>
              </label>
              <label className="check">
                <input
                  type="checkbox"
                  checked={needBed}
                  onChange={(e) => setNeedBed(e.target.checked)}
                />
                Necesito función cama
              </label>
              <button
                onClick={() => {
                  setQuery("");
                  setCategory(
                    needBed
                      ? "Sofás cama"
                      : people === "1"
                        ? "Poltronas"
                        : people === "5"
                          ? "Esquineros"
                          : "Modulares",
                  );
                  setSort("low");
                  setMaxPrice(+budget);
                  setModal(null);
                  go("catalogo");
                  setNotice(
                    "Mira estas opciones y confirma tu presupuesto de " +
                      money(+budget) +
                      " con un asesor.",
                  );
                }}
              >
                Ver opciones para mí
              </button>
            </div>
          )}
          {modal.type === "payment" && (
            <>
              <div className="payment-modal-brand">
                <PaymentBrand method={modal.method} />
              </div>
              <p>{s.paymentNote}</p>
              <p>
                Tu preferencia por {modal.method} puede quedar registrada en la
                solicitud de compra. La tienda confirma el canal de pago antes
                de cobrarte.
              </p>
              <a
                className="button"
                href={wa(
                  "Quiero consultar condiciones de pago con " + modal.method,
                )}
                target="_blank"
                rel="noreferrer"
              >
                Consultar condiciones por WhatsApp
              </a>
            </>
          )}
          {modal.type === "payment-options" && (
            <div className="finance-option-dialog">
              <p>Elige la entidad para consultar sus condiciones.</p>
              {modal.methods.map((method) => (
                <button
                  key={method}
                  aria-label={`Consultar ${method}`}
                  onClick={() => setModal({ type: "payment", method })}
                >
                  <PaymentBrand method={method} />
                  <span>{method === "Daviplata" ? "DaviPlata" : method}</span>
                  <ArrowRight size={18} />
                </button>
              ))}
              <p className="caption">
                La conexión de cobro está pendiente. Esta consulta no realiza
                ningún cargo.
              </p>
            </div>
          )}
          {modal.type === "track" && <Track />}
          {modal.type === "region" && <DeliveryRegion value={deliveryRegion} onSave={value => { setDeliveryRegion(value); try { localStorage.setItem(regionKey, JSON.stringify(value)); } catch {} setModal(null); }} />}
          {modal.type === "location" && <DeliveryLocation settings={s} region={deliveryRegion} />}
          {modal.type === "text" && <p className="preserve">{modal.text}</p>}
          {modal.type === "reel" && (
            <>
              {modal.r.video ? (
                <video
                  className="video"
                  src={modal.r.video}
                  controls
                  autoPlay
                  playsInline
                />
              ) : (
                <>
                  <img
                    className="modal-photo"
                    src={mediaUrl(modal.r.image)}
                    alt={modal.r.title}
                  />
                  <p>{modal.r.description}</p>
                  <p className="caption">
                    Video pendiente de carga por la tienda.
                  </p>
                </>
              )}
            </>
          )}
          {modal.type === "workshop" && (
            <>
              <img
                className="modal-photo"
                src={mediaUrl(c.workshop.image)}
                alt="Taller"
              />
              <p>{c.workshop.text}</p>
            </>
          )}
          {modal.type === "image" && (
            <img
              className="modal-photo"
              src={mediaUrl(modal.image)}
              alt={modal.title}
            />
          )}
        </Modal>
      )}
    </>
  );
}
function Product({ p, i, onAdd, onDetails, on3d }) {
  const [color, setColor] = useState(p.colors[0]);
  const photo = productPhoto(p, color);
  return (
    <article className="product">
      <ProductReveal>
        <button className="photo-button" onClick={() => onDetails(color)}>
          <img src={mediaUrl(photo.url)} loading="lazy" alt={photo.alt} />
        </button>
        <span className="number">{String(i + 1).padStart(2, "0")}</span>
        {p.modelUrl && (
          <Explore3DButton productName={p.name} onClick={() => on3d(color)} />
        )}
      </ProductReveal>
      <div className="product-info">
        <small className="color-photo-caption">
          Color: {color}
          {!photo.matched
            ? " · imagen de referencia"
            : /ilustrativa|generada/i.test(photo.alt)
              ? " · imagen ilustrativa"
              : ""}
        </small>
        <div className="dots">
          {p.colors.map((x) => (
            <button
              title={x}
              aria-label={p.name + ": " + x}
              aria-pressed={color === x}
              style={{ background: colorHex[x] || "#777" }}
              className={color === x ? "chosen" : ""}
              key={x}
              onClick={() => setColor(x)}
            />
          ))}
        </div>
        <div className="price-line">
          <h3>{p.name}</h3>
          <small>3 partes de {money(Math.ceil(p.price / 3))}</small>
        </div>
        <div className="price-line">
          <strong className="price">{money(p.price)}</strong>
          <small className="accent">Consulta crédito y pagos</small>
        </div>
        <div className="price-line">
          <button onClick={() => onAdd(p, color)}>Comprar ahora</button>
          <button className="detail-link" onClick={() => onDetails(color)}>
            Ver detalles <ArrowRight size={15} />
          </button>
        </div>
      </div>
    </article>
  );
}
function Lead({ type, config, onSuccess, legalFingerprint }) {
  const [busy, setBusy] = useState(false),
    [contactChannel, setContactChannel] = useState("whatsapp"),
    [error, setError] = useState("");
  return (
    <form
      className="form-grid"
      onSubmit={async (e) => {
        e.preventDefault();
        setBusy(true);
        const f = new FormData(e.currentTarget);
        try {
          await api("/leads", {
            method: "POST",
            body: {
              name: f.get("name"),
              phone: f.get("phone"),
              city: f.get("city"),
              message: f.get("message"),
              type,
              email: f.get("email") || "",
              contactChannel,
              preferredDate: f.get("preferredDate") || "",
              preferredTime: f.get("preferredTime") || "",
              legalFingerprint,
              consent: f.get("consent") === "on",
              ...(type === "personalizacion" ? { configuration: config } : {}),
            },
          });
          onSuccess();
        } catch (err) {
          setError(err.message);
        } finally {
          setBusy(false);
        }
      }}
    >
      {type === "personalizacion" && (
        <p>
          Tu elección:{" "}
          {config.kind === "product" ? (
            `${config.productName || config.productId} · ${config.color} · ${
              config.summary ||
              Object.entries(config.parts || {})
                .map(
                  ([part, value]) => (partLabels[part] || part) + ": " + value,
                )
                .join(" · ")
            }${config.legOption ? " · Patas: " + config.legOption : ""}`
          ) : (
            <>
              {config.shape} · {config.fabric} ·{" "}
              {config.extras.join(", ") || "Sin extras"}
            </>
          )}
        </p>
      )}
      <label>
        Nombre
        <input name="name" required maxLength="100" />
      </label>
      <label>
        Teléfono
        <input name="phone" required type="tel" pattern="[+0-9\s-]{7,22}" />
      </label>
      <label>
        Ciudad
        <input name="city" required maxLength="100" />
      </label>
      <label>
        Cuéntanos qué necesitas
        <textarea
          name="message"
          required
          maxLength="2000"
          defaultValue={
            type === "envio"
              ? "Quiero consultar la entrega en mi ciudad."
              : type === "personalizacion"
                ? "Quiero cotizar esta configuración."
                : ""
          }
        />
      </label>
      <label>
        ¿Por dónde prefieres que te respondamos?
        <select
          value={contactChannel}
          onChange={(e) => setContactChannel(e.target.value)}
        >
          <option value="whatsapp">WhatsApp</option>
          <option value="phone">Llamada</option>
          <option value="email">Correo electrónico</option>
        </select>
      </label>
      {contactChannel === "email" && (
        <label>
          Correo electrónico
          <input
            name="email"
            type="email"
            required
            autoComplete="email"
            maxLength={254}
          />
        </label>
      )}
      {type === "asesoria" && (
        <>
          <div className="form-two">
            <label>
              Día que prefieres (opcional)
              <input name="preferredDate" type="date" />
            </label>
            <label>
              Franja preferida
              <select name="preferredTime">
                <option value="">Sin preferencia</option>
                <option value="morning">Mañana</option>
                <option value="afternoon">Tarde</option>
              </select>
            </label>
          </div>
          <p className="caption">
            Un asesor confirmará la disponibilidad y la hora de tu cita.
          </p>
        </>
      )}
      <p className="caption">
        Consulta nuestra{" "}
        <a href="/informacion#privacidad" target="_blank" rel="noreferrer">
          política de privacidad
        </a>
        .
      </p>
      <label className="check">
        <input name="consent" type="checkbox" required />
        {adviceConsent}
      </label>
      {error && <p className="error">{error}</p>}
      <button disabled={busy}>
        {busy ? "Enviando…" : "Enviar a la tienda"}
      </button>
    </form>
  );
}
function Track() {
  const saved = (() => {
      try {
        return JSON.parse(localStorage.getItem("dk-tracking") || "{}");
      } catch {
        return {};
      }
    })(),
    [result, setResult] = useState(null),
    [error, setError] = useState("");
  return (
    <form
      className="form-grid"
      onSubmit={async (e) => {
        e.preventDefault();
        const f = new FormData(e.currentTarget);
        setError("");
        try {
          setResult(
            await api("/track", {
              method: "POST",
              body: { id: f.get("id"), token: f.get("token") },
            }),
          );
        } catch (err) {
          setError(err.message);
        }
      }}
    >
      <label>
        Referencia de solicitud
        <input name="id" required defaultValue={saved.id || ""} />
      </label>
      <label>
        Clave privada de seguimiento
        <input name="token" required defaultValue={saved.token || ""} />
      </label>
      <p className="caption">
        Guarda ambos datos para consultar desde otro dispositivo.
      </p>
      <button>Consultar estado</button>
      {error && <p className="error">{error}</p>}
      {result && (
        <div className="tracking-result">
          <h3>Estado: {result.status.replaceAll("_", " ")}</h3>
          <p>Total de productos: {money(result.total)}</p>
          <p>Pago pendiente de confirmación con la tienda.</p>
        </div>
      )}
    </form>
  );
}
