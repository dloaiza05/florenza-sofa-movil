"use client";
import React, { useEffect, useRef } from "react";
export default function Viewer({ product }) {
  const frame = useRef(null);
  const demo = product?.modelDemo || !product?.modelUrl;
  const send = () => frame.current?.contentWindow?.postMessage({
    type: "florenza:product",
    viewer: product?.viewer || {},
    product: demo ? null : {
      name: product.name, modelUrl: product.modelUrl, usdzUrl: product.usdzUrl,
      width: product.width, depth: product.depth, height: product.height,
      viewer: product.viewer || {},
    },
  }, window.location.origin);
  useEffect(() => {
    const ready = event => {
      if (event.origin === window.location.origin && event.source === frame.current?.contentWindow && event.data?.type === "florenza:ready") send();
    };
    window.addEventListener("message", ready);
    send();
    return () => window.removeEventListener("message", ready);
  }, [product]);
  return <section className="mobile-sofa-integration">
    {demo && <p className="preview-model-note">Sofá de prueba de Florenza VR. Esta referencia aún no tiene su modelo propio cargado; sus medidas y colores pueden ser diferentes.</p>}
    <iframe key={`${product?.id}:${demo}:${product?.modelUrl}`} ref={frame} onLoad={send} title={`Vista 3D · ${product?.name || "Sofá"}`} src="/prueba3d/index.html?integrado=1" allow="xr-spatial-tracking; fullscreen" allowFullScreen style={{ width: "100%", height: "min(76dvh,850px)", minHeight: 450, border: 0, borderRadius: 12 }} />
  </section>;
}
