"use client";
import React, { useEffect, useRef, useState } from "react";
import "@google/model-viewer";
import { modelOptions, partLabels } from "./product-options";
import { money, mediaUrl } from "./api";
import { productPhoto } from "./product-photo";
import { viewerPurchase } from "./viewer-purchase";
import { ShoppingBag, ArrowRight } from "lucide-react";
export default function Viewer(props) {
  if (props.product?.modelDemo || !props.product?.modelUrl) {
    return <section className="mobile-sofa-integration">
      <p>Prueba de Florenza VR con el sofá de dos puestos. Esta referencia del catálogo aún no tiene su modelo propio cargado.</p>
      <iframe title="Sofá en tu espacio · Florenza VR" src="/prueba3d/index.html?integrado=1" allow="xr-spatial-tracking; fullscreen" allowFullScreen style={{ width: "100%", height: "min(76dvh,850px)", minHeight: 450, border: 0, borderRadius: 12 }} />
      <p><a href="/prueba3d/index.html" target="_blank" rel="noopener">Abrir el visor en pantalla completa</a></p>
    </section>;
  }
  return <ProductModelViewer {...props} />;
}
function ProductModelViewer({ product: p, onQuote, initialColor, onBuy }) {
  const ref = useRef(),
    original = useRef(new Map());
  const [failed, setFailed] = useState(false),
    [loaded, setLoaded] = useState(false),
    [arError, setArError] = useState(""),
    [parts, setParts] = useState({}),
    [legOption, setLegOption] = useState(""),
    [missing, setMissing] = useState([]),
    [color, setColor] = useState(initialColor || p?.colors?.[0] || "");
  const options = modelOptions(p || {}),
    leg = options.legs.find((x) => x.id === legOption),
    url = leg?.modelUrl || p?.modelUrl,
    customized = Object.values(parts).some(Boolean);
  useEffect(() => {
    setParts({});
    setLegOption("");
    setColor(initialColor || p?.colors?.[0] || "");
  }, [p?.id]);
  useEffect(() => {
    setLoaded(false);
    setFailed(false);
    setArError("");
    original.current = new Map();
    const el = ref.current;
    if (!el) return;
    const ready = () => {
      for (const material of el.model?.materials || [])
        original.current.set(material.name, [
          ...material.pbrMetallicRoughness.baseColorFactor,
        ]);
      setLoaded(true);
    };
    const error = () => setFailed(true);
    el.addEventListener("load", ready);
    el.addEventListener("error", error);
    if (el.loaded) ready();
    return () => {
      el.removeEventListener("load", ready);
      el.removeEventListener("error", error);
    };
  }, [url]);
  useEffect(() => {
    if (!loaded || !ref.current?.model) return;
    const materials = ref.current.model.materials,
      missingNames = [];
    for (const [part, names] of Object.entries(options.parts))
      for (const name of names) {
        const material = materials.find((x) => x.name === name);
        if (!material) {
          missingNames.push(name);
          continue;
        }
        const finish = options.finishes.find((x) => x.id === parts[part]);
        material.pbrMetallicRoughness.setBaseColorFactor(
          finish?.hex || original.current.get(name) || [1, 1, 1, 1],
        );
      }
    setMissing(missingNames);
  }, [loaded, parts, url, JSON.stringify(options)]);
  const purchase = viewerPurchase(p, color, parts, legOption);
  const photo = productPhoto(p, color);
  const commerce = (
    <div className="viewer-commerce">
      <img src={mediaUrl(photo.url)} alt={photo.alt} />
      <div className="viewer-commerce-info">
        <strong>{p.name}</strong>
        <span>{money(p.price)}</span>
        <small>
          {photo.matched ? "Foto del color elegido" : "Imagen de referencia"}
          {/ilustrativa|generada/i.test(photo.alt) ? " · ilustrativa" : ""}
        </small>
      </div>
      <label>
        Color para comprar
        <select value={color} onChange={(e) => setColor(e.target.value)}>
          {p.colors.map((x) => (
            <option key={x}>{x}</option>
          ))}
        </select>
      </label>
      {onBuy && (
        <button
          className="viewer-buy"
          disabled={!purchase}
          onClick={() => {
            if (purchase) onBuy(purchase.product, purchase.color);
          }}
        >
          <ShoppingBag size={18} />
          {purchase ? "Comprar este color" : "Requiere cotización"}
          <ArrowRight size={18} />
        </button>
      )}
      {!purchase && (
        <p className="viewer-commerce-note">
          Cambiaste piezas o patas. Usa «Cotizar esta configuración» para
          confirmar su precio y conservar tus ajustes.
        </p>
      )}
    </div>
  );
  if (!url)
    return (
      <>
        <p>
          La vista 3D de este mueble estará disponible próximamente. Puedes
          elegir su color y continuar con la compra.
        </p>
        {commerce}
      </>
    );
  return (
    <>
      <p>{p.name} · arrastra para girar y pellizca para acercar.</p>
      {commerce}
      <p className="caption">
        El color de compra se muestra en la foto. El visor conserva los acabados
        del modelo; los cambios por pieza se cotizan.
      </p>
      {p.modelDemo && (
        <p className="viewer-note">
          Modelo geométrico de demostración. No reproduce este producto ni sus
          medidas. Se reemplazará por el modelo real de Blender.
        </p>
      )}
      <div className="viewer-box">
        <model-viewer
          key={url}
          ref={ref}
          src={url}
          ios-src={(leg ? leg.usdzUrl : p.usdzUrl) || undefined}
          alt={"Modelo 3D de " + p.name}
          camera-controls=""
          touch-action="pan-y"
          shadow-intensity="1"
          ar=""
          ar-modes={customized ? "webxr" : "webxr scene-viewer quick-look"}
          ar-scale="fixed"
          ar-placement="floor"
        >
          <button slot="ar-button" hidden>
            Ver en mi espacio
          </button>
        </model-viewer>
      </div>
      {failed && (
        <p className="error" role="alert">
          No pudimos cargar el modelo. Revisa el archivo desde administración.
        </p>
      )}
      {missing.length > 0 && (
        <p className="viewer-note">
          El archivo no contiene todos los materiales configurados. Las piezas
          afectadas están desactivadas; la tienda debe revisar el GLB.
        </p>
      )}
      <div className="model-options">
        {Object.entries(options.parts)
          .filter(([, names]) => names.length && options.finishes.length)
          .map(([part, names]) => (
            <label key={part}>
              {partLabels[part]}
              <select
                disabled={
                  !loaded ||
                  failed ||
                  names.some((name) => missing.includes(name))
                }
                value={parts[part] || ""}
                onChange={(e) => setParts({ ...parts, [part]: e.target.value })}
              >
                <option value="">Acabado original</option>
                {options.finishes.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.label}
                  </option>
                ))}
              </select>
            </label>
          ))}
        {options.legs.length > 0 && (
          <label>
            Tipo de patas
            <select
              value={legOption}
              disabled={!loaded && !failed}
              onChange={(e) => setLegOption(e.target.value)}
            >
              <option value="">Patas del modelo base</option>
              {options.legs.map((x) => (
                <option key={x.id} value={x.id}>
                  {x.label}
                </option>
              ))}
            </select>
          </label>
        )}
      </div>
      {customized && (
        <p className="viewer-note">
          Los acabados personalizados se conservan en la cámara mediante WebXR
          compatible. Otros visores necesitan modelos exportados con esos
          acabados. Puedes volver a «Acabado original» para consultar la vista
          base en esos dispositivos.
        </p>
      )}
      <div className="actions">
        <button
          disabled={!loaded || failed}
          onClick={() => {
            ref.current.resetTurntableRotation();
            ref.current.cameraOrbit = "0deg 75deg 105%";
            ref.current.jumpCameraToGoal();
          }}
        >
          Restablecer vista
        </button>
        <button
          className="outline"
          disabled={!loaded || failed}
          onClick={async () => {
            setArError("");
            if (!ref.current?.canActivateAR) {
              setArError(
                customized
                  ? "Este dispositivo no ofrece cámara AR para esta configuración. Puedes verla en 3D y enviarla a cotización."
                  : "Abre el enlace HTTPS en un celular compatible. En computador puedes girar y ampliar el modelo.",
              );
              return;
            }
            try {
              await ref.current.activateAR();
            } catch {
              setArError(
                "No se pudo iniciar la realidad aumentada en este dispositivo.",
              );
            }
          }}
        >
          Ver en mi espacio
        </button>
      </div>
      {arError && (
        <p role="status" className="viewer-note">
          {arError}
        </p>
      )}
      {onQuote && (
        <div className="configuration-summary">
          <p>
            Los acabados por pieza quedan incluidos en tu solicitud. La tienda
            confirma materiales, medidas y precio antes de fabricar.
          </p>
          <button
            disabled={!loaded || failed || missing.length > 0}
            onClick={() =>
              onQuote({
                kind: "product",
                productId: p.id,
                productName: p.name,
                summary: Object.entries(parts)
                  .filter(([, value]) => value)
                  .map(
                    ([part, id]) =>
                      partLabels[part] +
                      ": " +
                      options.finishes.find((x) => x.id === id)?.label,
                  )
                  .join(" · "),
                color,
                parts: Object.fromEntries(
                  Object.entries(parts).filter(([, value]) => value),
                ),
                legOption,
              })
            }
          >
            Cotizar esta configuración
          </button>
        </div>
      )}
      <p className="caption">
        Escala fija en realidad aumentada. El modelo debe estar en metros y
        validado con las medidas del mueble. La cámara se activa únicamente al
        solicitarlo y conceder permiso; esta página no graba ni sube imágenes
        del espacio.
      </p>
    </>
  );
}
