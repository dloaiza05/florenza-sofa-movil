export const marketingConsent =
  "Autorizo a Dekoramma a usar los datos que proporciono para enviarme novedades, ofertas y promociones únicamente por los canales que elijo. Puedo retirar esta autorización en cualquier momento sin afectar mis compras ni asesorías.";
export const adviceConsent =
  "Autorizo a Dekoramma a usar mis datos y contactarme por el canal elegido para atender esta solicitud de asesoría. Esto no me inscribe a publicidad.";
