"use client";
import React, { useEffect, useState } from "react";
import { api } from "./api";
export default function MarketingPreferences() {
  const [token, setToken] = useState(""),
    [message, setMessage] = useState(""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [email, setEmail] = useState("");
  useEffect(() => {
    setToken(window.location.hash.slice(1));
    api("/catalog")
      .then((x) => setEmail(x.settings.email))
      .catch(() => {});
  }, []);
  return (
    <main className="legal-page wrap">
      <a href="/">← Volver a Dekoramma</a>
      <h1>Tú decides qué recibes.</h1>
      <p>
        Retira tu autorización para novedades, ofertas y promociones. Tus
        solicitudes de compra y asesoría siguen su curso.
      </p>
      {message ? (
        <p role="status">{message}</p>
      ) : (
        <form
          className="form-grid"
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            setError("");
            try {
              const r = await api("/marketing/withdraw", {
                method: "POST",
                body: { token },
              });
              setMessage(r.message);
            } catch (e) {
              setError(e.message);
            } finally {
              setBusy(false);
            }
          }}
        >
          <label>
            Clave de tu enlace privado
            <input
              value={token}
              onChange={(e) => setToken(e.target.value)}
              required
              pattern="[a-f0-9]{64}"
              autoComplete="off"
            />
          </label>
          {error && (
            <p role="alert" className="error">
              {error}
            </p>
          )}
          <button disabled={busy}>
            {busy ? "Guardando…" : "Retirar mi autorización de publicidad"}
          </button>
        </form>
      )}
      <p>
        ¿No tienes tu enlace?{" "}
        {email ? (
          <a
            href={
              "mailto:" +
              email +
              "?subject=Retirar%20autorizacion%20de%20publicidad"
            }
          >
            Solicita la gestión a la tienda
          </a>
        ) : (
          <a href="/informacion#privacidad">Consulta el canal de privacidad</a>
        )}
        .
      </p>
    </main>
  );
}
