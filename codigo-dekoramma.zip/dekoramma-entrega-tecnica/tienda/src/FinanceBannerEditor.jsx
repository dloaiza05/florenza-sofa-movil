import React from "react";
export default function FinanceBannerEditor({ value = [], onChange, Media }) {
  function update(i, key, next) {
    onChange(value.map((b, j) => (j === i ? { ...b, [key]: next } : b)));
  }
  function move(i, delta) {
    const next = [...value];
    [next[i], next[i + delta]] = [next[i + delta], next[i]];
    onChange(next);
  }
  return (
    <details className="editor-section">
      <summary>Banners de financiación · imágenes y contenido</summary>
      <p>
        Sube tus piezas en JPG, PNG o WebP. La imagen para celular es opcional.
        Los botones conservan la consulta de las entidades; esto no activa
        cobros.
      </p>
      {value.map((b, i) => (
        <fieldset key={b.id} className="campaign-editor">
          <legend>
            {
              {
                credit: "Financiación",
                bank: "Tarjetas y PSE",
                wallet: "Billeteras",
              }[b.id]
            }
          </legend>
          <label>
            <input
              type="checkbox"
              checked={b.visible !== false}
              onChange={(e) => update(i, "visible", e.target.checked)}
            />{" "}
            Mostrar este banner
          </label>
          {[
            ["title", "Título", 90],
            ["text", "Descripción", 220],
            ["button", "Texto del botón", 50],
            ["imageAlt", "Descripción de la imagen", 180],
          ].map(([key, label, max]) => (
            <label key={key}>
              {label}
              <input
                value={b[key] || ""}
                required={key !== "imageAlt" || !!(b.image || b.mobileImage)}
                maxLength={max}
                onChange={(e) => update(i, key, e.target.value)}
              />
            </label>
          ))}
          <Media
            value={b.image || ""}
            label="Imagen para computador y tablet"
            accept="image/png,image/jpeg,image/webp"
            onChange={(url) => update(i, "image", url)}
          />
          <Media
            value={b.mobileImage || ""}
            label="Imagen para celular (opcional)"
            accept="image/png,image/jpeg,image/webp"
            onChange={(url) => update(i, "mobileImage", url)}
          />
          {(b.image || b.mobileImage) && (
            <button
              className="outline"
              type="button"
              onClick={() =>
                onChange(
                  value.map((x, j) =>
                    j === i
                      ? {
                          ...x,
                          image: "",
                          mobileImage: "",
                          imageAlt: "",
                          video: "",
                        }
                      : x,
                  ),
                )
              }
            >
              Usar diseño sin fotografía
            </button>
          )}
          <div className="actions">
            <Media
              label="Video de financiación MP4 · máximo 3 minutos (opcional)"
              value={b.video || ""}
              accept=".mp4"
              onChange={(v) => update(i, "video", v)}
            />
            <button
              type="button"
              disabled={i === 0}
              onClick={() => move(i, -1)}
            >
              Subir
            </button>
            <button
              type="button"
              disabled={i === value.length - 1}
              onClick={() => move(i, 1)}
            >
              Bajar
            </button>
          </div>
        </fieldset>
      ))}
    </details>
  );
}
