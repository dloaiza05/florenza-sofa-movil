import { OBJLoader } from "three/examples/jsm/loaders/OBJLoader.js";
import { GLTFExporter } from "three/examples/jsm/exporters/GLTFExporter.js";
import { Box3, Vector3, MeshStandardMaterial } from "three";
export async function convertObj(text, units) {
 if(typeof text!=="string" || text.length>20*1024*1024)throw Error("OBJ demasiado grande.");
 const scale={m:1,cm:.01,mm:.001}[units];
 if(!scale)throw Error("Selecciona la unidad del modelo.");
 if(!/^v\s/m.test(text)||!/^f\s/m.test(text))throw Error("El archivo no contiene superficies OBJ.");
 const model=new OBJLoader().parse(text);
 try {
  let count=0;
  model.traverse(node=>{
   if(!node.isMesh)return;
   count+=node.geometry.attributes.position.count;
   node.material=new MeshStandardMaterial({name:'Tapizado',color:'#aaa9a5',roughness:.9});
  });
  if(count===0||count>300000)throw Error("Usa un modelo entre 1 y 300.000 vértices resultantes.");
  model.scale.setScalar(scale);model.updateMatrixWorld(true);
  const box=new Box3().setFromObject(model),size=box.getSize(new Vector3()),center=box.getCenter(new Vector3());
  const width=Math.round(size.x*1000)/10,depth=Math.round(size.z*1000)/10,height=Math.round(size.y*1000)/10;
  if(![width,depth,height].every(Number.isFinite)||width<20||depth<20||height<10||width>1000||depth>1000||height>500)throw Error("Las dimensiones no corresponden a un mueble. Revisa las unidades y orientación del OBJ.");
  model.position.set(-center.x,-box.min.y,-center.z);model.updateMatrixWorld(true);
  const buffer=await new GLTFExporter().parseAsync(model,{binary:true,onlyVisible:true});
  return {buffer,width,depth,height};
 } finally {model.traverse(n=>{n.geometry?.dispose();if(Array.isArray(n.material))n.material.forEach(m=>m.dispose());else n.material?.dispose();});}
}
