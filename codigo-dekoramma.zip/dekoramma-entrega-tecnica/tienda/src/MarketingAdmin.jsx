"use client";
import React, { useEffect, useState } from "react";
import { api } from "./api";
function WithdrawRequest({ id, onDone }) {
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  return (
    <details>
      <summary>Registrar retiro solicitado por el titular</summary>
      <form
        className="form-grid"
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          setError("");
          try {
            await api("/admin/marketing/" + id + "/withdraw", {
              method: "POST",
              body: { reason: new FormData(e.currentTarget).get("reason") },
            });
            onDone();
          } catch (e) {
            setError(e.message);
          } finally {
            setBusy(false);
          }
        }}
      >
        <label>
          Constancia de la solicitud
          <input
            name="reason"
            minLength={10}
            maxLength={500}
            required
            placeholder="Canal, fecha y referencia de la solicitud"
          />
        </label>
        <p className="caption">
          Se retirarán los permisos asociados al mismo contacto y quedará
          registro de esta gestión.
        </p>
        {error && <p className="error">{error}</p>}
        <button disabled={busy}>
          {busy ? "Registrando…" : "Registrar retiro de publicidad"}
        </button>
      </form>
    </details>
  );
}
export default function MarketingAdmin() {
  const [data, setData] = useState(null),
    [error, setError] = useState(""),
    [page, setPage] = useState(1);
  useEffect(() => {
    let current = true;
    setData(null);
    api("/admin/marketing?page=" + page)
      .then((x) => {
        if (current) {
          setData(x);
          setError("");
        }
      })
      .catch((e) => {
        if (current) setError(e.message);
      });
    return () => {
      current = false;
    };
  }, [page]);
  return (
    <section>
      <h2>Permisos de novedades y ofertas</h2>
      <p>
        Las asesorías y las compras no inscriben automáticamente a publicidad.
        Estos registros conservan la autorización y los canales elegidos.
      </p>
      <p className="notice">
        Envíos deshabilitados. Falta conectar correo/WhatsApp, verificar la
        titularidad del canal y habilitar los controles de exclusión, horarios y
        frecuencia antes de activar campañas.
      </p>
      {error && <p className="error">{error}</p>}
      {data ? (
        <>
          <p>
            {data.total} solicitudes · página {page} de {data.pages}
          </p>
          {data.contacts.map((x) => (
            <article className="admin-card" key={x.id}>
              <h3>{x.data.name || "Sin nombre"}</h3>
              <p>
                {x.data.email} {x.data.phone}
              </p>
              <p>
                Canales: {x.data.channels.join(" · ")} ·{" "}
                <strong>
                  {x.status === "withdrawn"
                    ? "Autorización retirada"
                    : "Pendiente de verificar"}
                </strong>
              </p>
              <p>
                {new Date(x.created_at).toLocaleString("es-CO", {
                  timeZone: "America/Bogota",
                })}
                {x.data.demo ? " · Registro de demostración" : ""}
              </p>
              <details>
                <summary>Prueba de autorización y política</summary>
                <p>{x.data.consent.text}</p>
                <p>Versión: {x.data.consent.version}</p>
                <p>Huella: {x.data.consent.fingerprint}</p>
                <p>{x.data.consent.privacy}</p>
              </details>
              {x.status !== "withdrawn" && (
                <WithdrawRequest
                  id={x.id}
                  onDone={() =>
                    api("/admin/marketing?page=" + page)
                      .then(setData)
                      .catch((e) => setError(e.message))
                  }
                />
              )}
            </article>
          ))}
          <div className="relationship-actions">
            <button disabled={page === 1} onClick={() => setPage(page - 1)}>
              Anterior
            </button>
            <button
              disabled={page >= data.pages}
              onClick={() => setPage(page + 1)}
            >
              Siguiente
            </button>
          </div>
          <details>
            <summary>Últimos 100 movimientos</summary>
            {data.events.map((e, i) => (
              <p key={i}>
                {new Date(e.created_at).toLocaleString("es-CO", {
                  timeZone: "America/Bogota",
                })}{" "}
                · {e.contact_id} ·{" "}
                {e.action === "withdrawn"
                  ? "Retiro de autorización"
                  : "Solicitud de inscripción"}
              </p>
            ))}
          </details>
        </>
      ) : (
        !error && <p>Cargando…</p>
      )}
    </section>
  );
}
