"use client";
import React, { useEffect, useState } from "react";
import { api } from "./api";
import { storeDirections } from "./locations";
const sections = [
  ["terms", "Términos y condiciones", "terminos"],
  ["warranty", "Garantías y cuidado", "garantias"],
  ["privacy", "Política de privacidad", "privacidad"],
  ["withdrawal", "Derecho de retracto y reversión", "retracto"],
  ["documentation", "Verificación comercial", "documentos"],
];
export default function LegalCenter() {
  const [settings, setSettings] = useState(null),
    [documents, setDocuments] = useState([]),
    [error, setError] = useState("");
  useEffect(() => {
    Promise.all([api("/catalog"), api("/documents")])
      .then(([catalog, result]) => {
        setSettings(catalog.settings);
        setDocuments(result.documents);
      })
      .catch((e) => setError(e.message));
  }, []);
  if (error)
    return (
      <main className="wrap">
        <h1>No pudimos cargar la información</h1>
        <p>{error}</p>
        <button onClick={() => location.reload()}>Reintentar</button>
      </main>
    );
  if (!settings)
    return <main className="loading">Cargando información de la tienda…</main>;
  const s = settings,
    request =
      "mailto:" +
      s.email +
      "?subject=" +
      encodeURIComponent("Solicitud de documentación comercial · Dekoramma") +
      "&body=" +
      encodeURIComponent(
        "Hola, quisiera solicitar información de verificación comercial.\nDocumento que necesito: RUT / Cámara de Comercio / datos para facturación.\nFinalidad de la solicitud: \nNombre y correo de respuesta: ",
      );
  return (
    <main className="legal-page wrap">
      <a className="back-link" href="/">
        ← Volver a la tienda
      </a>
      <header>
        <p className="eyebrow">Dekoramma · Estilo y arte</p>
        <h1>Información para comprar con confianza.</h1>
        <p>
          Conoce dónde estamos, cómo solicitar atención y qué documentos
          respaldan tu compra.
        </p>
      </header>
      {s.legalDraft && (
        <p className="viewer-note">
          Borradores en revisión. La identificación legal y las condiciones
          comerciales pendientes deben completarse antes de abrir ventas.
        </p>
      )}
      <nav className="legal-nav" aria-label="Información al cliente">
        <a href="#ubicacion">Dónde estamos</a>
        {sections.map(([, title, id]) => (
          <a key={id} href={"#" + id}>
            {title}
          </a>
        ))}
      </nav>
      <section id="ubicacion" className="legal-section">
        <h2>Visítanos en Bosa</h2>
        <p>{s.address}</p>
        <p>{s.hours}</p>
        <div className="actions">
          <a
            className="button"
            href={storeDirections(s)}
            target="_blank"
            rel="noreferrer"
          >
            Cómo llegar
          </a>
          <a
            className="button outline"
            href={"https://wa.me/" + s.phone}
            target="_blank"
            rel="noreferrer"
          >
            Atención por WhatsApp
          </a>
        </div>
        <dl className="product-specs">
          <dt>Razón social o nombre del comerciante</dt>
          <dd>{s.legalName || "Pendiente por editar"}</dd>
          <dt>NIT</dt>
          <dd>{s.taxId || "Pendiente por editar"}</dd>
          <dt>Matrícula mercantil</dt>
          <dd>{s.registration || "Pendiente por editar"}</dd>
          <dt>Correo de atención</dt>
          <dd>
            <a href={"mailto:" + s.email}>{s.email}</a>
          </dd>
        </dl>
      </section>
      {sections.map(([key, title, id]) => (
        <section className="legal-section" id={id} key={id}>
          <p className="eyebrow">{s.legalVersion}</p>
          <h2>{title}</h2>
          <div className="legal-copy">
            {(s[key] || "Pendiente por editar").split("\n\n").map((text, i) => (
              <p className="preserve" key={i}>
                {text}
              </p>
            ))}
          </div>
          {documents
            .filter((doc) => doc.category === key)
            .map((doc) => (
              <a
                className="button outline"
                key={doc.id}
                href={"/api/documents/" + doc.id + "/file"}
              >
                Descargar PDF aprobado · {doc.document_year} · v{doc.version}
              </a>
            ))}
          {key === "documentation" && (
            <a className="button outline" href={request}>
              Solicitar RUT o Cámara de Comercio por correo
            </a>
          )}
        </section>
      ))}
      <section className="legal-section">
        <h2>Documentos publicados</h2>
        {documents.length ? (
          documents.map((doc) => (
            <p key={doc.id}>
              <a href={"/api/documents/" + doc.id + "/file"}>
                {doc.title} · {doc.document_year} · versión {doc.version}
              </a>
            </p>
          ))
        ) : (
          <p>
            Los PDFs aparecerán aquí cuando la tienda los apruebe y publique.
            Los documentos internos no se muestran al público.
          </p>
        )}
        <p>
          <a href="https://www.sic.gov.co/" target="_blank" rel="noreferrer">
            Superintendencia de Industria y Comercio
          </a>
        </p>
      </section>
    </main>
  );
}
