import React from "react";
import { ShieldCheck } from "lucide-react";
import PaymentBrand from "./PaymentBrand";
const describe = {
  Bold: ["Tarjeta débito o crédito", "Pago seguro a través de Bold", "card"],
  PSE: ["PSE", "Continúa en tu banco", "bank"],
  Addi: ["Addi", "Financiación sujeta a aprobación", "credit"],
  Sistecrédito: ["Sistecrédito", "Consulta cupo y condiciones", "credit"],
  "Vanti Listo": [
    "Vanti Listo",
    "Sujeto a cupo y convenio habilitado",
    "credit",
  ],
  Nequi: ["Nequi", "Pago desde tu billetera", "wallet"],
  Daviplata: ["DaviPlata", "Consulta el canal disponible", "wallet"],
};
export default function PaymentChoices({ methods, value, onChange }) {
  const ordered = [...methods].sort(
    (a, b) =>
      (a === "Bold" ? 0 : a === "PSE" ? 1 : 2) -
      (b === "Bold" ? 0 : b === "PSE" ? 1 : 2),
  );
  return (
    <fieldset className="payment-choices">
      <legend>Tu forma de pago</legend>
      <div className="payment-choice-grid">
        {ordered.map((method) => {
          const [label, description, kind] = describe[method] || [
            method,
            "Consulta disponibilidad",
            "wallet",
          ];
          return (
            <label
              key={method}
              className={
                "payment-choice " + (value === method ? "selected" : "")
              }
            >
              <input
                type="radio"
                name="method"
                value={method}
                checked={value === method}
                onChange={() => onChange(method)}
                required
              />
              <PaymentBrand method={method} />
              <span>
                <strong>{label}</strong>
                <small>{description}</small>
              </span>
            </label>
          );
        })}
      </div>
      <p className="payment-security">
        <ShieldCheck size={18} />
        Los datos de tarjeta y claves bancarias se ingresan en el proveedor de
        pago.
      </p>
      <p className="caption">
        Conexión de cobro pendiente de activación. Por ahora puedes registrar tu
        solicitud; no se realizará ningún cargo.
      </p>
    </fieldset>
  );
}
