import { adminPreviewRequest } from "./admin-preview-api";
let csrf = "";
export function setCsrf(value) {
  csrf = value || "";
}
export async function api(url, { method = "GET", body } = {}) {
  if (typeof window !== "undefined" && window.location.pathname === "/admin/vista-previa") {
    return adminPreviewRequest(url, { method, body });
  }
  const form = body instanceof FormData;
  const res = await fetch("/api" + url, {
    method,
    credentials: "same-origin",
    headers: {
      ...(!form && body ? { "Content-Type": "application/json" } : {}),
      ...(csrf ? { "X-CSRF-Token": csrf } : {}),
    },
    body: body ? (form ? body : JSON.stringify(body)) : undefined,
  });
  const data = await res
    .json()
    .catch(() => ({ error: "No hay conexión con el servidor" }));
  if (!res.ok) throw new Error(data.error || "No se pudo completar");
  return data;
}
export const money = (n) =>
  new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
    maximumFractionDigits: 0,
  }).format(n);
export const categories = [
  "Salas completas",
  "Esquineros",
  "Sofás cama",
  "Modulares",
  "Poltronas",
  "Reclinables",
  "Sofás",
  "Comedores",
  "Camas",
  "Colchones",
  "Bases cama",
];

export const mediaUrl = (url) =>
  url?.startsWith("/assets/") &&
  url.endsWith(".png") &&
  url !== "/assets/logo.png"
    ? url.replace(/\.png$/, ".webp")
    : url;

export async function resetRehearsal(){ throw Error("Esta opción solo pertenece al ensayo de GitHub."); }
