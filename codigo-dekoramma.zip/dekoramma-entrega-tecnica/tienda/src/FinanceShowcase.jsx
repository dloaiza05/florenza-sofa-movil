import React from "react";
import { ArrowUpRight, ArrowRight } from "lucide-react";
import PaymentBrand from "./PaymentBrand";
import { financeBanners } from "./finance-content";
import { mediaUrl } from "./api";
import BannerMedia from "./BannerMedia";
const groups = {
  credit: ["Addi", "Sistecrédito", "Vanti Listo"],
  bank: ["Bold", "PSE"],
  wallet: ["Nequi", "Daviplata"],
};
export default function FinanceShowcase({
  title,
  subtitle,
  banners = financeBanners,
  methods,
  onChoose,
  onBrowse,
  demo,
}) {
  return (
    <div className="finance-showcase">
      <div className="finance-heading">
        <div>
          <span className="eyebrow">ESTILO Y ARTE, TAMBIÉN AL ELEGIR</span>
          <h2>{title}</h2>
          <p>{subtitle}</p>
        </div>
        <span className="finance-signature">
          Hecho a tu medida.
          <br />
          También tu forma de elegir.
        </span>
      </div>
      <div className="finance-banners">
        {banners.map((banner, i) => {
          const available = (groups[banner.id] || []).filter((x) =>
            methods.includes(x),
          );
          if (!available.length || banner.visible === false) return null;
          return (
            <article
              className={`finance-banner finance-banner--${banner.id}`}
              key={banner.id}
            >
              {(banner.image || banner.mobileImage || banner.video) && (
                <div className="finance-banner-photo">
                  <BannerMedia
                    banner={{
                      ...banner,
                      image: banner.image || banner.mobileImage,
                    }}
                  />
                </div>
              )}
              <div className="finance-banner-top">
                <span>
                  0{i + 1} /{" "}
                  {banner.id === "credit"
                    ? "A TU RITMO"
                    : banner.id === "bank"
                      ? "A TU MANERA"
                      : "DESDE TU CELULAR"}
                </span>
                <img
                  src={`/assets/payments/dekoramma-${banner.id}.svg`}
                  alt=""
                  width="88"
                  height="88"
                />
              </div>
              <h3>{banner.title}</h3>
              <p>{banner.text}</p>
              <div className="finance-provider-row">
                {available.map((method) => (
                  <button
                    key={method}
                    onClick={() => onChoose(method)}
                    aria-label={`Consultar condiciones de ${method}`}
                  >
                    <PaymentBrand method={method} />
                  </button>
                ))}
              </div>
              <button
                className="finance-cta"
                onClick={() => onBrowse(available, banner.button)}
              >
                {banner.button}
                <ArrowUpRight size={20} />
              </button>
            </article>
          );
        })}
      </div>
      <div className="finance-support">
        <span>Encuentra una opción para tu hogar</span>
        <div>
          {methods.map((method) => (
            <button
              key={method}
              onClick={() => onChoose(method)}
              aria-label={`Ver condiciones de ${method}`}
            >
              <PaymentBrand method={method} />
            </button>
          ))}
        </div>
        <a href="#catalogo">
          Explorar muebles <ArrowRight size={16} />
        </a>
      </div>
      <p className="caption finance-disclosure">
        Financiación sujeta a aprobación, cupo y condiciones de cada entidad.
        {demo
          ? " Vista de desarrollo: conexiones de cobro pendientes de activación."
          : ""}
      </p>
    </div>
  );
}
