import React from "react";
import { categories } from "./api";
function localDate(value) {
  return value
    ? new Date(Date.parse(value) - 5 * 3600000).toISOString().slice(0, 16)
    : "";
}
export default function CampaignEditor({ campaigns = [], onChange, Media }) {
  const update = (index, key, value) =>
    onChange(
      campaigns.map((c, i) => (i === index ? { ...c, [key]: value } : c)),
    );
  return (
    <details className="editor-section">
      <summary>Campañas del banner · simulación</summary>
      <p>
        Hasta seis campañas. Horarios de Bogotá. Solo se muestran durante su
        vigencia y con la vista de desarrollo activa. Estos porcentajes no
        cambian los precios.
      </p>
      {campaigns.map((c, i) => (
        <fieldset key={c.id} className="campaign-editor">
          <legend>Campaña {i + 1}</legend>
          <div className="actions">
            {[-1, 1].map((delta) => (
              <button
                key={delta}
                type="button"
                disabled={i + delta < 0 || i + delta >= campaigns.length}
                onClick={() => {
                  const next = [...campaigns];
                  [next[i], next[i + delta]] = [next[i + delta], next[i]];
                  onChange(next);
                }}
              >
                {delta < 0 ? "Subir" : "Bajar"}
              </button>
            ))}
          </div>
          <label>
            <input
              type="checkbox"
              checked={c.enabled}
              onChange={(e) => update(i, "enabled", e.target.checked)}
            />{" "}
            Mostrar durante la vigencia
          </label>
          {[
            ["title", "Título", 90],
            ["text", "Descripción", 240],
            ["buttonText", "Texto del botón", 40],
            ["imageAlt", "Descripción accesible de la foto", 180],
          ].map(([key, label, max]) => (
            <label key={key}>
              {label}
              <input
                required
                maxLength={max}
                value={c[key]}
                onChange={(e) => update(i, key, e.target.value)}
              />
            </label>
          ))}
          <label>
            Porcentaje de ejemplo
            <input
              type="number"
              required
              min="1"
              max="95"
              step="1"
              value={c.discountPercent}
              onChange={(e) =>
                update(i, "discountPercent", Number(e.target.value))
              }
            />
          </label>
          <label>
            Categoría que abre el botón
            <select
              value={c.category}
              onChange={(e) => update(i, "category", e.target.value)}
            >
              {categories.map((x) => (
                <option key={x}>{x}</option>
              ))}
            </select>
          </label>
          {[
            ["startsAt", "Inicio"],
            ["endsAt", "Cierre"],
          ].map(([key, label]) => (
            <label key={key}>
              {label} · Bogotá
              <input
                required
                type="datetime-local"
                value={localDate(c[key])}
                onChange={(e) =>
                  update(
                    i,
                    key,
                    e.target.value ? `${e.target.value}:00-05:00` : "",
                  )
                }
              />
            </label>
          ))}
          <Media
            label="Fotografía de la campaña"
            value={c.image}
            onChange={(v) => update(i, "image", v)}
            accept="image/png,image/jpeg,image/webp"
          />
          <Media
            label="Imagen para celular (opcional)"
            value={c.mobileImage || ""}
            onChange={(v) => update(i, "mobileImage", v)}
            accept="image/png,image/jpeg,image/webp"
          />
          {c.mobileImage && (
            <button
              type="button"
              className="outline"
              onClick={() => update(i, "mobileImage", "")}
            >
              Usar la misma imagen en todos los tamaños
            </button>
          )}
          <label>
            Condiciones
            <textarea
              required
              maxLength={2000}
              value={c.terms}
              onChange={(e) => update(i, "terms", e.target.value)}
            />
          </label>
          <Media
            label="Video de campaña MP4 · máximo 3 minutos (opcional)"
            value={c.video || ""}
            accept=".mp4"
            onChange={(v) => update(i, "video", v)}
          />
          <p>
            El video reemplaza la fotografía al reproducirlo. Conserva una
            imagen de portada; la información esencial debe estar también en los
            textos.
          </p>
          <button
            type="button"
            className="outline"
            onClick={() => onChange(campaigns.filter((_, j) => i !== j))}
          >
            Quitar campaña
          </button>
        </fieldset>
      ))}
      <button
        type="button"
        disabled={campaigns.length >= 6}
        onClick={() =>
          onChange([
            ...campaigns,
            {
              id: crypto.randomUUID(),
              enabled: false,
              simulation: true,
              title: "Nueva campaña",
              text: "Describe la colección y sus condiciones.",
              discountPercent: 10,
              startsAt: new Date().toISOString(),
              endsAt: new Date(Date.now() + 7 * 86400000).toISOString(),
              image: "/assets/sala-industrial.png",
              imageAlt: "Sala modular en ambiente industrial",
              category: categories[0],
              buttonText: "Explorar colección",
              terms:
                "Simulación. Promoción pendiente de aprobación; no modifica los precios.",
            },
          ])
        }
      >
        Añadir campaña
      </button>
    </details>
  );
}
