// Gallery bindings are authoritative; never recolor a photo to simulate upholstery.
export function productPhoto(product, color) {
  const photo =
    product?.gallery?.find((p) => p.color === color && p.url) ||
    product?.colorImages?.find((p) => p.color === color && p.url);
  return {
    url: photo?.url || product?.image || "",
    alt:
      photo?.alt ||
      `${product?.name || "Producto"}${photo ? " · " + color : " · imagen de referencia"}`,
    matched: !!photo,
  };
}
