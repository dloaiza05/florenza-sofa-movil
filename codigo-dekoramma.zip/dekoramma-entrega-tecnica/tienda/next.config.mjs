export default {
  poweredByHeader: false,
  devIndicators: false,
  productionBrowserSourceMaps: false,
  turbopack: { root: process.cwd() },
};
