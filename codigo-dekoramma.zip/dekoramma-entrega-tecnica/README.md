# Dekoramma · Entrega técnica de revisión

Código organizado de Florenza Estudio Digital. Este respaldo de desarrollo no es un acta de entrega final ni acredita funcionamiento de servicios financieros o administración en producción.

## Carpetas

- tienda/src: componentes React y estilos.
- tienda/app: rutas de Next.js.
- tienda/server/controllers: controladores de solicitudes.
- tienda/server/services: lógica de servicios.
- tienda/server/repositories: acceso a datos; tienda/server/db.js contiene inicialización de base de datos.
- tienda/tests: pruebas disponibles del proyecto.
- visor: código del visor móvil. Florenza VR es un servicio propio; véase LICENSE.md. No cede titularidad a Dekoramma.
- herramientas: preparación de imágenes y scripts de publicación usados en el workspace original.
- docs: análisis de privacidad y condiciones pendientes.

## Abrir una copia local

1. Descargar el repositorio florenza-sofa-movil completo y descomprimir este ZIP.
2. Ejecutar `python herramientas/preparar_medios.py RUTA_DEL_REPOSITORIO_DESCARGADO`. Copia las imágenes y GLB públicos a la estructura de la tienda.
3. Dentro de tienda, ejecutar `npm ci` y `npm run dev`. Requiere Node.js compatible con el package.json. El desarrollo local usa la base de desarrollo prevista en server/db.js.
4. Abrir http://localhost:8790. Configurar servicios y acceso administrativo por separado; no se suministran credenciales en esta copia.

La publicación de GitHub Pages ejecuta únicamente HTML/CSS/JavaScript. No ejecuta Node.js ni PostgreSQL. La demostración administrativa es temporal y no sube archivos ni guarda datos comerciales.

## Trabajo y aprobaciones

La carpeta local outputs/dekoramma-web sigue siendo el proyecto de trabajo. Revisar allí los cambios con Lady y el equipo. Registrar qué versión aprobaron y qué falta; no publicar automáticamente cada edición. Preparar una copia pública, comprobar catálogo, imágenes, navegación y visor, y subir únicamente los archivos de publicación. Mantener la versión anterior y registrar su commit para poder volver atrás. Los scripts de build incluidos conservan rutas del workspace original y requieren ejecutarse desde su raíz.

Versión 1 del visor: commit 0c605c5a6b1bbac7983828bcd7a1c0caca70af52, conservada en outputs/florenza-sofa-movil-v1 y publicada como v1.html. El proyecto original florenza-v permanece separado.

Nunca subir .env, contraseñas, tokens, bases de datos, carpetas uploads, contratos, documentos de identidad ni registros de clientes. En producción configurar HTTPS, PostgreSQL, almacenamiento y responsables de operación antes de habilitar los servicios reales.
