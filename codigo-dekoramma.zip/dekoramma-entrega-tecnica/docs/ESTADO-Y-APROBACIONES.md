# Estado de esta versión

## Publicación de revisión

- Tienda: https://dloaiza05.github.io/florenza-sofa-movil/dekoramma.html
- Visor actualizado: https://dloaiza05.github.io/florenza-sofa-movil/
- Versión 1: https://dloaiza05.github.io/florenza-sofa-movil/v1.html
- Respaldo de fuente: https://dloaiza05.github.io/florenza-sofa-movil/codigo-dekoramma.zip

GitHub Pages sirve la demostración y los archivos públicos sin depender del computador. No es el servidor de producción de la tienda. Los datos del catálogo son de ejemplo; la administración es una simulación en memoria. No hay cobros reales ni envío de formularios en esta publicación.

## Comprobado

Portada y catálogo publicados, imágenes sin fallos observados, apertura del visor dentro del catálogo, carga del sofá, cambio de color, aviso de cámara con casilla inicialmente desmarcada y posibilidad de cancelar, comparación manual de medidas y demostración administrativa. Respaldo V1 coincide por SHA-256 con los once archivos de la primera publicación. Repositorio original florenza-v sin nuevos commits.

## Pendiente de comprobar o acordar

- Colocación y colores sobre la cámara en Android WebXR real. Interfaz nativa de iPhone/Scene Viewer: cambios de color desde la web antes de entrar.
- Modelo de celular y navegador de la esposa para reproducir su dificultad.
- Medidas físicas y modelos propios de cada producto; actualmente solo hay un sofá de prueba en tres acabados.
- Escáner completo de mallas, paredes, obstáculos y medidas automáticas: no implementado; requiere estudio específico y no se ofrece como función probada.
- Datos legales y política de privacidad definitiva del comercio, papeles de responsable/encargado y condiciones de servicio Florenza VR. No se ha acordado duración, renovación ni tarifa adicional.
- Servidor, dominio, almacenamiento, configuración administrativa y cobros oficiales antes de operar comercialmente.

## Forma de trabajar

Mantener el proyecto original en outputs/dekoramma-web. Revisar cambios localmente, registrar aprobación de Lady y el equipo, preparar la publicación de revisión y subir únicamente su contenido público. Conservar cada commit y copia aprobada. El respaldo organizado está en outputs/dekoramma-entrega-tecnica. No copiar a GitHub las carpetas privadas del proyecto ni los contratos.

Contrato actualizado: Contrato-Dekoramma-Florenza-BORRADOR-V20.pdf. Anexo para acompañar el portafolio: Anexo-Florenza-VR-servicio-V01.pdf. Ambos permanecen locales.
