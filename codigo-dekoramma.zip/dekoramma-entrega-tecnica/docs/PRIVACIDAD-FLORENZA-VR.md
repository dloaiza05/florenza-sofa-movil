# Florenza VR: privacidad y condiciones de la prueba

## Comportamiento revisado

El visor usa model-viewer, servido desde la misma publicación, para cargar tres GLB de un sofá. La página propia no incorpora captura de video, subida de fotografías, reconocimiento facial, grabación de audio ni almacenamiento de planos. La comparación manual de dimensiones permanece en memoria en el navegador. El consentimiento de esta demostración no se envía ni se registra en un servidor.

La cámara y el seguimiento espacial se activan al solicitar realidad aumentada y conceder los permisos del dispositivo. WebXR, Scene Viewer y Quick Look no son equivalentes. Las aplicaciones nativas tienen interfaces y políticas propias; no se puede afirmar que el proveedor externo no trate datos. GitHub puede tratar IP, dispositivo y datos de acceso según su política. El sitio comercial de demostración conserva localmente una bolsa de productos y preferencias de bienvenida; esto es distinto del visor.

## Aviso implementado

Antes de abrir la cámara se explica su finalidad y se ofrece continuar sin cámara. La casilla empieza sin marcar. Hay información ampliable y enlaces a políticas de proveedores. La aceptación no es una renuncia de derechos ni una autorización para publicidad. La V1 se conserva como copia histórica sin estas mejoras y no debe presentarse como versión definitiva con este aviso.

## Responsabilidades que deben acordarse antes de producción

Dekoramma debe identificarse como responsable de los tratamientos que determine para su tienda y aprobar finalidad, política, canales de consultas y reclamos. Florenza conserva sus obligaciones por los tratamientos que realice y, si actúa por cuenta de Dekoramma, debe documentarse su papel de encargado y las instrucciones correspondientes. El visitante no asume por aceptar el aviso los incumplimientos de estas partes.

Faltan identificación jurídica completa, canal aprobado de privacidad, inventario final de proveedores y flujos, condiciones del servicio VR y pruebas en equipos físicos. Si se añade registro de autorizaciones, almacenar únicamente versión del aviso, acción, fecha/hora y el identificador mínimo necesario, con conservación y acceso definidos; no recopilar fotos, IP o datos identificativos innecesarios para simular evidencia legal. Si en el futuro se guarda una malla o imagen de la vivienda, hay que revisar previamente finalidad, necesidad, seguridad, conservación y autorización específica. No está incluido en esta prueba.

La casilla no impide reclamaciones ni sustituye el cumplimiento legal. Mantener un aviso visible, claro y accesible; no esconder información esencial en letra ilegible. Revisión jurídica final aconsejable antes de su uso comercial.

## Fuentes oficiales consultadas

- SIC, finalidad y autorización: https://www.sic.gov.co/recursos_user/boletin-juridico-feb2017/articulo/datos/el-principio-de-la-finalidad-debe-tenerse-en-cuenta.html
- SIC, política y marco de Ley 1581: https://sedeelectronica.sic.gov.co/politica-de-tratamiento-de-datos-personales
- GitHub, política vigente desde el 27/04/2026: https://docs.github.com/en/site-policy/privacy-policies/github-general-privacy-statement
- Model-viewer, modos de realidad aumentada: https://modelviewer.dev/examples/augmentedreality/index.html
- DNDA, software y titularidad: https://www.derechodeautor.gov.co/es/registro-de-software
