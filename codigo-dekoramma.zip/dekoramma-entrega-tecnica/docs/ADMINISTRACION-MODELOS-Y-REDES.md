# Revisión de administración, medios y Florenza VR

## Uso local
En /admin, Productos permite organizar hasta 10 fotografías y 3 videos MP4 por referencia (máximo 180 segundos por video), cargar GLB y USDZ, y revisar el visor con los cambios del formulario. Guardar producto publica sus datos en el servidor local. El catálogo público de GitHub es una demostración independiente sin usuarios, cobros ni persistencia administrativa.

Las opciones de cada visor permiten mostrar medidas, comparación manual con espacio libre, sugerencia horizontal y acceso a cámara. El aviso de privacidad no es desactivable desde estos controles. La cámara sigue dependiendo del dispositivo y navegador; no hay escaneo de malla, paredes ni detección de obstáculos.

## Archivos
GLB: archivo autocontenido, escala en metros, origen al piso. USDZ: opcional para iPhone, debe coincidir con el GLB. OBJ básico: importación de geometría hasta 20 MB y 300.000 vértices resultantes, unidades seleccionadas por el administrador, conversión a GLB, sin MTL ni texturas externas. El operador verifica orientación, escala y calidad antes de guardar. No sustituye un render fotorrealista.

Cada acabado del visor admite GLB y USDZ propios. Los archivos deben representar la misma geometría. El nombre de material habilita un cambio orientativo de color dentro de WebXR; los visores nativos requieren elegir el acabado antes de abrir la cámara. La fidelidad de los modelos y colores debe revisarse en Android e iPhone físicos.

## Redes sociales
Facebook e Instagram aparecen encima de WhatsApp con los recursos gráficos existentes. Sus enlaces se editan en Tienda. Se conserva el acceso del pie de página. Estos botones únicamente abren los perfiles configurados.

## Validación
Conversión OBJ, dimensiones, rechazo de archivos inválidos y URLs externas, carga autenticada y controles de visibilidad revisados. El modelo geométrico de control se probó en el formulario sin guardar cambios sobre los productos existentes. No se ejecutó cámara AR en un celular físico durante esta revisión.
