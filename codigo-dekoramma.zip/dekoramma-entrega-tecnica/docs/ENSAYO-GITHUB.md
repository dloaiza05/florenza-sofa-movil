# Ensayo de administración en GitHub Pages

El acceso de demostración permite ensayar con el catálogo público. Guarda productos, fotografías JPG/PNG/WEBP, videos MP4, modelos GLB/USDZ, textos y campañas en IndexedDB del navegador. Los OBJ se convierten a GLB básico desde el editor existente. No se envían estos cambios a GitHub, al servidor ni a otros dispositivos.

En «Opciones de prueba» se encuentra «Restablecer página original», con confirmación antes de borrar el ensayo. Conserva el código y los archivos publicados. Los archivos locales de prueba no son una copia de seguridad; pueden perderse al borrar los datos del navegador.

El acceso por contraseña es una comodidad del ensayo, no una barrera de seguridad para datos privados. La tienda real conserva autenticación de servidor. No incluir contraseñas, sesiones, datos de clientes ni documentos privados en el paquete público.

Las cargas GLB locales funcionan en el visor web. La cámara depende del dispositivo y del modo AR disponible; Scene Viewer necesita un modelo alojado en una URL pública y no puede leer archivos Blob del navegador. Las pruebas de cámara con modelos publicados siguen disponibles en el visor independiente.

El servidor sigue siendo necesario para solicitudes reales, documentos y aprobaciones, almacenamiento compartido, permisos y operaciones de negocio. Estas funciones no se simulan como ejecutadas.

## Revisión del 13/09/2026

- Inicio de sesión válido y rechazo de credenciales incorrectas comprobados en el navegador de prueba.
- JPG y MP4 de dos segundos cargados desde administración; nombre y medidas modificados; persistencia tras navegación y recarga comprobada en la ficha del cliente.
- GLB del sofá cargado; visor recibió el modelo y mostró 190 × 104 × 89 cm.
- Restablecimiento comprobado: recuperó el nombre original y la galería base. Posteriormente se reforzó el restablecimiento con una transacción conjunta y espera de guardados anteriores.
- Bienvenida repetida al refrescar, botón siguiente del banner y selector de ciudad comprobados. El selector pasó después al encabezado compacto.
- Redes trasladadas al pie de página; se retiró su duplicado de las preguntas frecuentes. Logotipo SVG de Sistecrédito obtenido del sitio oficial y documentado en PAYMENT-ASSET-SOURCES.json. DaviPlata permanece como texto hasta disponer de un recurso oficial de calidad suficiente.
- 31 pruebas existentes aprobadas; compilación Next.js aprobada. Revisión visual de escritorio realizada. La herramienta no aplicó el tamaño móvil solicitado; la comprobación física en celular sigue pendiente.

La publicación se registra en la cola de trabajo y en el archivo de comprobación de despliegue, después de verificar GitHub Pages.
